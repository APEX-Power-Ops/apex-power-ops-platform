"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

export type UserRole = "executive" | "project-manager" | "estimator" | "field-tech" | "office-admin"

export interface RoleInfo {
  id: UserRole
  name: string
  title: string
  avatar: string
  initials: string
}

export const roles: Record<UserRole, RoleInfo> = {
  executive: {
    id: "executive",
    name: "Brandon Carrasco",
    title: "Regional VP / GM Arizona Services",
    avatar: "/avatars/executive.png",
    initials: "BC",
  },
  "project-manager": {
    id: "project-manager",
    name: "Jason Swenson",
    title: "Senior Project Manager",
    avatar: "/avatars/pm.png",
    initials: "JS",
  },
  estimator: {
    id: "estimator",
    name: "Chad Sheffield",
    title: "Account Manager",
    avatar: "/avatars/estimator.png",
    initials: "CS",
  },
  "field-tech": {
    id: "field-tech",
    name: "Phillip Pentecost",
    title: "Lead Technician",
    avatar: "/avatars/field-tech.png",
    initials: "PP",
  },
  "office-admin": {
    id: "office-admin",
    name: "Annelise Silivongxay",
    title: "Operations Coordinator",
    avatar: "/avatars/admin.png",
    initials: "AS",
  },
}

interface RoleContextType {
  currentRole: UserRole
  roleInfo: RoleInfo
  setRole: (role: UserRole) => void
}

const RoleContext = createContext<RoleContextType | undefined>(undefined)

export function RoleProvider({ children }: { children: ReactNode }) {
  const [currentRole, setCurrentRole] = useState<UserRole>("executive")

  const value: RoleContextType = {
    currentRole,
    roleInfo: roles[currentRole],
    setRole: setCurrentRole,
  }

  return <RoleContext.Provider value={value}>{children}</RoleContext.Provider>
}

export function useRole() {
  const context = useContext(RoleContext)
  if (!context) {
    throw new Error("useRole must be used within a RoleProvider")
  }
  return context
}
