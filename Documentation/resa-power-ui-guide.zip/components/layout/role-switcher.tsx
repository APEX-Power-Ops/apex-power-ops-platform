"use client"

import type React from "react"

import { useRole, roles, type UserRole } from "@/contexts/role-context"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ChevronDown, Briefcase, FolderKanban, Calculator, Wrench, ClipboardList, User } from "lucide-react"

const roleIcons: Record<UserRole, React.ElementType> = {
  executive: Briefcase,
  "project-manager": FolderKanban,
  estimator: Calculator,
  "field-tech": Wrench,
  "office-admin": ClipboardList,
}

export function RoleSwitcher() {
  const { currentRole, roleInfo, setRole } = useRole()

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2 h-9 px-3 border-dashed bg-transparent">
          <Avatar className="h-6 w-6">
            <AvatarFallback className="text-xs bg-primary/10 text-primary">{roleInfo.initials}</AvatarFallback>
          </Avatar>
          <div className="flex flex-col items-start text-left">
            <span className="text-xs font-medium leading-none">{roleInfo.name}</span>
            <span className="text-[10px] text-muted-foreground leading-none mt-0.5">{roleInfo.title}</span>
          </div>
          <ChevronDown className="h-3 w-3 text-muted-foreground ml-1" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-56">
        <DropdownMenuLabel className="text-xs text-muted-foreground font-normal">Switch Demo Role</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {Object.values(roles).map((role) => {
          const Icon = roleIcons[role.id] || User
          const isActive = currentRole === role.id
          return (
            <DropdownMenuItem key={role.id} onClick={() => setRole(role.id)} className={isActive ? "bg-accent" : ""}>
              <Icon className="mr-2 h-4 w-4 text-muted-foreground" />
              <div className="flex flex-col">
                <span className="font-medium">{role.name}</span>
                <span className="text-xs text-muted-foreground">{role.title}</span>
              </div>
            </DropdownMenuItem>
          )
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
