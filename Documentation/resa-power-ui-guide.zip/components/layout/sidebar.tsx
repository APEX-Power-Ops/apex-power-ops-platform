"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  FolderKanban,
  Zap,
  Users,
  Building2,
  FileText,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  DollarSign,
  Calculator,
  Calendar,
  ClipboardList,
  Target,
  Wrench,
  BookOpen,
  Book,
  FileImage,
  ShieldCheck,
  ShieldAlert,
  ClipboardCheck,
  AlertTriangle,
  Receipt,
  UserCog,
  Plug,
  HelpCircle,
  ChevronsUpDown,
  Cpu,
  Lock,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { useRole, type UserRole } from "@/contexts/role-context"
import { Badge } from "@/components/ui/badge"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface NavItem {
  name: string
  href: string
  icon: React.ElementType
  roles: UserRole[]
  badge?: number | string
  status?: "coming-soon" | "phase-2"
  locked?: boolean
}

interface NavGroup {
  name: string
  icon: React.ElementType
  defaultExpanded?: boolean
  roles: UserRole[]
  items: NavItem[]
}

const navigationGroups: NavGroup[] = [
  {
    name: "Operations",
    icon: LayoutDashboard,
    defaultExpanded: true,
    roles: ["executive", "project-manager", "estimator", "office-admin"],
    items: [
      {
        name: "Dashboard",
        href: "/",
        icon: LayoutDashboard,
        roles: ["executive", "project-manager", "estimator", "office-admin"],
      },
      {
        name: "Projects",
        href: "/projects",
        icon: FolderKanban,
        roles: ["executive", "project-manager", "estimator", "office-admin"],
      },
      {
        name: "Clients",
        href: "/clients",
        icon: Building2,
        roles: ["executive", "project-manager", "estimator", "office-admin"],
      },
      { name: "Apparatus", href: "/apparatus", icon: Cpu, roles: ["executive", "project-manager", "office-admin"] },
    ],
  },
  {
    name: "Resources",
    icon: Users,
    defaultExpanded: false,
    roles: ["executive", "project-manager", "office-admin"],
    items: [
      {
        name: "Employees",
        href: "/employees",
        icon: Users,
        roles: ["executive", "project-manager", "office-admin"],
        status: "coming-soon",
      },
      {
        name: "Equipment",
        href: "/equipment",
        icon: Wrench,
        roles: ["executive", "project-manager", "office-admin"],
        status: "coming-soon",
      },
      {
        name: "Scheduling",
        href: "/scheduling",
        icon: Calendar,
        roles: ["executive", "project-manager", "office-admin"],
      },
    ],
  },
  {
    name: "Services",
    icon: Zap,
    defaultExpanded: true,
    roles: ["executive", "project-manager", "estimator", "office-admin"],
    items: [
      {
        name: "Power System Studies",
        href: "/studies",
        icon: Zap,
        roles: ["executive", "project-manager", "estimator", "office-admin"],
        badge: 12,
      },
      {
        name: "Estimates",
        href: "/estimates",
        icon: Calculator,
        roles: ["executive", "project-manager", "estimator", "office-admin"],
      },
      { name: "Reports", href: "/reports", icon: FileText, roles: ["executive", "project-manager", "office-admin"] },
    ],
  },
  {
    name: "Reference Materials",
    icon: BookOpen,
    defaultExpanded: false,
    roles: ["executive", "project-manager", "estimator", "field-tech", "office-admin"],
    items: [
      {
        name: "NETA Standards",
        href: "/neta-standards",
        icon: BookOpen,
        roles: ["executive", "project-manager", "estimator", "field-tech", "office-admin"],
        status: "coming-soon",
      },
      {
        name: "SOPs",
        href: "/sops",
        icon: ClipboardList,
        roles: ["executive", "project-manager", "estimator", "field-tech", "office-admin"],
        status: "coming-soon",
      },
      {
        name: "Safety Documents",
        href: "/safety-docs",
        icon: ShieldAlert,
        roles: ["executive", "project-manager", "estimator", "field-tech", "office-admin"],
        status: "coming-soon",
      },
      {
        name: "Equipment Manuals",
        href: "/manuals",
        icon: Book,
        roles: ["executive", "project-manager", "estimator", "field-tech", "office-admin"],
        status: "coming-soon",
      },
      {
        name: "Drawings",
        href: "/drawings",
        icon: FileImage,
        roles: ["executive", "project-manager", "estimator", "office-admin"],
        status: "coming-soon",
      },
    ],
  },
  {
    name: "Safety",
    icon: ShieldCheck,
    defaultExpanded: false,
    roles: ["executive", "project-manager", "field-tech", "office-admin"],
    items: [
      {
        name: "Safety Dashboard",
        href: "/safety",
        icon: ShieldCheck,
        roles: ["executive", "project-manager", "field-tech", "office-admin"],
        status: "coming-soon",
      },
      {
        name: "JHA Forms",
        href: "/jha",
        icon: ClipboardCheck,
        roles: ["executive", "project-manager", "field-tech", "office-admin"],
        status: "coming-soon",
      },
      {
        name: "Incident Reports",
        href: "/incidents",
        icon: AlertTriangle,
        roles: ["executive", "project-manager", "office-admin"],
        status: "coming-soon",
      },
    ],
  },
  {
    name: "Finance",
    icon: DollarSign,
    defaultExpanded: false,
    roles: ["executive", "project-manager"],
    items: [
      { name: "Financials", href: "/financials", icon: DollarSign, roles: ["executive", "project-manager"] },
      {
        name: "Invoicing",
        href: "/invoicing",
        icon: Receipt,
        roles: ["executive", "project-manager"],
        status: "phase-2",
      },
    ],
  },
  {
    name: "Admin",
    icon: Settings,
    defaultExpanded: false,
    roles: ["executive", "office-admin"],
    items: [
      { name: "Admin Settings", href: "/admin", icon: Settings, roles: ["executive"], locked: true },
      {
        name: "User Management",
        href: "/users",
        icon: UserCog,
        roles: ["executive", "office-admin"],
        status: "coming-soon",
      },
      { name: "Integrations", href: "/integrations", icon: Plug, roles: ["executive"], status: "phase-2" },
    ],
  },
  // Project Manager specific
  {
    name: "My Work",
    icon: Target,
    defaultExpanded: true,
    roles: ["project-manager"],
    items: [
      { name: "My Projects", href: "/my-projects", icon: FolderKanban, roles: ["project-manager"] },
      { name: "Team Workload", href: "/team-workload", icon: Users, roles: ["project-manager"], status: "coming-soon" },
      {
        name: "Task Calendar",
        href: "/task-calendar",
        icon: Calendar,
        roles: ["project-manager"],
        status: "coming-soon",
      },
    ],
  },
  // Estimator specific
  {
    name: "Sales",
    icon: Target,
    defaultExpanded: true,
    roles: ["estimator"],
    items: [
      { name: "Pipeline", href: "/pipeline", icon: Target, roles: ["estimator"] },
      { name: "Opportunities", href: "/opportunities", icon: Calculator, roles: ["estimator"], status: "coming-soon" },
    ],
  },
]

export function Sidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)
  const { currentRole } = useRole()

  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>(() => {
    const initial: Record<string, boolean> = {}
    navigationGroups.forEach((group) => {
      initial[group.name] = group.defaultExpanded ?? false
    })
    return initial
  })

  const toggleGroup = (groupName: string) => {
    setExpandedGroups((prev) => ({
      ...prev,
      [groupName]: !prev[groupName],
    }))
  }

  const toggleAllGroups = (expand: boolean) => {
    const newState: Record<string, boolean> = {}
    navigationGroups.forEach((group) => {
      newState[group.name] = expand
    })
    setExpandedGroups(newState)
  }

  // Filter groups and items based on current role
  const filteredGroups = navigationGroups
    .filter((group) => group.roles.includes(currentRole))
    .map((group) => ({
      ...group,
      items: group.items.filter((item) => item.roles.includes(currentRole)),
    }))
    .filter((group) => group.items.length > 0)

  if (currentRole === "field-tech") {
    return null
  }

  return (
    <aside
      className={cn(
        "flex flex-col bg-sidebar text-sidebar-foreground h-screen sticky top-0 transition-all duration-300",
        collapsed ? "w-16" : "w-64",
      )}
    >
      {/* Logo */}
      <div className="flex items-center h-16 px-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary">
            <Zap className="w-5 h-5 text-primary-foreground" />
          </div>
          {!collapsed && <span className="text-lg font-semibold tracking-tight">RESA Power</span>}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
        {filteredGroups.map((group) => (
          <Collapsible
            key={group.name}
            open={!collapsed && expandedGroups[group.name]}
            onOpenChange={() => !collapsed && toggleGroup(group.name)}
          >
            <CollapsibleTrigger asChild>
              <button
                className={cn(
                  "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors w-full",
                  "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground",
                  collapsed && "justify-center",
                )}
              >
                <group.icon className="w-5 h-5 shrink-0" />
                {!collapsed && (
                  <>
                    <span className="flex-1 text-left text-xs uppercase tracking-wider font-semibold">
                      {group.name}
                    </span>
                    <ChevronDown
                      className={cn(
                        "w-4 h-4 transition-transform",
                        expandedGroups[group.name] ? "rotate-0" : "-rotate-90",
                      )}
                    />
                  </>
                )}
              </button>
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-1 mt-1">
              {group.items.map((item) => {
                const isActive = pathname === item.href
                const isDisabled = item.status === "coming-soon" || item.status === "phase-2"

                return (
                  <Link
                    key={item.name}
                    href={isDisabled ? "#" : item.href}
                    onClick={(e) => isDisabled && e.preventDefault()}
                    className={cn(
                      "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ml-2",
                      isActive && !isDisabled
                        ? "bg-sidebar-accent text-sidebar-accent-foreground"
                        : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground",
                      isDisabled && "opacity-50 cursor-not-allowed hover:bg-transparent",
                    )}
                  >
                    <item.icon className="w-4 h-4 shrink-0" />
                    {!collapsed && (
                      <>
                        <span className="flex-1">{item.name}</span>
                        {item.badge && typeof item.badge === "number" && (
                          <Badge variant="secondary" className="ml-auto text-xs h-5 px-1.5">
                            {item.badge}
                          </Badge>
                        )}
                        {item.status === "coming-soon" && (
                          <Badge
                            variant="outline"
                            className="ml-auto text-[10px] h-5 px-1.5 bg-amber-500/10 text-amber-600 border-amber-500/30"
                          >
                            Soon
                          </Badge>
                        )}
                        {item.status === "phase-2" && (
                          <Badge
                            variant="outline"
                            className="ml-auto text-[10px] h-5 px-1.5 bg-blue-500/10 text-blue-600 border-blue-500/30"
                          >
                            Phase 2
                          </Badge>
                        )}
                        {item.locked && <Lock className="w-3 h-3 ml-auto text-sidebar-foreground/50" />}
                      </>
                    )}
                  </Link>
                )
              })}
            </CollapsibleContent>
          </Collapsible>
        ))}
      </nav>

      {/* Sidebar Footer */}
      <div className="px-2 py-4 border-t border-sidebar-border space-y-2">
        {!collapsed && (
          <button
            onClick={() => toggleAllGroups(!Object.values(expandedGroups).every((v) => v))}
            className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground transition-colors w-full"
          >
            <ChevronsUpDown className="w-4 h-4 shrink-0" />
            <span>Toggle All</span>
          </button>
        )}

        <Link
          href="/help"
          className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground transition-colors w-full"
        >
          <HelpCircle className="w-4 h-4 shrink-0" />
          {!collapsed && <span>Help & Support</span>}
        </Link>

        <button className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground transition-colors w-full">
          <LogOut className="w-4 h-4 shrink-0" />
          {!collapsed && <span>Sign Out</span>}
        </button>

        {!collapsed && <div className="px-3 py-2 text-xs text-sidebar-foreground/50">v2.0 - Dec 2025</div>}
      </div>

      {/* Collapse Toggle */}
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-20 h-6 w-6 rounded-full border border-sidebar-border bg-sidebar text-sidebar-foreground shadow-sm hover:bg-sidebar-accent"
      >
        {collapsed ? <ChevronRight className="h-3 w-3" /> : <ChevronLeft className="h-3 w-3" />}
      </Button>
    </aside>
  )
}
