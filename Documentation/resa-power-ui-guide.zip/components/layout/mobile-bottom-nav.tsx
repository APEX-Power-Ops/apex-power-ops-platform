"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, ClipboardList, Zap, User, RefreshCw } from "lucide-react"
import { cn } from "@/lib/utils"
import { useRole } from "@/contexts/role-context"

const mobileNavItems = [
  { name: "Today", href: "/field-tech", icon: Home },
  { name: "Tasks", href: "/field-tech/tasks", icon: ClipboardList },
  { name: "Equipment", href: "/field-tech/equipment", icon: Zap },
  { name: "Sync", href: "/field-tech/sync", icon: RefreshCw },
  { name: "Profile", href: "/field-tech/profile", icon: User },
]

export function MobileBottomNav() {
  const pathname = usePathname()
  const { currentRole } = useRole()

  // Only show for field tech role
  if (currentRole !== "field-tech") {
    return null
  }

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50 md:hidden">
      <div className="flex items-center justify-around h-16">
        {mobileNavItems.map((item) => {
          const isActive = pathname === item.href
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex flex-col items-center justify-center gap-1 w-full h-full transition-colors",
                isActive ? "text-primary" : "text-muted-foreground",
              )}
            >
              <item.icon className="h-5 w-5" />
              <span className="text-xs font-medium">{item.name}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
