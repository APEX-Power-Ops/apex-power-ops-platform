"use client"

import type React from "react"
import { Sidebar } from "@/components/layout/sidebar"
import { Header } from "@/components/layout/header"
import { DemoBanner } from "@/components/layout/demo-banner"
import { MobileBottomNav } from "@/components/layout/mobile-bottom-nav"
import { useRole } from "@/contexts/role-context"

interface AppShellProps {
  children: React.ReactNode
  title: string
  subtitle?: string
}

export function AppShell({ children, title, subtitle }: AppShellProps) {
  const { currentRole } = useRole()
  const isFieldTech = currentRole === "field-tech"

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar for non-field-tech roles */}
      {!isFieldTech && <Sidebar />}

      <div className="flex-1 flex flex-col">
        <DemoBanner />
        <Header title={title} subtitle={subtitle} />

        <main className={`flex-1 p-6 ${isFieldTech ? "pb-24" : ""}`}>{children}</main>

        {/* Mobile bottom nav for field tech */}
        {isFieldTech && <MobileBottomNav />}
      </div>
    </div>
  )
}
