"use client"

import { useRole } from "@/contexts/role-context"
import { Info } from "lucide-react"

export function DemoBanner() {
  const { roleInfo } = useRole()

  try {
    return (
      <div className="bg-amber-500/10 border-b border-amber-500/20 px-4 py-2">
        <div className="flex items-center justify-center gap-2 text-sm">
          <Info className="h-4 w-4 text-amber-600" />
          <span className="text-amber-800 font-medium">DEMO MODE</span>
          <span className="text-amber-700">
            — Viewing as <strong>{roleInfo.title}</strong> ({roleInfo.name})
          </span>
        </div>
      </div>
    )
  } catch (error) {
    // If role context is not available, return null
    return null
  }
}
