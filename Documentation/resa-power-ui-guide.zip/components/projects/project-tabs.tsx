"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { OverviewTab } from "./tabs/overview-tab"
import { ScopesTab } from "./tabs/scopes-tab"
import { ApparatusTab } from "./tabs/apparatus-tab"
import { TasksTab } from "./tabs/tasks-tab"
import { FinancialsTab } from "./tabs/financials-tab"

interface Project {
  id: string
  name: string
  client: string
  status: "active" | "pending" | "completed" | "on-hold" | "cancelled"
  startDate: string
  endDate: string
  location: string
  estimator: string
  projectManager: string
  description: string
  quoted: number
  recognized: number
  remaining: number
  margin: number
  scopeCount: number
  apparatusCount: number
  taskCount: number
}

interface ProjectTabsProps {
  project: Project
}

const tabs = [
  { id: "overview", label: "Overview" },
  { id: "scopes", label: "Scopes", count: 4 },
  { id: "apparatus", label: "Apparatus", count: 12 },
  { id: "tasks", label: "Tasks", count: 28 },
  { id: "financials", label: "Financials" },
]

export function ProjectTabs({ project }: ProjectTabsProps) {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div>
      {/* Tab Navigation */}
      <div className="border-b border-border bg-card">
        <nav className="flex gap-6 px-6" aria-label="Tabs">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "py-3 text-sm font-medium border-b-2 -mb-px transition-colors",
                activeTab === tab.id
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground hover:border-border",
              )}
            >
              {tab.label}
              {tab.count !== undefined && (
                <span
                  className={cn(
                    "ml-2 px-2 py-0.5 text-xs rounded-full",
                    activeTab === tab.id ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground",
                  )}
                >
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div className="p-6">
        {activeTab === "overview" && <OverviewTab project={project} />}
        {activeTab === "scopes" && <ScopesTab />}
        {activeTab === "apparatus" && <ApparatusTab />}
        {activeTab === "tasks" && <TasksTab />}
        {activeTab === "financials" && <FinancialsTab project={project} />}
      </div>
    </div>
  )
}
