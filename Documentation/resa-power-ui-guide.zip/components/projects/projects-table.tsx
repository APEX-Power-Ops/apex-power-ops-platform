"use client"

import type React from "react"
import Link from "next/link"
import { ArrowUpDown, ArrowUp, ArrowDown, MoreHorizontal, Eye, Pencil, Copy, Archive } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Progress } from "@/components/ui/progress"
import { StatusBadge } from "@/components/dashboard/status-badge"
import { cn } from "@/lib/utils"

export interface Project {
  id: string
  projectNumber: string
  name: string
  client: string
  status: "opportunity" | "sold" | "in-progress" | "on-hold" | "complete"
  location: string
  startDate: string
  revenue: number
  progress: number
}

interface ProjectsTableProps {
  projects: Project[]
  selectedProjects: string[]
  onSelectProject: (id: string) => void
  onSelectAll: (selected: boolean) => void
  sortConfig: { key: string; direction: "asc" | "desc" }
  onSort: (key: string) => void
}

type SortField = "projectNumber" | "name" | "client" | "status" | "location" | "startDate" | "revenue" | "progress"

export function ProjectsTable({
  projects = [],
  selectedProjects = [],
  onSelectProject,
  onSelectAll,
  sortConfig,
  onSort,
}: ProjectsTableProps) {
  const sortField = sortConfig.key as SortField
  const sortDirection = sortConfig.direction

  const sortedProjects = [...(projects || [])].sort((a, b) => {
    if (!sortField) return 0
    const multiplier = sortDirection === "asc" ? 1 : -1
    const aValue = a[sortField]
    const bValue = b[sortField]

    if (typeof aValue === "string" && typeof bValue === "string") {
      return aValue.localeCompare(bValue) * multiplier
    }
    if (typeof aValue === "number" && typeof bValue === "number") {
      return (aValue - bValue) * multiplier
    }
    return 0
  })

  const toggleAll = () => {
    onSelectAll(selectedProjects.length !== projects.length)
  }

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) {
      return <ArrowUpDown className="ml-1 h-4 w-4 text-muted-foreground/50" />
    }
    return sortDirection === "asc" ? <ArrowUp className="ml-1 h-4 w-4" /> : <ArrowDown className="ml-1 h-4 w-4" />
  }

  const SortableHeader = ({
    field,
    children,
    className,
  }: { field: SortField; children: React.ReactNode; className?: string }) => (
    <TableHead className={className}>
      <button className="flex items-center hover:text-foreground transition-colors" onClick={() => onSort(field)}>
        {children}
        <SortIcon field={field} />
      </button>
    </TableHead>
  )

  return (
    <div className="border rounded-lg overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="w-12">
              <Checkbox
                checked={selectedProjects.length === projects.length && projects.length > 0}
                onCheckedChange={toggleAll}
              />
            </TableHead>
            <SortableHeader field="projectNumber">Project #</SortableHeader>
            <SortableHeader field="name">Name</SortableHeader>
            <SortableHeader field="client">Client</SortableHeader>
            <SortableHeader field="status">Status</SortableHeader>
            <SortableHeader field="location">Location</SortableHeader>
            <SortableHeader field="startDate">Start Date</SortableHeader>
            <SortableHeader field="revenue" className="text-right">
              Revenue
            </SortableHeader>
            <SortableHeader field="progress">Progress</SortableHeader>
            <TableHead className="w-12"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedProjects.map((project) => (
            <TableRow
              key={project.id}
              className={cn(
                "cursor-pointer hover:bg-muted/50 transition-colors",
                selectedProjects.includes(project.id) && "bg-primary/5",
              )}
            >
              <TableCell onClick={(e) => e.stopPropagation()}>
                <Checkbox
                  checked={selectedProjects.includes(project.id)}
                  onCheckedChange={() => onSelectProject(project.id)}
                />
              </TableCell>
              <TableCell className="font-mono text-sm">{project.projectNumber}</TableCell>
              <TableCell>
                <Link href={`/projects/${project.id}`} className="font-medium text-primary hover:underline">
                  {project.name}
                </Link>
              </TableCell>
              <TableCell>{project.client}</TableCell>
              <TableCell>
                <StatusBadge status={project.status} />
              </TableCell>
              <TableCell className="text-muted-foreground">{project.location}</TableCell>
              <TableCell className="text-muted-foreground">{project.startDate}</TableCell>
              <TableCell className="text-right font-medium">${project.revenue.toLocaleString()}</TableCell>
              <TableCell>
                <div className="flex items-center gap-2 min-w-[120px]">
                  <Progress value={project.progress} className="h-2 flex-1" />
                  <span className="text-xs text-muted-foreground w-8">{project.progress}%</span>
                </div>
              </TableCell>
              <TableCell onClick={(e) => e.stopPropagation()}>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem asChild>
                      <Link href={`/projects/${project.id}`}>
                        <Eye className="mr-2 h-4 w-4" />
                        View
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Pencil className="mr-2 h-4 w-4" />
                      Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Copy className="mr-2 h-4 w-4" />
                      Duplicate
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-status-error">
                      <Archive className="mr-2 h-4 w-4" />
                      Archive
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
