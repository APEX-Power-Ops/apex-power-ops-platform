"use client"

import { useState } from "react"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Plus, Trash2 } from "lucide-react"

const scopeTypes = [
  { id: "testing", name: "Testing" },
  { id: "engineering", name: "Engineering" },
  { id: "emergency", name: "Emergency" },
  { id: "thermal", name: "Thermal" },
  { id: "commissioning", name: "Commissioning" },
  { id: "maintenance", name: "Maintenance" },
]

interface Scope {
  id: string
  name: string
  type: string
  revenueType: "time-materials" | "fixed-fee"
  quotedAmount?: number
}

interface StepInitialScopeProps {
  data: {
    scopes: Scope[]
  }
  onChange: (data: { scopes: Scope[] }) => void
  errors: Record<string, string>
}

export function StepInitialScope({ data, onChange, errors }: StepInitialScopeProps) {
  const [currentScope, setCurrentScope] = useState<Partial<Scope>>({
    name: "",
    type: "",
    revenueType: "time-materials",
    quotedAmount: undefined,
  })

  const addScope = () => {
    if (!currentScope.name || !currentScope.type) return

    const newScope: Scope = {
      id: Date.now().toString(),
      name: currentScope.name,
      type: currentScope.type,
      revenueType: currentScope.revenueType || "time-materials",
      quotedAmount: currentScope.quotedAmount,
    }

    onChange({ scopes: [...data.scopes, newScope] })
    setCurrentScope({
      name: "",
      type: "",
      revenueType: "time-materials",
      quotedAmount: undefined,
    })
  }

  const removeScope = (id: string) => {
    onChange({ scopes: data.scopes.filter((s) => s.id !== id) })
  }

  return (
    <div className="space-y-6">
      <div className="rounded-lg border bg-muted/30 p-4">
        <h4 className="mb-4 text-sm font-medium">Add Scope</h4>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="scopeName" className="text-sm font-medium">
              Scope Name
            </Label>
            <Input
              id="scopeName"
              value={currentScope.name}
              onChange={(e) => setCurrentScope({ ...currentScope, name: e.target.value })}
              placeholder="e.g., Substation Testing Phase 1"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="scopeType" className="text-sm font-medium">
              Scope Type
            </Label>
            <Select
              value={currentScope.type}
              onValueChange={(value) => setCurrentScope({ ...currentScope, type: value })}
            >
              <SelectTrigger id="scopeType">
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                {scopeTypes.map((type) => (
                  <SelectItem key={type.id} value={type.id}>
                    {type.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="mt-4 space-y-2">
          <Label className="text-sm font-medium">Revenue Type</Label>
          <div className="flex gap-2">
            <Button
              type="button"
              variant={currentScope.revenueType === "time-materials" ? "default" : "outline"}
              size="sm"
              onClick={() =>
                setCurrentScope({ ...currentScope, revenueType: "time-materials", quotedAmount: undefined })
              }
            >
              Time & Materials
            </Button>
            <Button
              type="button"
              variant={currentScope.revenueType === "fixed-fee" ? "default" : "outline"}
              size="sm"
              onClick={() => setCurrentScope({ ...currentScope, revenueType: "fixed-fee" })}
            >
              Fixed Fee
            </Button>
          </div>
        </div>

        {currentScope.revenueType === "fixed-fee" && (
          <div className="mt-4 space-y-2">
            <Label htmlFor="quotedAmount" className="text-sm font-medium">
              Quoted Amount
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
              <Input
                id="quotedAmount"
                type="number"
                value={currentScope.quotedAmount || ""}
                onChange={(e) =>
                  setCurrentScope({ ...currentScope, quotedAmount: Number.parseFloat(e.target.value) || undefined })
                }
                placeholder="0.00"
                className="pl-7"
              />
            </div>
          </div>
        )}

        <Button
          type="button"
          variant="secondary"
          className="mt-4"
          onClick={addScope}
          disabled={!currentScope.name || !currentScope.type}
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Scope
        </Button>
      </div>

      {errors.scopes && <p className="text-sm text-destructive">{errors.scopes}</p>}

      {data.scopes.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-sm font-medium">Added Scopes ({data.scopes.length})</h4>
          {data.scopes.map((scope) => (
            <Card key={scope.id}>
              <CardContent className="flex items-center justify-between p-4">
                <div className="flex-1">
                  <p className="font-medium">{scope.name}</p>
                  <div className="mt-1 flex items-center gap-3 text-sm text-muted-foreground">
                    <span className="capitalize">
                      {scopeTypes.find((t) => t.id === scope.type)?.name || scope.type}
                    </span>
                    <span>•</span>
                    <span>
                      {scope.revenueType === "fixed-fee"
                        ? `Fixed Fee - $${scope.quotedAmount?.toLocaleString() || 0}`
                        : "Time & Materials"}
                    </span>
                  </div>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => removeScope(scope.id)}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {data.scopes.length === 0 && (
        <div className="rounded-lg border border-dashed p-8 text-center">
          <p className="text-muted-foreground">No scopes added yet. Add at least one scope to continue.</p>
        </div>
      )}
    </div>
  )
}
