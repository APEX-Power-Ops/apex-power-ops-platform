"use client"

import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

const clients = [
  { id: "1", name: "Duke Energy" },
  { id: "2", name: "Southern California Edison" },
  { id: "3", name: "Pacific Gas & Electric" },
  { id: "4", name: "Florida Power & Light" },
  { id: "5", name: "Xcel Energy" },
]

interface StepClientBasicsProps {
  data: {
    clientId: string
    projectName: string
    description: string
    isOpportunity: boolean
  }
  onChange: (data: Partial<StepClientBasicsProps["data"]>) => void
  errors: Record<string, string>
}

export function StepClientBasics({ data, onChange, errors }: StepClientBasicsProps) {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="client" className="text-sm font-medium">
          Client <span className="text-destructive">*</span>
        </Label>
        <Select value={data.clientId} onValueChange={(value) => onChange({ clientId: value })}>
          <SelectTrigger id="client" className={errors.clientId ? "border-destructive" : ""}>
            <SelectValue placeholder="Select a client" />
          </SelectTrigger>
          <SelectContent>
            {clients.map((client) => (
              <SelectItem key={client.id} value={client.id}>
                {client.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.clientId && <p className="text-sm text-destructive">{errors.clientId}</p>}
        <Button variant="link" size="sm" className="h-auto p-0 text-primary">
          <Plus className="mr-1 h-3 w-3" />
          New Client
        </Button>
      </div>

      <div className="space-y-2">
        <Label htmlFor="projectName" className="text-sm font-medium">
          Project Name <span className="text-destructive">*</span>
        </Label>
        <Input
          id="projectName"
          value={data.projectName}
          onChange={(e) => onChange({ projectName: e.target.value })}
          placeholder="Enter project name"
          className={errors.projectName ? "border-destructive" : ""}
        />
        {errors.projectName && <p className="text-sm text-destructive">{errors.projectName}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="description" className="text-sm font-medium">
          Description
        </Label>
        <Textarea
          id="description"
          value={data.description}
          onChange={(e) => onChange({ description: e.target.value })}
          placeholder="Enter project description (optional)"
          rows={4}
        />
      </div>

      <div className="flex items-center space-x-2">
        <Checkbox
          id="isOpportunity"
          checked={data.isOpportunity}
          onCheckedChange={(checked) => onChange({ isOpportunity: checked as boolean })}
        />
        <Label htmlFor="isOpportunity" className="text-sm font-normal cursor-pointer">
          This is an opportunity (not yet sold)
        </Label>
      </div>
    </div>
  )
}
