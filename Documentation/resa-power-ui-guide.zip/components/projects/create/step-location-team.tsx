"use client"

import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Plus, CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"

const sites = [
  { id: "1", name: "Duke Energy - Charlotte Main", clientId: "1" },
  { id: "2", name: "Duke Energy - Raleigh Plant", clientId: "1" },
  { id: "3", name: "SCE - Los Angeles HQ", clientId: "2" },
  { id: "4", name: "PG&E - San Francisco Office", clientId: "3" },
]

const resaLocations = [
  { id: "phoenix", name: "Phoenix" },
  { id: "las-vegas", name: "Las Vegas" },
  { id: "denver", name: "Denver" },
  { id: "san-diego", name: "San Diego" },
]

const teamMembers = [
  { id: "1", name: "Michael Chen", role: "estimator" },
  { id: "2", name: "Sarah Johnson", role: "estimator" },
  { id: "3", name: "David Martinez", role: "pm" },
  { id: "4", name: "Emily Brown", role: "pm" },
  { id: "5", name: "James Wilson", role: "pm" },
]

interface StepLocationTeamProps {
  data: {
    siteId: string
    resaLocation: string
    estimatorId: string
    projectManagerId: string
    startDate: Date | undefined
    endDate: Date | undefined
  }
  clientId: string
  onChange: (data: Partial<StepLocationTeamProps["data"]>) => void
  errors: Record<string, string>
}

export function StepLocationTeam({ data, clientId, onChange, errors }: StepLocationTeamProps) {
  const filteredSites = sites.filter((site) => site.clientId === clientId)
  const estimators = teamMembers.filter((m) => m.role === "estimator")
  const projectManagers = teamMembers.filter((m) => m.role === "pm")

  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="site" className="text-sm font-medium">
            Site <span className="text-destructive">*</span>
          </Label>
          <Select value={data.siteId} onValueChange={(value) => onChange({ siteId: value })}>
            <SelectTrigger id="site" className={errors.siteId ? "border-destructive" : ""}>
              <SelectValue placeholder="Select a site" />
            </SelectTrigger>
            <SelectContent>
              {filteredSites.length > 0 ? (
                filteredSites.map((site) => (
                  <SelectItem key={site.id} value={site.id}>
                    {site.name}
                  </SelectItem>
                ))
              ) : (
                <SelectItem value="none" disabled>
                  No sites for this client
                </SelectItem>
              )}
            </SelectContent>
          </Select>
          {errors.siteId && <p className="text-sm text-destructive">{errors.siteId}</p>}
          <Button variant="link" size="sm" className="h-auto p-0 text-primary">
            <Plus className="mr-1 h-3 w-3" />
            New Site
          </Button>
        </div>

        <div className="space-y-2">
          <Label htmlFor="resaLocation" className="text-sm font-medium">
            RESA Location <span className="text-destructive">*</span>
          </Label>
          <Select value={data.resaLocation} onValueChange={(value) => onChange({ resaLocation: value })}>
            <SelectTrigger id="resaLocation" className={errors.resaLocation ? "border-destructive" : ""}>
              <SelectValue placeholder="Select location" />
            </SelectTrigger>
            <SelectContent>
              {resaLocations.map((location) => (
                <SelectItem key={location.id} value={location.id}>
                  {location.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.resaLocation && <p className="text-sm text-destructive">{errors.resaLocation}</p>}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="estimator" className="text-sm font-medium">
            Estimator
          </Label>
          <Select value={data.estimatorId} onValueChange={(value) => onChange({ estimatorId: value })}>
            <SelectTrigger id="estimator">
              <SelectValue placeholder="Select estimator" />
            </SelectTrigger>
            <SelectContent>
              {estimators.map((member) => (
                <SelectItem key={member.id} value={member.id}>
                  {member.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="projectManager" className="text-sm font-medium">
            Project Manager
          </Label>
          <Select value={data.projectManagerId} onValueChange={(value) => onChange({ projectManagerId: value })}>
            <SelectTrigger id="projectManager">
              <SelectValue placeholder="Select project manager" />
            </SelectTrigger>
            <SelectContent>
              {projectManagers.map((member) => (
                <SelectItem key={member.id} value={member.id}>
                  {member.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-2">
          <Label className="text-sm font-medium">Start Date</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn("w-full justify-start text-left font-normal", !data.startDate && "text-muted-foreground")}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {data.startDate ? format(data.startDate, "PPP") : "Select date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={data.startDate}
                onSelect={(date) => onChange({ startDate: date })}
                initialFocus
              />
            </PopoverContent>
          </Popover>
        </div>

        <div className="space-y-2">
          <Label className="text-sm font-medium">Expected End Date</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn("w-full justify-start text-left font-normal", !data.endDate && "text-muted-foreground")}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {data.endDate ? format(data.endDate, "PPP") : "Select date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={data.endDate}
                onSelect={(date) => onChange({ endDate: date })}
                initialFocus
                disabled={(date) => (data.startDate ? date < data.startDate : false)}
              />
            </PopoverContent>
          </Popover>
        </div>
      </div>
    </div>
  )
}
