"use client"

import { useState } from "react"
import { Search, X, Calendar } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import type { DateRange } from "react-day-picker"

interface ProjectsFiltersProps {
  onFiltersChange: (filters: FilterState) => void
}

export interface FilterState {
  search: string
  status: string
  client: string
  location: string
  dateRange: DateRange | undefined
}

const clients = [
  "All Clients",
  "Austin Energy",
  "Tesla Gigafactory",
  "Samsung Austin",
  "Applied Materials",
  "NXP Semiconductors",
  "Dell Technologies",
]

const locations = ["All Locations", "Phoenix, AZ", "Las Vegas, NV", "Denver, CO", "San Diego, CA"]

export function ProjectsFilters({ onFiltersChange }: ProjectsFiltersProps) {
  const [filters, setFilters] = useState<FilterState>({
    search: "",
    status: "all",
    client: "all",
    location: "all",
    dateRange: undefined,
  })

  const updateFilters = (key: keyof FilterState, value: string | DateRange | undefined) => {
    const newFilters = { ...filters, [key]: value }
    setFilters(newFilters)
    onFiltersChange(newFilters)
  }

  const clearFilters = () => {
    const clearedFilters: FilterState = {
      search: "",
      status: "all",
      client: "all",
      location: "all",
      dateRange: undefined,
    }
    setFilters(clearedFilters)
    onFiltersChange(clearedFilters)
  }

  const hasActiveFilters =
    filters.search ||
    filters.status !== "all" ||
    filters.client !== "all" ||
    filters.location !== "all" ||
    filters.dateRange

  return (
    <div className="flex flex-wrap items-center gap-3">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search projects..."
          value={filters.search}
          onChange={(e) => updateFilters("search", e.target.value)}
          className="pl-9 w-64"
        />
      </div>

      <Select value={filters.status} onValueChange={(v) => updateFilters("status", v)}>
        <SelectTrigger className="w-40">
          <SelectValue placeholder="Status" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Statuses</SelectItem>
          <SelectItem value="opportunity">Opportunity</SelectItem>
          <SelectItem value="sold">Sold</SelectItem>
          <SelectItem value="in-progress">In Progress</SelectItem>
          <SelectItem value="on-hold">On Hold</SelectItem>
          <SelectItem value="complete">Complete</SelectItem>
        </SelectContent>
      </Select>

      <Select value={filters.client} onValueChange={(v) => updateFilters("client", v)}>
        <SelectTrigger className="w-44">
          <SelectValue placeholder="Client" />
        </SelectTrigger>
        <SelectContent>
          {clients.map((client) => (
            <SelectItem key={client} value={client === "All Clients" ? "all" : client}>
              {client}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select value={filters.location} onValueChange={(v) => updateFilters("location", v)}>
        <SelectTrigger className="w-40">
          <SelectValue placeholder="Location" />
        </SelectTrigger>
        <SelectContent>
          {locations.map((location) => (
            <SelectItem key={location} value={location === "All Locations" ? "all" : location}>
              {location}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className={cn("w-56 justify-start text-left font-normal", !filters.dateRange && "text-muted-foreground")}
          >
            <Calendar className="mr-2 h-4 w-4" />
            {filters.dateRange?.from ? (
              filters.dateRange.to ? (
                <>
                  {format(filters.dateRange.from, "MMM d")} - {format(filters.dateRange.to, "MMM d, yyyy")}
                </>
              ) : (
                format(filters.dateRange.from, "MMM d, yyyy")
              )
            ) : (
              "Date range"
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <CalendarComponent
            initialFocus
            mode="range"
            defaultMonth={filters.dateRange?.from}
            selected={filters.dateRange}
            onSelect={(range) => updateFilters("dateRange", range)}
            numberOfMonths={2}
          />
        </PopoverContent>
      </Popover>

      {hasActiveFilters && (
        <Button variant="ghost" onClick={clearFilters} className="text-muted-foreground">
          <X className="mr-1 h-4 w-4" />
          Clear Filters
        </Button>
      )}
    </div>
  )
}
