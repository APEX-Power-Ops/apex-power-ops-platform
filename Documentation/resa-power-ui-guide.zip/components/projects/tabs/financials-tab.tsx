import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { TrendingUp, TrendingDown, DollarSign, Target } from "lucide-react"

interface Project {
  quoted: number
  recognized: number
  remaining: number
  margin: number
}

interface FinancialsTabProps {
  project: Project
}

const scopeFinancials = [
  { name: "Switchgear Testing", quoted: 125000, recognized: 95000, costs: 64000, margin: 32.6 },
  { name: "Protective Relay Coordination", quoted: 180000, recognized: 108000, costs: 72000, margin: 33.3 },
  { name: "Transformer Testing", quoted: 95000, recognized: 0, costs: 0, margin: 0 },
  { name: "Acceptance Testing", quoted: 85000, recognized: 84500, costs: 58000, margin: 31.4 },
]

export function FinancialsTab({ project }: FinancialsTabProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const totalCosts = scopeFinancials.reduce((sum, s) => sum + s.costs, 0)
  const grossProfit = project.recognized - totalCosts

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Target className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Quoted</p>
                <p className="text-xl font-semibold text-foreground">{formatCurrency(project.quoted)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-status-success/10">
                <DollarSign className="w-5 h-5 text-status-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Revenue Recognized</p>
                <p className="text-xl font-semibold text-status-success">{formatCurrency(project.recognized)}</p>
              </div>
            </div>
            <Progress value={(project.recognized / project.quoted) * 100} className="h-1.5 mt-3" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-status-info/10">
                <TrendingUp className="w-5 h-5 text-status-info" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Gross Profit</p>
                <p className="text-xl font-semibold text-status-info">{formatCurrency(grossProfit)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-status-warning/10">
                <TrendingDown className="w-5 h-5 text-status-warning" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Costs</p>
                <p className="text-xl font-semibold text-status-warning">{formatCurrency(totalCosts)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Revenue Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Revenue Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Recognition Progress</span>
              <span className="font-medium">{Math.round((project.recognized / project.quoted) * 100)}%</span>
            </div>
            <div className="relative h-4 bg-muted rounded-full overflow-hidden">
              <div
                className="absolute left-0 top-0 h-full bg-status-success rounded-full"
                style={{ width: `${(project.recognized / project.quoted) * 100}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-xs text-muted-foreground pt-1">
              <span>{formatCurrency(project.recognized)} recognized</span>
              <span>{formatCurrency(project.remaining)} remaining</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Scope Breakdown Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Scope-by-Scope Breakdown</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Scope</TableHead>
                <TableHead className="text-right">Quoted</TableHead>
                <TableHead className="text-right">Recognized</TableHead>
                <TableHead className="text-right">Costs</TableHead>
                <TableHead className="text-right">Margin %</TableHead>
                <TableHead className="w-32">Progress</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {scopeFinancials.map((scope) => (
                <TableRow key={scope.name}>
                  <TableCell className="font-medium">{scope.name}</TableCell>
                  <TableCell className="text-right">{formatCurrency(scope.quoted)}</TableCell>
                  <TableCell className="text-right text-status-success">{formatCurrency(scope.recognized)}</TableCell>
                  <TableCell className="text-right text-status-warning">{formatCurrency(scope.costs)}</TableCell>
                  <TableCell className="text-right">{scope.margin > 0 ? `${scope.margin.toFixed(1)}%` : "—"}</TableCell>
                  <TableCell>
                    <Progress value={scope.quoted > 0 ? (scope.recognized / scope.quoted) * 100 : 0} className="h-2" />
                  </TableCell>
                </TableRow>
              ))}
              {/* Totals Row */}
              <TableRow className="bg-muted/50 font-semibold">
                <TableCell>Total</TableCell>
                <TableCell className="text-right">{formatCurrency(project.quoted)}</TableCell>
                <TableCell className="text-right text-status-success">{formatCurrency(project.recognized)}</TableCell>
                <TableCell className="text-right text-status-warning">{formatCurrency(totalCosts)}</TableCell>
                <TableCell className="text-right">{project.margin}%</TableCell>
                <TableCell>
                  <Progress value={(project.recognized / project.quoted) * 100} className="h-2" />
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
