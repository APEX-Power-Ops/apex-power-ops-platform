"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { StatusBadge } from "@/components/dashboard/status-badge"
import { Plus, ChevronDown, ChevronRight, CheckCircle2, Circle } from "lucide-react"

const scopes = [
  {
    id: 1,
    name: "Switchgear Testing",
    type: "Medium Voltage",
    status: "active" as const,
    revenue: 125000,
    recognized: 95000,
    progress: 76,
    tasks: [
      { id: 1, name: "Visual inspection", completed: true },
      { id: 2, name: "Insulation resistance test", completed: true },
      { id: 3, name: "Contact resistance test", completed: true },
      { id: 4, name: "Primary injection test", completed: false },
      { id: 5, name: "Secondary injection test", completed: false },
    ],
  },
  {
    id: 2,
    name: "Protective Relay Coordination",
    type: "Protection",
    status: "active" as const,
    revenue: 180000,
    recognized: 108000,
    progress: 60,
    tasks: [
      { id: 1, name: "Relay settings review", completed: true },
      { id: 2, name: "Coordination study", completed: true },
      { id: 3, name: "Relay testing", completed: false },
      { id: 4, name: "Documentation", completed: false },
    ],
  },
  {
    id: 3,
    name: "Transformer Testing",
    type: "Power Equipment",
    status: "pending" as const,
    revenue: 95000,
    recognized: 0,
    progress: 0,
    tasks: [
      { id: 1, name: "Turns ratio test", completed: false },
      { id: 2, name: "Winding resistance test", completed: false },
      { id: 3, name: "Insulation power factor test", completed: false },
    ],
  },
  {
    id: 4,
    name: "Acceptance Testing",
    type: "Commissioning",
    status: "pending" as const,
    revenue: 85000,
    recognized: 0,
    progress: 0,
    tasks: [
      { id: 1, name: "Functional testing", completed: false },
      { id: 2, name: "Load testing", completed: false },
      { id: 3, name: "Final documentation", completed: false },
    ],
  },
]

export function ScopesTab() {
  const [expandedScopes, setExpandedScopes] = useState<number[]>([1])

  const toggleScope = (scopeId: number) => {
    setExpandedScopes((prev) => (prev.includes(scopeId) ? prev.filter((id) => id !== scopeId) : [...prev, scopeId]))
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Project Scopes</h2>
          <p className="text-sm text-muted-foreground">4 scopes with 15 total tasks</p>
        </div>
        <Button size="sm">
          <Plus className="w-4 h-4 mr-2" />
          Add Scope
        </Button>
      </div>

      {/* Scopes List */}
      <div className="space-y-3">
        {scopes.map((scope) => {
          const isExpanded = expandedScopes.includes(scope.id)
          const completedTasks = scope.tasks.filter((t) => t.completed).length

          return (
            <Card key={scope.id}>
              <CardContent className="p-0">
                {/* Scope Header */}
                <button
                  onClick={() => toggleScope(scope.id)}
                  className="w-full p-4 flex items-center gap-4 text-left hover:bg-muted/50 transition-colors"
                >
                  {isExpanded ? (
                    <ChevronDown className="w-5 h-5 text-muted-foreground shrink-0" />
                  ) : (
                    <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0" />
                  )}

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-medium text-foreground">{scope.name}</h3>
                      <StatusBadge status={scope.status} />
                    </div>
                    <p className="text-sm text-muted-foreground">{scope.type}</p>
                  </div>

                  <div className="text-right shrink-0">
                    <p className="text-sm font-medium text-foreground">{formatCurrency(scope.revenue)}</p>
                    <p className="text-xs text-muted-foreground">{formatCurrency(scope.recognized)} recognized</p>
                  </div>

                  <div className="w-32 shrink-0">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-muted-foreground">Progress</span>
                      <span className="font-medium">{scope.progress}%</span>
                    </div>
                    <Progress value={scope.progress} className="h-2" />
                  </div>
                </button>

                {/* Expanded Tasks */}
                {isExpanded && (
                  <div className="border-t border-border px-4 py-3 bg-muted/30">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
                      Tasks ({completedTasks}/{scope.tasks.length} completed)
                    </p>
                    <div className="space-y-2">
                      {scope.tasks.map((task) => (
                        <div key={task.id} className="flex items-center gap-3 py-1.5 px-2 rounded hover:bg-muted/50">
                          {task.completed ? (
                            <CheckCircle2 className="w-4 h-4 text-status-success" />
                          ) : (
                            <Circle className="w-4 h-4 text-muted-foreground" />
                          )}
                          <span
                            className={
                              task.completed ? "text-sm text-muted-foreground line-through" : "text-sm text-foreground"
                            }
                          >
                            {task.name}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
