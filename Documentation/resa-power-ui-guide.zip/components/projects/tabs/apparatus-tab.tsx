"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { StatusBadge } from "@/components/dashboard/status-badge"
import { Plus, Search, LayoutGrid, List } from "lucide-react"

const apparatus = [
  {
    id: 1,
    type: "Switchgear",
    manufacturer: "ABB",
    model: "UniGear ZS1",
    serial: "SG-2024-001",
    status: "completed" as const,
    lastTest: "2024-01-20",
  },
  {
    id: 2,
    type: "Switchgear",
    manufacturer: "Siemens",
    model: "8DA10",
    serial: "SG-2024-002",
    status: "active" as const,
    lastTest: "2024-01-18",
  },
  {
    id: 3,
    type: "Transformer",
    manufacturer: "GE",
    model: "Prolec",
    serial: "TF-2024-001",
    status: "pending" as const,
    lastTest: null,
  },
  {
    id: 4,
    type: "Transformer",
    manufacturer: "ABB",
    model: "TraxStar",
    serial: "TF-2024-002",
    status: "pending" as const,
    lastTest: null,
  },
  {
    id: 5,
    type: "Relay",
    manufacturer: "SEL",
    model: "SEL-751",
    serial: "RL-2024-001",
    status: "completed" as const,
    lastTest: "2024-01-15",
  },
  {
    id: 6,
    type: "Relay",
    manufacturer: "SEL",
    model: "SEL-751",
    serial: "RL-2024-002",
    status: "completed" as const,
    lastTest: "2024-01-15",
  },
  {
    id: 7,
    type: "Relay",
    manufacturer: "GE",
    model: "Multilin 750",
    serial: "RL-2024-003",
    status: "active" as const,
    lastTest: "2024-01-19",
  },
  {
    id: 8,
    type: "Circuit Breaker",
    manufacturer: "ABB",
    model: "VD4",
    serial: "CB-2024-001",
    status: "active" as const,
    lastTest: "2024-01-19",
  },
  {
    id: 9,
    type: "Circuit Breaker",
    manufacturer: "Siemens",
    model: "3AH5",
    serial: "CB-2024-002",
    status: "pending" as const,
    lastTest: null,
  },
  {
    id: 10,
    type: "Cable",
    manufacturer: "Southwire",
    model: "15kV EPR",
    serial: "CA-2024-001",
    status: "completed" as const,
    lastTest: "2024-01-12",
  },
  {
    id: 11,
    type: "Cable",
    manufacturer: "Southwire",
    model: "15kV EPR",
    serial: "CA-2024-002",
    status: "completed" as const,
    lastTest: "2024-01-12",
  },
  {
    id: 12,
    type: "Motor",
    manufacturer: "WEG",
    model: "W22 Premium",
    serial: "MT-2024-001",
    status: "pending" as const,
    lastTest: null,
  },
]

export function ApparatusTab() {
  const [viewMode, setViewMode] = useState<"table" | "grid">("table")
  const [searchQuery, setSearchQuery] = useState("")
  const [typeFilter, setTypeFilter] = useState("all")

  const filteredApparatus = apparatus.filter((item) => {
    const matchesSearch =
      item.serial.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.manufacturer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.model.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = typeFilter === "all" || item.type === typeFilter
    return matchesSearch && matchesType
  })

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "—"
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  const equipmentTypes = [...new Set(apparatus.map((a) => a.type))]

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Apparatus</h2>
          <p className="text-sm text-muted-foreground">12 pieces of equipment</p>
        </div>
        <Button size="sm">
          <Plus className="w-4 h-4 mr-2" />
          Add Apparatus
        </Button>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search by serial, manufacturer, model..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            {equipmentTypes.map((type) => (
              <SelectItem key={type} value={type}>
                {type}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex items-center border rounded-lg p-0.5">
          <Button
            variant={viewMode === "table" ? "secondary" : "ghost"}
            size="sm"
            className="h-8 px-2"
            onClick={() => setViewMode("table")}
          >
            <List className="w-4 h-4" />
          </Button>
          <Button
            variant={viewMode === "grid" ? "secondary" : "ghost"}
            size="sm"
            className="h-8 px-2"
            onClick={() => setViewMode("grid")}
          >
            <LayoutGrid className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Table View */}
      {viewMode === "table" && (
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Type</TableHead>
                <TableHead>Manufacturer</TableHead>
                <TableHead>Model</TableHead>
                <TableHead>Serial #</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Test</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredApparatus.map((item) => (
                <TableRow key={item.id} className="cursor-pointer hover:bg-muted/50">
                  <TableCell className="font-medium">{item.type}</TableCell>
                  <TableCell>{item.manufacturer}</TableCell>
                  <TableCell>{item.model}</TableCell>
                  <TableCell className="font-mono text-sm">{item.serial}</TableCell>
                  <TableCell>
                    <StatusBadge status={item.status} />
                  </TableCell>
                  <TableCell className="text-muted-foreground">{formatDate(item.lastTest)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}

      {/* Grid View */}
      {viewMode === "grid" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredApparatus.map((item) => (
            <Card key={item.id} className="cursor-pointer hover:shadow-md transition-shadow">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-base">{item.type}</CardTitle>
                  <StatusBadge status={item.status} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Manufacturer</span>
                    <span className="font-medium">{item.manufacturer}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Model</span>
                    <span className="font-medium">{item.model}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Serial #</span>
                    <span className="font-mono">{item.serial}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Last Test</span>
                    <span>{formatDate(item.lastTest)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
