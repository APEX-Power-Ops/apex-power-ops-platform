"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Plus, List, Columns3 } from "lucide-react"
import { cn } from "@/lib/utils"

type TaskStatus = "todo" | "in-progress" | "review" | "completed"

interface Task {
  id: number
  title: string
  scope: string
  assignee: { name: string; avatar?: string }
  dueDate: string
  status: TaskStatus
  priority: "low" | "medium" | "high"
}

const tasks: Task[] = [
  {
    id: 1,
    title: "Complete visual inspection - SG-001",
    scope: "Switchgear Testing",
    assignee: { name: "John Smith" },
    dueDate: "2024-01-25",
    status: "completed",
    priority: "high",
  },
  {
    id: 2,
    title: "Insulation resistance test - SG-001",
    scope: "Switchgear Testing",
    assignee: { name: "John Smith" },
    dueDate: "2024-01-26",
    status: "completed",
    priority: "high",
  },
  {
    id: 3,
    title: "Contact resistance test - SG-002",
    scope: "Switchgear Testing",
    assignee: { name: "Sarah Lee" },
    dueDate: "2024-01-27",
    status: "in-progress",
    priority: "high",
  },
  {
    id: 4,
    title: "Primary injection test - SG-001",
    scope: "Switchgear Testing",
    assignee: { name: "John Smith" },
    dueDate: "2024-01-28",
    status: "in-progress",
    priority: "medium",
  },
  {
    id: 5,
    title: "Review relay settings",
    scope: "Protective Relay",
    assignee: { name: "Mike Chen" },
    dueDate: "2024-01-29",
    status: "review",
    priority: "high",
  },
  {
    id: 6,
    title: "Coordination study update",
    scope: "Protective Relay",
    assignee: { name: "Mike Chen" },
    dueDate: "2024-01-30",
    status: "in-progress",
    priority: "medium",
  },
  {
    id: 7,
    title: "Test SEL-751 relay bank",
    scope: "Protective Relay",
    assignee: { name: "Sarah Lee" },
    dueDate: "2024-02-01",
    status: "todo",
    priority: "medium",
  },
  {
    id: 8,
    title: "Document test results",
    scope: "Protective Relay",
    assignee: { name: "John Smith" },
    dueDate: "2024-02-02",
    status: "todo",
    priority: "low",
  },
  {
    id: 9,
    title: "Transformer turns ratio test",
    scope: "Transformer Testing",
    assignee: { name: "Sarah Lee" },
    dueDate: "2024-02-05",
    status: "todo",
    priority: "high",
  },
  {
    id: 10,
    title: "Winding resistance measurement",
    scope: "Transformer Testing",
    assignee: { name: "John Smith" },
    dueDate: "2024-02-06",
    status: "todo",
    priority: "medium",
  },
]

const columns: { id: TaskStatus; title: string; color: string }[] = [
  { id: "todo", title: "To Do", color: "bg-muted" },
  { id: "in-progress", title: "In Progress", color: "bg-status-info" },
  { id: "review", title: "Review", color: "bg-status-warning" },
  { id: "completed", title: "Completed", color: "bg-status-success" },
]

const priorityStyles = {
  low: "bg-muted text-muted-foreground",
  medium: "bg-status-warning/10 text-status-warning",
  high: "bg-status-error/10 text-status-error",
}

export function TasksTab() {
  const [viewMode, setViewMode] = useState<"kanban" | "list">("kanban")

  const getTasksByStatus = (status: TaskStatus) => tasks.filter((t) => t.status === status)

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    })
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Tasks</h2>
          <p className="text-sm text-muted-foreground">28 tasks across 4 scopes</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center border rounded-lg p-0.5">
            <Button
              variant={viewMode === "kanban" ? "secondary" : "ghost"}
              size="sm"
              className="h-8 px-2"
              onClick={() => setViewMode("kanban")}
            >
              <Columns3 className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "secondary" : "ghost"}
              size="sm"
              className="h-8 px-2"
              onClick={() => setViewMode("list")}
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
          <Button size="sm">
            <Plus className="w-4 h-4 mr-2" />
            Add Task
          </Button>
        </div>
      </div>

      {/* Kanban View */}
      {viewMode === "kanban" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {columns.map((column) => {
            const columnTasks = getTasksByStatus(column.id)
            return (
              <div key={column.id} className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className={cn("w-2 h-2 rounded-full", column.color)} />
                  <h3 className="font-medium text-foreground">{column.title}</h3>
                  <span className="text-sm text-muted-foreground">({columnTasks.length})</span>
                </div>
                <div className="space-y-2">
                  {columnTasks.map((task) => (
                    <Card key={task.id} className="cursor-pointer hover:shadow-md transition-shadow">
                      <CardContent className="p-3">
                        <p className="text-sm font-medium text-foreground mb-2">{task.title}</p>
                        <p className="text-xs text-muted-foreground mb-3">{task.scope}</p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Avatar className="h-6 w-6">
                              <AvatarImage src={task.assignee.avatar || "/placeholder.svg"} />
                              <AvatarFallback className="text-xs">
                                {task.assignee.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </AvatarFallback>
                            </Avatar>
                            <span className="text-xs text-muted-foreground">{formatDate(task.dueDate)}</span>
                          </div>
                          <span className={cn("text-xs px-1.5 py-0.5 rounded", priorityStyles[task.priority])}>
                            {task.priority}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* List View */}
      {viewMode === "list" && (
        <Card>
          <CardContent className="p-0">
            <div className="divide-y divide-border">
              {tasks.map((task) => (
                <div key={task.id} className="flex items-center gap-4 p-4 hover:bg-muted/50 cursor-pointer">
                  <div
                    className={cn("w-2 h-2 rounded-full shrink-0", columns.find((c) => c.id === task.status)?.color)}
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground truncate">{task.title}</p>
                    <p className="text-sm text-muted-foreground">{task.scope}</p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className={cn("text-xs px-2 py-0.5 rounded", priorityStyles[task.priority])}>
                      {task.priority}
                    </span>
                    <Avatar className="h-7 w-7">
                      <AvatarFallback className="text-xs">
                        {task.assignee.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm text-muted-foreground w-16">{formatDate(task.dueDate)}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
