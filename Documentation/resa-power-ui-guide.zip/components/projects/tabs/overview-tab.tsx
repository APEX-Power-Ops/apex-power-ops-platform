import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, FileText, Activity, Calendar, MapPin, User } from "lucide-react"

interface Project {
  startDate: string
  endDate: string
  location: string
  estimator: string
  projectManager: string
  description: string
  quoted: number
  recognized: number
  remaining: number
  margin: number
}

interface OverviewTabProps {
  project: Project
}

const recentActivity = [
  { id: 1, action: "Apparatus test completed", item: "Transformer TF-001", time: "2 hours ago", icon: Activity },
  { id: 2, action: "Task assigned to", item: "John Smith", time: "4 hours ago", icon: User },
  { id: 3, action: "Scope status updated", item: "Switchgear Testing", time: "Yesterday", icon: FileText },
  { id: 4, action: "New apparatus added", item: "Relay RL-005", time: "2 days ago", icon: Plus },
  { id: 5, action: "Invoice generated", item: "INV-2024-0156", time: "3 days ago", icon: FileText },
]

export function OverviewTab({ project }: OverviewTabProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Left Column - 2/3 width */}
      <div className="lg:col-span-2 space-y-6">
        {/* Project Details Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Project Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Start Date</p>
                    <p className="font-medium">{formatDate(project.startDate)}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">End Date</p>
                    <p className="font-medium">{formatDate(project.endDate)}</p>
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Location</p>
                    <p className="font-medium">{project.location}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <User className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm text-muted-foreground">Estimator</p>
                    <p className="font-medium">{project.estimator}</p>
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <User className="w-5 h-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">Project Manager</p>
                  <p className="font-medium">{project.projectManager}</p>
                </div>
              </div>
            </div>
            <div className="mt-6 pt-6 border-t border-border">
              <p className="text-sm text-muted-foreground mb-2">Description</p>
              <p className="text-foreground">{project.description}</p>
            </div>
          </CardContent>
        </Card>

        {/* Financial Summary Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Financial Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="text-sm text-muted-foreground">Quoted</p>
                <p className="text-xl font-semibold text-foreground">{formatCurrency(project.quoted)}</p>
              </div>
              <div className="p-4 bg-status-success/10 rounded-lg">
                <p className="text-sm text-muted-foreground">Recognized</p>
                <p className="text-xl font-semibold text-status-success">{formatCurrency(project.recognized)}</p>
              </div>
              <div className="p-4 bg-status-warning/10 rounded-lg">
                <p className="text-sm text-muted-foreground">Remaining</p>
                <p className="text-xl font-semibold text-status-warning">{formatCurrency(project.remaining)}</p>
              </div>
              <div className="p-4 bg-primary/10 rounded-lg">
                <p className="text-sm text-muted-foreground">Margin</p>
                <p className="text-xl font-semibold text-primary">{project.margin}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Right Column - 1/3 width */}
      <div className="space-y-6">
        {/* Quick Actions Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button variant="outline" className="w-full justify-start bg-transparent">
              <Plus className="w-4 h-4 mr-2" />
              Add Scope
            </Button>
            <Button variant="outline" className="w-full justify-start bg-transparent">
              <Plus className="w-4 h-4 mr-2" />
              Add Apparatus
            </Button>
            <Button variant="outline" className="w-full justify-start bg-transparent">
              <FileText className="w-4 h-4 mr-2" />
              View Report
            </Button>
          </CardContent>
        </Card>

        {/* Recent Activity Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-start gap-3">
                  <div className="p-1.5 rounded-full bg-muted">
                    <activity.icon className="w-3.5 h-3.5 text-muted-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground">
                      {activity.action} <span className="font-medium">{activity.item}</span>
                    </p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
