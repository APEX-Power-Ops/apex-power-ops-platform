import type { ReactNode } from "react"
import { AlertTriangle, HelpCircle, MessageSquare } from "lucide-react"
import { cn } from "@/lib/utils"

interface DecisionCalloutProps {
  title: string
  children: ReactNode
  type?: "question" | "decision" | "feedback"
  stakeholder?: string
  className?: string
}

export function DecisionCallout({ title, children, type = "question", stakeholder, className }: DecisionCalloutProps) {
  const icons = {
    question: HelpCircle,
    decision: AlertTriangle,
    feedback: MessageSquare,
  }
  const Icon = icons[type]

  return (
    <div className={cn("border-l-4 border-amber-500 bg-amber-50 p-4 rounded-r-lg", className)}>
      <div className="flex items-start gap-3">
        <Icon className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h4 className="font-semibold text-amber-800">{title}</h4>
            {stakeholder && (
              <span className="text-xs bg-amber-200 text-amber-800 px-2 py-0.5 rounded-full">{stakeholder}</span>
            )}
          </div>
          <div className="text-sm text-amber-700">{children}</div>
        </div>
      </div>
    </div>
  )
}
