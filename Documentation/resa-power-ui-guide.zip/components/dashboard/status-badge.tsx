import { cn } from "@/lib/utils"

type Status =
  | "active"
  | "pending"
  | "completed"
  | "on-hold"
  | "cancelled"
  | "opportunity"
  | "sold"
  | "in-progress"
  | "complete"
  | "passed"
  | "failed"
  | "not-tested"
  | "scheduled"
  // Study statuses
  | "intake"
  | "awaiting-docs"
  | "partial-docs"
  | "with-engineer"
  | "rfi-pending"
  | "draft-submitted"
  | "revisions"
  | "stickers-pending"
  | "closed"
  // Estimate statuses
  | "draft"
  | "sent"
  | "negotiating"
  | "won"
  | "lost"
  | "generated"
  | "pending-review"
  | "finalized"

interface StatusBadgeProps {
  status: Status
  className?: string
}

const statusStyles: Record<Status, string> = {
  active: "bg-status-info/10 text-status-info",
  pending: "bg-status-warning/10 text-status-warning",
  completed: "bg-status-success/10 text-status-success",
  "on-hold": "bg-muted text-muted-foreground",
  cancelled: "bg-status-error/10 text-status-error",
  opportunity: "bg-amber-100 text-amber-800",
  sold: "bg-blue-100 text-blue-800",
  "in-progress": "bg-green-100 text-green-800",
  complete: "bg-slate-100 text-slate-600",
  passed: "bg-status-success/10 text-status-success",
  failed: "bg-status-error/10 text-status-error",
  "not-tested": "bg-muted text-muted-foreground",
  scheduled: "bg-status-info/10 text-status-info",
  // Study statuses
  intake: "bg-slate-100 text-slate-600",
  "awaiting-docs": "bg-amber-100 text-amber-800",
  "partial-docs": "bg-orange-100 text-orange-800",
  "with-engineer": "bg-blue-100 text-blue-800",
  "rfi-pending": "bg-purple-100 text-purple-800",
  "draft-submitted": "bg-cyan-100 text-cyan-800",
  revisions: "bg-rose-100 text-rose-800",
  "stickers-pending": "bg-indigo-100 text-indigo-800",
  closed: "bg-green-100 text-green-800",
  // Estimate statuses
  draft: "bg-slate-100 text-slate-600",
  sent: "bg-blue-100 text-blue-800",
  negotiating: "bg-purple-100 text-purple-800",
  won: "bg-green-100 text-green-800",
  lost: "bg-red-100 text-red-800",
  generated: "bg-blue-100 text-blue-800",
  "pending-review": "bg-amber-100 text-amber-800",
  finalized: "bg-green-100 text-green-800",
}

const statusLabels: Record<Status, string> = {
  active: "Active",
  pending: "Pending",
  completed: "Completed",
  "on-hold": "On Hold",
  cancelled: "Cancelled",
  opportunity: "Opportunity",
  sold: "Sold",
  "in-progress": "In Progress",
  complete: "Complete",
  passed: "Passed",
  failed: "Failed",
  "not-tested": "Not Tested",
  scheduled: "Scheduled",
  // Study statuses
  intake: "Intake",
  "awaiting-docs": "Awaiting Docs",
  "partial-docs": "Partial Docs",
  "with-engineer": "With Engineer",
  "rfi-pending": "RFI Pending",
  "draft-submitted": "Draft Submitted",
  revisions: "Revisions",
  "stickers-pending": "Stickers Pending",
  closed: "Closed",
  // Estimate statuses
  draft: "Draft",
  sent: "Sent",
  negotiating: "Negotiating",
  won: "Won",
  lost: "Lost",
  generated: "Generated",
  "pending-review": "Pending Review",
  finalized: "Finalized",
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
        statusStyles[status],
        className,
      )}
    >
      {statusLabels[status]}
    </span>
  )
}
