import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"

type ActivityType = "task" | "status" | "comment" | "upload"

interface Activity {
  id: string
  user: {
    name: string
    avatar?: string
    initials: string
  }
  action: string
  target: string
  type: ActivityType
  timestamp: string
}

const activities: Activity[] = [
  {
    id: "1",
    user: { name: "Sarah Chen", initials: "SC" },
    action: "completed test on",
    target: "Transformer T-001",
    type: "task",
    timestamp: "5 minutes ago",
  },
  {
    id: "2",
    user: { name: "Mike Johnson", initials: "MJ" },
    action: "updated status of",
    target: "Downtown Substation Upgrade",
    type: "status",
    timestamp: "15 minutes ago",
  },
  {
    id: "3",
    user: { name: "Emily Davis", initials: "ED" },
    action: "added comment on",
    target: "Hospital Generator Maintenance",
    type: "comment",
    timestamp: "1 hour ago",
  },
  {
    id: "4",
    user: { name: "James Wilson", initials: "JW" },
    action: "uploaded report for",
    target: "Office Complex Inspection",
    type: "upload",
    timestamp: "2 hours ago",
  },
  {
    id: "5",
    user: { name: "Lisa Park", initials: "LP" },
    action: "assigned to",
    target: "Data Center Power Audit",
    type: "task",
    timestamp: "3 hours ago",
  },
]

const typeColors: Record<ActivityType, string> = {
  task: "bg-status-success",
  status: "bg-status-info",
  comment: "bg-status-warning",
  upload: "bg-primary",
}

export function ActivityFeed() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity, index) => (
            <div key={activity.id} className="flex gap-3">
              <div className="relative">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={activity.user.avatar || "/placeholder.svg"} />
                  <AvatarFallback className="text-xs bg-secondary text-secondary-foreground">
                    {activity.user.initials}
                  </AvatarFallback>
                </Avatar>
                <div
                  className={cn(
                    "absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-card",
                    typeColors[activity.type],
                  )}
                />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-foreground">
                  <span className="font-medium">{activity.user.name}</span>{" "}
                  <span className="text-muted-foreground">{activity.action}</span>{" "}
                  <span className="font-medium">{activity.target}</span>
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">{activity.timestamp}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
