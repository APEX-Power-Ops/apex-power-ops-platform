import Link from "next/link"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { StatusBadge } from "./status-badge"
import { ArrowRight } from "lucide-react"

const projects = [
  {
    id: "PRJ-001",
    name: "Downtown Substation Upgrade",
    client: "City Power & Light",
    status: "active" as const,
    progress: 65,
    dueDate: "2024-03-15",
  },
  {
    id: "PRJ-002",
    name: "Industrial Plant Annual Testing",
    client: "ABC Manufacturing",
    status: "pending" as const,
    progress: 0,
    dueDate: "2024-03-20",
  },
  {
    id: "PRJ-003",
    name: "Hospital Generator Maintenance",
    client: "Regional Medical Center",
    status: "active" as const,
    progress: 40,
    dueDate: "2024-03-10",
  },
  {
    id: "PRJ-004",
    name: "Office Complex Inspection",
    client: "Metro Properties",
    status: "completed" as const,
    progress: 100,
    dueDate: "2024-02-28",
  },
  {
    id: "PRJ-005",
    name: "Data Center Power Audit",
    client: "TechCorp Solutions",
    status: "on-hold" as const,
    progress: 25,
    dueDate: "2024-04-01",
  },
]

export function RecentProjectsTable() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg font-semibold">Recent Projects</CardTitle>
        <Button variant="ghost" size="sm" asChild>
          <Link href="/projects" className="flex items-center gap-1">
            View All
            <ArrowRight className="h-4 w-4" />
          </Link>
        </Button>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Project</TableHead>
              <TableHead>Client</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Progress</TableHead>
              <TableHead>Due Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {projects.map((project) => (
              <TableRow key={project.id}>
                <TableCell>
                  <div>
                    <Link
                      href={`/projects/${project.id}`}
                      className="font-medium text-foreground hover:text-primary transition-colors"
                    >
                      {project.name}
                    </Link>
                    <p className="text-xs text-muted-foreground">{project.id}</p>
                  </div>
                </TableCell>
                <TableCell className="text-muted-foreground">{project.client}</TableCell>
                <TableCell>
                  <StatusBadge status={project.status} />
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className="w-24 h-2 bg-secondary rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full transition-all"
                        style={{ width: `${project.progress}%` }}
                      />
                    </div>
                    <span className="text-sm text-muted-foreground">{project.progress}%</span>
                  </div>
                </TableCell>
                <TableCell className="text-muted-foreground">
                  {new Date(project.dueDate).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                  })}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}
