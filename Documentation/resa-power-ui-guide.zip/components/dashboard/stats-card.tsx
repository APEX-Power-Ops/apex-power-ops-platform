import { cn } from "@/lib/utils"
import { Card, CardContent } from "@/components/ui/card"
import type { ComponentType } from "react"

interface StatsCardProps {
  title: string
  value: string | number
  change?: {
    value: string
    trend: "up" | "down" | "neutral"
  }
  icon: ComponentType<{ className?: string }>
  iconColor?: string
}

export function StatsCard({
  title,
  value,
  change,
  icon: Icon,
  iconColor = "bg-primary/10 text-primary",
}: StatsCardProps) {
  return (
    <Card className="bg-card">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-3xl font-semibold text-card-foreground">{value}</p>
            {change && (
              <p
                className={cn(
                  "text-sm font-medium",
                  change.trend === "up" && "text-status-success",
                  change.trend === "down" && "text-status-error",
                  change.trend === "neutral" && "text-muted-foreground",
                )}
              >
                {change.trend === "up" && "↑ "}
                {change.trend === "down" && "↓ "}
                {change.value}
              </p>
            )}
          </div>
          <div className={cn("p-3 rounded-lg", iconColor)}>
            <Icon className="h-6 w-6" />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
