"use client"

import { useState } from "react"
import { Download, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Progress } from "@/components/ui/progress"
import {
  Bar,
  BarChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { AppShell } from "@/components/layout/app-shell"

const monthlyData = [
  { month: "Aug", quoted: 320000, recognized: 280000 },
  { month: "Sep", quoted: 450000, recognized: 390000 },
  { month: "Oct", quoted: 380000, recognized: 350000 },
  { month: "Nov", quoted: 520000, recognized: 420000 },
  { month: "Dec", quoted: 410000, recognized: 380000 },
  { month: "Jan", quoted: 480000, recognized: 320000 },
]

const revenueByType = [
  { name: "Testing", value: 1850000, color: "#1e40af" },
  { name: "Engineering", value: 720000, color: "#3b82f6" },
  { name: "Emergency", value: 340000, color: "#60a5fa" },
  { name: "Other", value: 190000, color: "#93c5fd" },
]

const projectRevenue = [
  {
    id: "1",
    project: "Main Substation Upgrade",
    client: "Acme Corp",
    quoted: 450000,
    recognized: 320000,
    margin: 42,
    status: "in-progress",
  },
  {
    id: "2",
    project: "Building B Electrical",
    client: "TechStart Inc",
    quoted: 180000,
    recognized: 180000,
    margin: 38,
    status: "complete",
  },
  {
    id: "3",
    project: "Data Center Power",
    client: "CloudNet Systems",
    quoted: 620000,
    recognized: 450000,
    margin: 45,
    status: "in-progress",
  },
  {
    id: "4",
    project: "Hospital Emergency Power",
    client: "Metro Health",
    quoted: 340000,
    recognized: 120000,
    margin: 35,
    status: "in-progress",
  },
  {
    id: "5",
    project: "Manufacturing Line A",
    client: "Industrial Pro",
    quoted: 280000,
    recognized: 280000,
    margin: 41,
    status: "complete",
  },
]

const totals = {
  quoted: projectRevenue.reduce((sum, p) => sum + p.quoted, 0),
  recognized: projectRevenue.reduce((sum, p) => sum + p.recognized, 0),
}

export default function FinancialsPage() {
  const [timeRange, setTimeRange] = useState("6m")
  const [locationFilter, setLocationFilter] = useState("all")

  return (
    <AppShell title="Financials" subtitle="Revenue tracking and financial performance">
      <div className="space-y-6">
        {/* Filters */}
        <div className="flex items-center gap-4">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Time Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1m">Last Month</SelectItem>
              <SelectItem value="3m">Last 3 Months</SelectItem>
              <SelectItem value="6m">Last 6 Months</SelectItem>
              <SelectItem value="1y">Last Year</SelectItem>
              <SelectItem value="ytd">Year to Date</SelectItem>
            </SelectContent>
          </Select>
          <Select value={locationFilter} onValueChange={setLocationFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Location" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Locations</SelectItem>
              <SelectItem value="phoenix">Phoenix</SelectItem>
              <SelectItem value="las-vegas">Las Vegas</SelectItem>
              <SelectItem value="denver">Denver</SelectItem>
              <SelectItem value="san-diego">San Diego</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex-1" />
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export Report
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">Total Quoted</p>
                <TrendingUp className="h-4 w-4 text-status-success" />
              </div>
              <p className="text-2xl font-semibold mt-1">$2.56M</p>
              <p className="text-xs text-status-success">+12% from last period</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">Revenue Recognized</p>
                <TrendingUp className="h-4 w-4 text-status-success" />
              </div>
              <p className="text-2xl font-semibold mt-1">$2.14M</p>
              <p className="text-xs text-status-success">+8% from last period</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">Avg Margin</p>
                <TrendingUp className="h-4 w-4 text-status-success" />
              </div>
              <p className="text-2xl font-semibold mt-1">38.5%</p>
              <p className="text-xs text-status-success">+2.1% from last period</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">Outstanding</p>
                <TrendingUp className="h-4 w-4 text-status-warning" />
              </div>
              <p className="text-2xl font-semibold mt-1">$420K</p>
              <p className="text-xs text-muted-foreground">Across 12 projects</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Quoted vs Recognized Revenue</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="month" />
                  <YAxis tickFormatter={(v) => `$${v / 1000}K`} />
                  <Tooltip
                    formatter={(value: number) => [`$${(value / 1000).toFixed(0)}K`]}
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}
                  />
                  <Legend />
                  <Bar dataKey="quoted" name="Quoted" fill="#1e40af" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="recognized" name="Recognized" fill="#60a5fa" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Revenue by Service Type</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={revenueByType}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    dataKey="value"
                    nameKey="name"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {revenueByType.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: number) => [`$${(value / 1000).toFixed(0)}K`]}
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Project Revenue Table */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Project Revenue Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Project</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Quoted</TableHead>
                  <TableHead>Recognized</TableHead>
                  <TableHead>Progress</TableHead>
                  <TableHead>Margin</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {projectRevenue.map((project) => (
                  <TableRow key={project.id}>
                    <TableCell className="font-medium">{project.project}</TableCell>
                    <TableCell>{project.client}</TableCell>
                    <TableCell>${(project.quoted / 1000).toFixed(0)}K</TableCell>
                    <TableCell>${(project.recognized / 1000).toFixed(0)}K</TableCell>
                    <TableCell className="w-32">
                      <div className="flex items-center gap-2">
                        <Progress value={(project.recognized / project.quoted) * 100} className="h-2" />
                        <span className="text-xs text-muted-foreground">
                          {((project.recognized / project.quoted) * 100).toFixed(0)}%
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span
                        className={
                          project.margin >= 40
                            ? "text-status-success"
                            : project.margin >= 30
                              ? "text-status-warning"
                              : "text-status-error"
                        }
                      >
                        {project.margin}%
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  )
}
