"use client"

import { useState } from "react"
import { AppShell } from "@/components/layout/app-shell"
import { StatsCard } from "@/components/dashboard/stats-card"
import { StatusBadge } from "@/components/dashboard/status-badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import {
  FileText,
  Search,
  MoreHorizontal,
  Download,
  Eye,
  Mail,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Zap,
  FileCheck,
  MapPin,
  Clock,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Lock,
  Copy,
  Trash2,
  Loader2,
  Send,
  Paperclip,
  FileBarChart,
  ClipboardCheck,
  Timer,
  LayoutTemplate,
} from "lucide-react"

// Report type badges
type ReportType = "ats" | "mts" | "ir" | "combined"

const reportTypeBadges: Record<ReportType, { label: string; className: string }> = {
  ats: { label: "ATS", className: "bg-blue-100 text-blue-800" },
  mts: { label: "MTS", className: "bg-green-100 text-green-800" },
  ir: { label: "IR", className: "bg-orange-100 text-orange-800" },
  combined: { label: "Combined", className: "bg-purple-100 text-purple-800" },
}

// Sample reports data
const reportsData = [
  {
    id: "RPT-2024-0156",
    project: "Sundance TIAC",
    client: "Stellar Energy",
    type: "ats" as ReportType,
    employee: "K. Ellertson",
    status: "finalized" as const,
    date: "12/10",
  },
  {
    id: "RPT-2024-0155",
    project: "Main Campus Upgrade",
    client: "State University",
    type: "mts" as ReportType,
    employee: "A. Smith",
    status: "pending-review" as const,
    date: "12/10",
  },
  {
    id: "RPT-2024-0154",
    project: "Distribution Center",
    client: "Amazon",
    type: "ats" as ReportType,
    employee: "K. Ellertson",
    status: "generated" as const,
    date: "12/09",
  },
  {
    id: "RPT-2024-0153",
    project: "Hospital Wing C",
    client: "Mercy Health",
    type: "ir" as ReportType,
    employee: "M. Johnson",
    status: "finalized" as const,
    date: "12/08",
  },
  {
    id: "RPT-2024-0152",
    project: "Data Center Phase 2",
    client: "Microsoft",
    type: "combined" as ReportType,
    employee: "K. Ellertson",
    status: "finalized" as const,
    date: "12/07",
  },
]

const projectsForWizard = [
  {
    id: "p1",
    name: "Sundance TIAC",
    client: "Stellar Energy",
    location: "Phoenix, AZ",
    status: "Testing Complete",
    apparatusCount: 12,
    lastUpdated: "12/10",
  },
  {
    id: "p2",
    name: "Main Campus Upgrade",
    client: "State University",
    location: "Denver, CO",
    status: "In Progress",
    apparatusCount: 28,
    lastUpdated: "12/09",
  },
  {
    id: "p3",
    name: "Data Center Expansion",
    client: "Microsoft",
    location: "Las Vegas, NV",
    status: "Testing Complete",
    apparatusCount: 45,
    lastUpdated: "12/08",
  },
  {
    id: "p4",
    name: "Hospital Wing C",
    client: "Mercy Health",
    location: "San Diego, CA",
    status: "Testing Complete",
    apparatusCount: 8,
    lastUpdated: "12/07",
  },
  {
    id: "p5",
    name: "Distribution Center",
    client: "Amazon",
    location: "Phoenix, AZ",
    status: "In Progress",
    apparatusCount: 22,
    lastUpdated: "12/06",
  },
]

const equipmentForProject = [
  { id: "e1", name: "ATS-1 - Main Switchgear", model: "Eaton VCP-W", location: "Building A, MCC Room", status: "Pass" },
  {
    id: "e2",
    name: "ATS-2 - Generator Transfer Switch",
    model: "ASCO 7000",
    location: "Building A, Generator Room",
    status: "Pass",
  },
  {
    id: "e3",
    name: "ATS-3 - Distribution Panel DP-1",
    model: "Square D",
    location: "Building B, Electrical Room",
    status: "Pass",
  },
  {
    id: "e4",
    name: "ATS-4 - Emergency Lighting Panel",
    model: "Cutler-Hammer",
    location: "Building B, Mechanical Room",
    status: "Pending",
  },
  { id: "e5", name: "ATS-5 - UPS System", model: "Eaton 9395", location: "Building A, Data Room", status: "Pass" },
]

// Employees for signature
const employees = [
  { id: "kellertson", name: "Kole Ellertson", title: "Power Systems Technician", location: "Phoenix Services" },
  { id: "asmith", name: "Austin Smith", title: "Senior Technician", location: "Denver Services" },
  { id: "mjohnson", name: "Mike Johnson", title: "Field Engineer", location: "Las Vegas Services" },
  { id: "swilliams", name: "Sarah Williams", title: "Power Systems Technician", location: "San Diego Services" },
]

export default function ReportsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")
  const [typeFilter, setTypeFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [wizardOpen, setWizardOpen] = useState(false)
  const [wizardStep, setWizardStep] = useState(1)
  const [selectedProject, setSelectedProject] = useState<string | null>(null)
  const [reportType, setReportType] = useState("ats")
  const [selectedEmployee, setSelectedEmployee] = useState("kellertson")
  const [selectedEquipment, setSelectedEquipment] = useState<string[]>(["e1", "e2", "e3", "e5"])
  const [attentionTo, setAttentionTo] = useState("Terry Johnson")
  const [reLine, setReLine] = useState("Acceptance Testing Report - Sundance TIAC")
  const [projectDescription, setProjectDescription] = useState("")
  const [selectedSections, setSelectedSections] = useState({
    coverPage: true,
    summaryLetter: true,
    scopeOfWork: true,
    results: true,
    equipmentTable: true,
    testDataSheets: true,
    thermalImages: false,
    appendix: false,
  })
  const [outputFormat, setOutputFormat] = useState("pdf")
  const [internalNotes, setInternalNotes] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [generationComplete, setGenerationComplete] = useState(false)
  const [previewPage, setPreviewPage] = useState(1)
  const [emailModalOpen, setEmailModalOpen] = useState(false)
  const [questionsOpen, setQuestionsOpen] = useState(true)

  const selectedProjectData = projectsForWizard.find((p) => p.id === selectedProject)
  const selectedEmployeeData = employees.find((e) => e.id === selectedEmployee)

  const filteredReports = reportsData.filter((report) => {
    const matchesSearch =
      report.project.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.client.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.id.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesType = typeFilter === "all" || report.type === typeFilter
    const matchesStatus = statusFilter === "all" || report.status === statusFilter

    if (activeTab === "all") return matchesSearch && matchesType && matchesStatus
    if (activeTab === "my") return matchesSearch && matchesType && matchesStatus && report.employee === "K. Ellertson"
    if (activeTab === "pending") return matchesSearch && matchesType && report.status === "pending-review"
    return matchesSearch && matchesType && matchesStatus
  })

  const resetWizard = () => {
    setWizardStep(1)
    setSelectedProject(null)
    setReportType("ats")
    setSelectedEmployee("kellertson")
    setSelectedEquipment(["e1", "e2", "e3", "e5"])
    setAttentionTo("Terry Johnson")
    setReLine("Acceptance Testing Report - Sundance TIAC")
    setProjectDescription("")
    setSelectedSections({
      coverPage: true,
      summaryLetter: true,
      scopeOfWork: true,
      results: true,
      equipmentTable: true,
      testDataSheets: true,
      thermalImages: false,
      appendix: false,
    })
    setOutputFormat("pdf")
    setInternalNotes("")
    setIsGenerating(false)
    setGenerationComplete(false)
    setPreviewPage(1)
  }

  const openWizard = () => {
    resetWizard()
    setWizardOpen(true)
  }

  const handleGenerate = () => {
    setIsGenerating(true)
    // Simulate generation time
    setTimeout(() => {
      setIsGenerating(false)
      setGenerationComplete(true)
    }, 2000)
  }

  const handleSelectAll = () => {
    const passedEquipment = equipmentForProject.filter((e) => e.status === "Pass").map((e) => e.id)
    setSelectedEquipment(passedEquipment)
  }

  const handleDeselectAll = () => {
    setSelectedEquipment([])
  }

  return (
    <AppShell title="Report Generator" subtitle="Create professional PDF reports from project data">
      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4 mb-6">
        <StatsCard
          title="Reports This Month"
          value="24"
          change={{ value: "+8 from last month", trend: "up" }}
          icon={FileBarChart}
        />
        <StatsCard
          title="Pending Review"
          value="3"
          change={{ value: "3 awaiting approval", trend: "neutral" }}
          icon={ClipboardCheck}
          iconColor="bg-amber-100 text-amber-600"
        />
        <StatsCard title="Avg Generation Time" value="2.1 min" icon={Timer} iconColor="bg-green-100 text-green-600" />
        <StatsCard
          title="Templates Available"
          value="4"
          icon={LayoutTemplate}
          iconColor="bg-purple-100 text-purple-600"
        />
      </div>

      {/* Actions Bar */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <Button onClick={openWizard} size="lg">
          <FileText className="h-4 w-4 mr-2" />
          Create New Report
        </Button>
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search reports..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Report Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="ats">ATS</SelectItem>
            <SelectItem value="mts">MTS</SelectItem>
            <SelectItem value="ir">IR</SelectItem>
            <SelectItem value="combined">Combined</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="generated">Generated</SelectItem>
            <SelectItem value="pending-review">Pending</SelectItem>
            <SelectItem value="finalized">Finalized</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Reports Table */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Reports
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Report #</TableHead>
                <TableHead>Project</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Created By</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Date</TableHead>
                <TableHead className="w-[50px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredReports.map((report) => (
                <TableRow key={report.id}>
                  <TableCell className="font-mono text-sm">{report.id}</TableCell>
                  <TableCell className="font-medium">{report.project}</TableCell>
                  <TableCell>{report.client}</TableCell>
                  <TableCell>
                    <Badge className={reportTypeBadges[report.type].className}>
                      {reportTypeBadges[report.type].label}
                    </Badge>
                  </TableCell>
                  <TableCell>{report.employee}</TableCell>
                  <TableCell>
                    <StatusBadge status={report.status} />
                  </TableCell>
                  <TableCell>{report.date}</TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Eye className="h-4 w-4 mr-2" />
                          View PDF
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Download className="h-4 w-4 mr-2" />
                          Download
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Mail className="h-4 w-4 mr-2" />
                          Email to Client
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                          <Copy className="h-4 w-4 mr-2" />
                          Duplicate
                        </DropdownMenuItem>
                        {report.status === "draft" && (
                          <DropdownMenuItem className="text-destructive">
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Collapsible open={questionsOpen} onOpenChange={setQuestionsOpen}>
        <Card className="border-amber-200 bg-amber-50">
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer hover:bg-amber-100/50 transition-colors">
              <CardTitle className="flex items-center justify-between text-amber-800">
                <span className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Questions for Stakeholder Review
                </span>
                <ChevronDown className={`h-5 w-5 transition-transform ${questionsOpen ? "rotate-180" : ""}`} />
              </CardTitle>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="pt-0 text-amber-900">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-2">PERMISSIONS</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Who can generate reports? (Any tech, or project-assigned only)</li>
                    <li>Manager approval required before finalizing?</li>
                    <li>Can techs email reports directly to clients?</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">TEMPLATES</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Templates customizable per client?</li>
                    <li>Who can edit/create templates? (Admin only?)</li>
                    <li>Different cover pages per location?</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">WORKFLOW</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Version history needed for revisions?</li>
                    <li>Batch generation for multi-site projects?</li>
                    <li>Integration with document management system?</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">DELIVERY</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Auto-email option when finalized?</li>
                    <li>Client portal for self-service download?</li>
                    <li>Physical print/mail workflow needed?</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>

      {/* Create Report Wizard Dialog */}
      <Dialog open={wizardOpen} onOpenChange={setWizardOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {generationComplete
                ? "Report Generated Successfully!"
                : `Step ${wizardStep} of 3: ${
                    wizardStep === 1 ? "Select Project" : wizardStep === 2 ? "Report Details" : "Review & Generate"
                  }`}
            </DialogTitle>
          </DialogHeader>

          {/* Step Indicator */}
          {!generationComplete && !isGenerating && (
            <div className="flex items-center justify-center gap-2 py-4">
              {[1, 2, 3].map((step) => (
                <div key={step} className="flex items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      step < wizardStep
                        ? "bg-green-500 text-white"
                        : step === wizardStep
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {step < wizardStep ? <CheckCircle2 className="h-4 w-4" /> : step}
                  </div>
                  {step < 3 && <div className={`w-16 h-1 mx-2 ${step < wizardStep ? "bg-green-500" : "bg-muted"}`} />}
                </div>
              ))}
            </div>
          )}

          {/* Step 1: Select Project */}
          {wizardStep === 1 && !generationComplete && (
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search by project name, client, or job number..." className="pl-9" />
              </div>
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Recent Projects:</Label>
                <div className="space-y-2">
                  {projectsForWizard.map((project) => (
                    <div
                      key={project.id}
                      className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                        selectedProject === project.id
                          ? "border-primary bg-primary/5 ring-2 ring-primary/20"
                          : "border-border hover:border-primary/50"
                      }`}
                      onClick={() => setSelectedProject(project.id)}
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className={`mt-1 w-4 h-4 rounded-full border-2 flex-shrink-0 ${
                            selectedProject === project.id ? "border-primary bg-primary" : "border-muted-foreground"
                          }`}
                        >
                          {selectedProject === project.id && (
                            <div className="w-full h-full rounded-full bg-white scale-50" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <p className="font-medium">{project.name}</p>
                            <Badge
                              variant="outline"
                              className={
                                project.status === "Testing Complete"
                                  ? "text-green-600 border-green-300 bg-green-50"
                                  : "text-amber-600 border-amber-300 bg-amber-50"
                              }
                            >
                              {project.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{project.client}</p>
                          <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {project.location}
                            </span>
                            <span>{project.apparatusCount} apparatus</span>
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              Last updated {project.lastUpdated}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex justify-between pt-4 border-t">
                <Button variant="ghost" onClick={() => setWizardOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={() => setWizardStep(2)} disabled={!selectedProject}>
                  Next
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {/* Step 2: Report Details */}
          {wizardStep === 2 && !generationComplete && (
            <div className="space-y-6">
              {/* Selected Project Info */}
              {selectedProjectData && (
                <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                  <FileText className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <span className="font-medium">{selectedProjectData.name}</span>
                    <span className="text-muted-foreground"> • {selectedProjectData.client}</span>
                  </div>
                  <span className="text-sm text-muted-foreground ml-auto">{selectedProjectData.location}</span>
                </div>
              )}

              {/* Report Type & Date */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>
                    Report Type <span className="text-destructive">*</span>
                  </Label>
                  <Select value={reportType} onValueChange={setReportType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ats">ATS - Acceptance Testing Specification</SelectItem>
                      <SelectItem value="mts">MTS - Maintenance Testing Specification</SelectItem>
                      <SelectItem value="ir">IR - Infrared Thermography</SelectItem>
                      <SelectItem value="combined">Combined - ATS + IR</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Report Date</Label>
                  <Input type="date" defaultValue="2025-12-11" />
                </div>
              </div>

              {/* Client Information - Auto-filled */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="flex-1 h-px bg-border" />
                  <span>Client Information (Auto-filled)</span>
                  <div className="flex-1 h-px bg-border" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      Client Name
                      <Lock className="h-3 w-3 text-muted-foreground" />
                    </Label>
                    <Input value={selectedProjectData?.client || ""} readOnly className="bg-muted/50" />
                  </div>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      Site Name
                      <Lock className="h-3 w-3 text-muted-foreground" />
                    </Label>
                    <Input value={selectedProjectData?.name || ""} readOnly className="bg-muted/50" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    Site Address
                    <Lock className="h-3 w-3 text-muted-foreground" />
                  </Label>
                  <Input value="4567 Industrial Blvd, Phoenix, AZ 85001" readOnly className="bg-muted/50" />
                </div>
              </div>

              {/* Report Details */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="flex-1 h-px bg-border" />
                  <span>Report Details</span>
                  <div className="flex-1 h-px bg-border" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Attention To</Label>
                    <Input
                      value={attentionTo}
                      onChange={(e) => setAttentionTo(e.target.value)}
                      placeholder="Recipient name"
                    />
                    <p className="text-xs text-muted-foreground">Suggested: Terry Johnson (from client contacts)</p>
                  </div>
                  <div className="space-y-2">
                    <Label>RE Line</Label>
                    <Input
                      value={reLine}
                      onChange={(e) => setReLine(e.target.value)}
                      placeholder="Subject line for report"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Project Description (Optional)</Label>
                  <Textarea
                    value={projectDescription}
                    onChange={(e) => setProjectDescription(e.target.value)}
                    placeholder="Brief description of work performed..."
                    rows={3}
                  />
                </div>
              </div>

              {/* Equipment Selection */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="flex-1 h-px bg-border" />
                  <span>Equipment Selection</span>
                  <div className="flex-1 h-px bg-border" />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Select Equipment to Include:</Label>
                  <div className="flex gap-2">
                    <Button variant="link" size="sm" className="h-auto p-0" onClick={handleSelectAll}>
                      Select All
                    </Button>
                    <span className="text-muted-foreground">/</span>
                    <Button variant="link" size="sm" className="h-auto p-0" onClick={handleDeselectAll}>
                      Deselect All
                    </Button>
                  </div>
                </div>
                <div className="space-y-2 border rounded-lg p-3 max-h-48 overflow-y-auto">
                  {equipmentForProject.map((eq) => (
                    <div
                      key={eq.id}
                      className={`flex items-start gap-3 p-2 rounded ${eq.status === "Pending" ? "opacity-60" : ""}`}
                    >
                      <Checkbox
                        checked={selectedEquipment.includes(eq.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedEquipment([...selectedEquipment, eq.id])
                          } else {
                            setSelectedEquipment(selectedEquipment.filter((id) => id !== eq.id))
                          }
                        }}
                        disabled={eq.status === "Pending"}
                        className="mt-0.5"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-sm">{eq.name}</span>
                          <span className="text-xs text-muted-foreground">- {eq.model}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>Location: {eq.location}</span>
                          <span>|</span>
                          <span>Status:</span>
                          <span className={eq.status === "Pass" ? "text-green-600" : "text-amber-600"}>
                            {eq.status === "Pass" ? "✓ Pass" : "⏳ Pending"}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">
                  Only equipment with &apos;Pass&apos; status can be included in final reports
                </p>
              </div>

              {/* Prepared By / Signature */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="flex-1 h-px bg-border" />
                  <span>Prepared By</span>
                  <div className="flex-1 h-px bg-border" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Employee</Label>
                    <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {employees.map((emp) => (
                          <SelectItem key={emp.id} value={emp.id}>
                            {emp.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="border rounded-lg p-3 bg-muted/30">
                    <p className="text-xs text-muted-foreground mb-2">Signature Preview:</p>
                    <div className="text-center">
                      <p className="font-script text-2xl italic text-primary">{selectedEmployeeData?.name || ""}</p>
                      <p className="text-sm font-medium">{selectedEmployeeData?.name}</p>
                      <p className="text-xs text-muted-foreground">{selectedEmployeeData?.title}</p>
                      <p className="text-xs text-muted-foreground">RESA Power - {selectedEmployeeData?.location}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-between pt-4 border-t">
                <Button variant="outline" onClick={() => setWizardStep(1)}>
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
                <Button onClick={() => setWizardStep(3)}>
                  Next
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Review & Generate */}
          {wizardStep === 3 && !generationComplete && !isGenerating && (
            <div className="space-y-4">
              <div className="grid md:grid-cols-5 gap-6">
                {/* Left Column - Report Preview (60%) */}
                <div className="md:col-span-3 space-y-3">
                  <Label>Report Preview</Label>
                  <div className="border rounded-lg bg-slate-50 p-6 aspect-[8.5/11] flex flex-col items-center justify-center text-center">
                    <div className="mx-auto w-20 h-20 bg-primary rounded-lg flex items-center justify-center mb-4">
                      <Zap className="h-10 w-10 text-primary-foreground" />
                    </div>
                    <div className="w-32 h-0.5 bg-slate-300 mb-4" />
                    <h3 className="text-xl font-bold mb-1">
                      {reportType === "ats" && "ACCEPTANCE TESTING REPORT"}
                      {reportType === "mts" && "MAINTENANCE TESTING REPORT"}
                      {reportType === "ir" && "INFRARED THERMOGRAPHY REPORT"}
                      {reportType === "combined" && "COMBINED TESTING REPORT"}
                    </h3>
                    <div className="w-32 h-0.5 bg-slate-300 my-4" />
                    <p className="font-semibold">{selectedProjectData?.client}</p>
                    <p>{selectedProjectData?.name}</p>
                    <p className="text-muted-foreground">{selectedProjectData?.location}</p>
                    <p className="text-sm text-muted-foreground mt-4">December 11, 2025</p>
                    <div className="w-32 h-0.5 bg-slate-300 my-4" />
                    <p className="text-sm text-muted-foreground">Prepared By:</p>
                    <p className="text-sm font-medium">RESA Power</p>
                    <p className="text-sm text-muted-foreground">{selectedEmployeeData?.location}</p>
                  </div>
                  <div className="flex items-center justify-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPreviewPage(Math.max(1, previewPage - 1))}
                      disabled={previewPage === 1}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="text-sm text-muted-foreground">Page {previewPage} of 12</span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPreviewPage(Math.min(12, previewPage + 1))}
                      disabled={previewPage === 12}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* Right Column - Summary & Options (40%) */}
                <div className="md:col-span-2 space-y-4">
                  {/* Report Summary */}
                  <Card>
                    <CardHeader className="py-3">
                      <CardTitle className="text-sm">Report Summary</CardTitle>
                    </CardHeader>
                    <CardContent className="py-0 pb-3 space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Report Type:</span>
                        <Badge className={reportTypeBadges[reportType as ReportType].className}>
                          {reportTypeBadges[reportType as ReportType].label}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Client:</span>
                        <span className="font-medium">{selectedProjectData?.client}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Site:</span>
                        <span className="font-medium">{selectedProjectData?.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Date:</span>
                        <span>December 11, 2025</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Equipment:</span>
                        <span>{selectedEquipment.length} items</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Prepared By:</span>
                        <span>{selectedEmployeeData?.name}</span>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Sections to Include */}
                  <div className="space-y-2">
                    <Label className="text-sm">Sections to Include:</Label>
                    <div className="space-y-2 border rounded-lg p-3">
                      {[
                        { key: "coverPage", label: "Cover Page" },
                        { key: "summaryLetter", label: "Summary Letter" },
                        { key: "scopeOfWork", label: "Scope of Work" },
                        { key: "results", label: "Results & Recommendations" },
                        { key: "equipmentTable", label: "Equipment Summary Table" },
                        { key: "testDataSheets", label: "Individual Test Data Sheets" },
                        { key: "thermalImages", label: "Thermal Images", disabled: true, note: "No IR data available" },
                        { key: "appendix", label: "Appendix A: NETA Standards Reference" },
                      ].map((section) => (
                        <div key={section.key} className="flex items-center gap-2">
                          <Checkbox
                            checked={selectedSections[section.key as keyof typeof selectedSections]}
                            onCheckedChange={(checked) =>
                              setSelectedSections({ ...selectedSections, [section.key]: !!checked })
                            }
                            disabled={section.disabled}
                          />
                          <span className={`text-sm ${section.disabled ? "text-muted-foreground" : ""}`}>
                            {section.label}
                            {section.note && (
                              <span className="text-xs text-muted-foreground ml-1">({section.note})</span>
                            )}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Output Format */}
                  <div className="space-y-2">
                    <Label className="text-sm">Output Format:</Label>
                    <div className="space-y-2">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="format"
                          value="pdf"
                          checked={outputFormat === "pdf"}
                          onChange={() => setOutputFormat("pdf")}
                          className="text-primary"
                        />
                        <span className="text-sm">PDF (Recommended)</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="format"
                          value="pdf-word"
                          checked={outputFormat === "pdf-word"}
                          onChange={() => setOutputFormat("pdf-word")}
                          className="text-primary"
                        />
                        <span className="text-sm">PDF + Word (.docx)</span>
                      </label>
                    </div>
                  </div>

                  {/* Internal Notes */}
                  <div className="space-y-2">
                    <Label className="text-sm">Notes (internal, not in report):</Label>
                    <Textarea
                      value={internalNotes}
                      onChange={(e) => setInternalNotes(e.target.value)}
                      placeholder="Any internal notes..."
                      rows={2}
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-between pt-4 border-t">
                <Button variant="outline" onClick={() => setWizardStep(2)}>
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
                <Button onClick={handleGenerate}>
                  <FileCheck className="h-4 w-4 mr-2" />
                  Generate Report
                </Button>
              </div>
            </div>
          )}

          {/* Generating State */}
          {isGenerating && (
            <div className="py-12 text-center space-y-4">
              <Loader2 className="h-12 w-12 animate-spin mx-auto text-primary" />
              <div>
                <p className="font-medium">Generating Report...</p>
                <p className="text-sm text-muted-foreground">Creating PDF... This takes about 2 minutes</p>
              </div>
            </div>
          )}

          {/* Success State */}
          {generationComplete && (
            <div className="space-y-6 py-4">
              <div className="text-center space-y-4">
                <div className="mx-auto w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="h-12 w-12 text-green-600" />
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Report Number:</p>
                  <p className="font-mono font-semibold">RPT-2024-0157</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">File:</p>
                  <p className="font-medium">Stellar_Energy_Sundance_TIAC_ATS.pdf</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Size:</p>
                  <p className="font-medium">2.4 MB (12 pages)</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Generated:</p>
                  <p className="font-medium">December 11, 2025 at 2:34 PM</p>
                </div>
              </div>

              <div className="flex justify-center gap-3">
                <Button variant="outline">
                  <Eye className="h-4 w-4 mr-2" />
                  Preview
                </Button>
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
                <Button variant="outline" onClick={() => setEmailModalOpen(true)}>
                  <Mail className="h-4 w-4 mr-2" />
                  Email
                </Button>
              </div>

              <div className="border-t pt-4 space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Status:</span>
                  <StatusBadge status="generated" />
                </div>
                <p className="text-sm text-muted-foreground">Next Step: Submit for manager review</p>
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1 bg-transparent">
                    Submit for Review
                  </Button>
                  <Button className="flex-1" onClick={openWizard}>
                    Create Another Report
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Email Modal */}
      <Dialog open={emailModalOpen} onOpenChange={setEmailModalOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Email Report</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>To:</Label>
              <Input defaultValue="terry.johnson@stellarenergy.com" />
              <p className="text-xs text-muted-foreground">(auto-populated from client contact)</p>
            </div>
            <div className="space-y-2">
              <Label>CC:</Label>
              <Input placeholder="Add CC recipients..." />
            </div>
            <div className="space-y-2">
              <Label>Subject:</Label>
              <Input defaultValue="RESA Power - Acceptance Testing Report - Sundance TIAC" />
            </div>
            <div className="space-y-2">
              <Label>Message:</Label>
              <Textarea
                rows={6}
                defaultValue={`Dear Terry,

Please find attached the Acceptance Testing Report for the Sundance TIAC project.

If you have any questions, please don't hesitate to contact us.

Best regards,
Kole Ellertson
RESA Power`}
              />
            </div>
            <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
              <Paperclip className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">Stellar_Energy_Sundance_TIAC_ATS.pdf</span>
              <span className="text-sm text-muted-foreground">(2.4 MB)</span>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEmailModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => setEmailModalOpen(false)}>
              <Send className="h-4 w-4 mr-2" />
              Send Email
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppShell>
  )
}
