"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useRole } from "@/contexts/role-context"
import { AppShell } from "@/components/layout/app-shell"
import { StatsCard } from "@/components/dashboard/stats-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { DecisionCallout } from "@/components/ui/decision-callout"
import { DollarSign, TrendingUp, Target, AlertTriangle, Building2, ArrowRight } from "lucide-react"
import { Bar, BarChart, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, Legend } from "recharts"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

const revenueByLocation = [
  { name: "Phoenix", value: 1850000 },
  { name: "Las Vegas", value: 1420000 },
  { name: "Denver", value: 1180000 },
  { name: "San Diego", value: 920000 },
]

const revenueByServiceType = [
  { name: "Transformer Testing", value: 2800000, color: "#1e40af" },
  { name: "Switchgear", value: 1650000, color: "#3b82f6" },
  { name: "Cable Testing", value: 1200000, color: "#60a5fa" },
  { name: "Relay Calibration", value: 970000, color: "#93c5fd" },
]

const projectsNeedingAttention = [
  {
    id: "PRJ-2024-089",
    name: "Metro Hospital Main Switchgear",
    client: "Metro Health System",
    issue: "Budget overrun risk - 85% spent, 60% complete",
    severity: "high",
  },
  {
    id: "PRJ-2024-092",
    name: "Industrial Park Substation",
    client: "Texas Industrial LLC",
    issue: "Timeline slipping - 2 weeks behind schedule",
    severity: "medium",
  },
  {
    id: "PRJ-2024-078",
    name: "Data Center UPS Testing",
    client: "CloudFirst Inc",
    issue: "Pending client approval for 5 days",
    severity: "low",
  },
]

const topPerformers = [
  { name: "Mike Rodriguez", role: "Project Manager", metric: "$2.4M revenue", initials: "MR" },
  { name: "Sarah Martinez", role: "Field Tech Lead", metric: "98% test pass rate", initials: "SM" },
  { name: "David Kim", role: "Estimator", metric: "68% win rate", initials: "DK" },
]

export default function ExecutiveDashboardPage() {
  const { currentRole } = useRole()
  const router = useRouter()

  useEffect(() => {
    if (currentRole !== "executive") {
      router.push("/")
    }
  }, [currentRole, router])

  if (currentRole !== "executive") {
    return null
  }

  return (
    <AppShell title="Executive Summary" subtitle="Company-wide performance overview">
      <div className="space-y-6">
        {/* Decision Callout */}
        <DecisionCallout title="Resource Allocation Decision Needed" type="decision" stakeholder="Executive Team">
          Phoenix location is at 95% capacity while Denver is at 60%. Should we prioritize hiring in Phoenix or redirect
          work to Denver? This affects Q4 revenue projections.
        </DecisionCallout>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard
            title="YTD Revenue"
            value="$6.62M"
            change={{ value: "+18% vs last year", trend: "up" }}
            icon={DollarSign}
            iconColor="bg-status-success/10 text-status-success"
          />
          <StatsCard
            title="Gross Margin"
            value="42.3%"
            change={{ value: "+2.1% vs target", trend: "up" }}
            icon={TrendingUp}
            iconColor="bg-primary/10 text-primary"
          />
          <StatsCard
            title="Win Rate"
            value="64%"
            change={{ value: "+5% this quarter", trend: "up" }}
            icon={Target}
            iconColor="bg-status-info/10 text-status-info"
          />
          <StatsCard
            title="At-Risk Projects"
            value="3"
            change={{ value: "Needs attention", trend: "neutral" }}
            icon={AlertTriangle}
            iconColor="bg-status-warning/10 text-status-warning"
          />
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Revenue by Location */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-semibold">Revenue by Location</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={revenueByLocation} layout="vertical">
                  <XAxis type="number" tickFormatter={(v) => `$${(v / 1000000).toFixed(1)}M`} />
                  <YAxis type="category" dataKey="name" width={80} />
                  <Tooltip
                    formatter={(value: number) => [`$${(value / 1000000).toFixed(2)}M`, "Revenue"]}
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}
                  />
                  <Bar dataKey="value" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Revenue by Service Type */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-semibold">Revenue by Service Type</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={280}>
                <PieChart>
                  <Pie
                    data={revenueByServiceType}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    dataKey="value"
                    nameKey="name"
                    label={({ name, percent }) => `${name.split(" ")[0]} ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {revenueByServiceType.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: number) => [`$${(value / 1000000).toFixed(2)}M`, "Revenue"]}
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Bottom Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Projects Needing Attention */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base font-semibold">Projects Needing Attention</CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/projects">
                  View All <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {projectsNeedingAttention.map((project) => (
                  <div
                    key={project.id}
                    className="flex items-start gap-4 p-4 rounded-lg border border-border hover:bg-accent/50 transition-colors"
                  >
                    <div
                      className={`w-2 h-2 mt-2 rounded-full shrink-0 ${
                        project.severity === "high"
                          ? "bg-status-error"
                          : project.severity === "medium"
                            ? "bg-status-warning"
                            : "bg-status-info"
                      }`}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs text-muted-foreground font-mono">{project.id}</span>
                        <Badge
                          variant="outline"
                          className={
                            project.severity === "high"
                              ? "border-status-error text-status-error"
                              : project.severity === "medium"
                                ? "border-status-warning text-status-warning"
                                : "border-status-info text-status-info"
                          }
                        >
                          {project.severity}
                        </Badge>
                      </div>
                      <h4 className="font-medium text-foreground truncate">{project.name}</h4>
                      <p className="text-sm text-muted-foreground">{project.client}</p>
                      <p className="text-sm text-status-warning mt-1">{project.issue}</p>
                    </div>
                    <Button variant="outline" size="sm" asChild>
                      <Link href={`/projects/${project.id}`}>View</Link>
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Top Performers */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-semibold">Top Performers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topPerformers.map((performer, index) => (
                  <div key={performer.name} className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary text-sm font-semibold">
                      {index + 1}
                    </div>
                    <Avatar className="h-10 w-10">
                      <AvatarFallback>{performer.initials}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">{performer.name}</p>
                      <p className="text-sm text-muted-foreground">{performer.role}</p>
                    </div>
                    <Badge variant="secondary" className="shrink-0">
                      {performer.metric}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Location Performance Decision */}
        <DecisionCallout title="Location Expansion Opportunity" type="question" stakeholder="CFO Review">
          <div className="flex items-center gap-2 mt-2">
            <Building2 className="h-4 w-4" />
            <span>
              Las Vegas market shows strong demand signals. Consider expanding technician capacity. Estimated
              investment: $450K. Projected ROI: 18 months.
            </span>
          </div>
        </DecisionCallout>
      </div>
    </AppShell>
  )
}
