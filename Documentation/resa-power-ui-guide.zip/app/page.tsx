"use client"

import { useRole } from "@/contexts/role-context"
import { useRouter } from "next/navigation"
import { AppShell } from "@/components/layout/app-shell"
import { StatsCard } from "@/components/dashboard/stats-card"
import { RecentProjectsTable } from "@/components/dashboard/recent-projects-table"
import { ActivityFeed } from "@/components/dashboard/activity-feed"
import { FolderKanban, Zap, CheckCircle, Clock } from "lucide-react"
import { useEffect } from "react"

export default function DashboardPage() {
  const { currentRole } = useRole()
  const router = useRouter()

  useEffect(() => {
    if (currentRole === "field-tech") {
      router.push("/field-tech")
    } else if (currentRole === "executive") {
      router.push("/executive")
    }
  }, [currentRole, router])

  if (currentRole === "executive" || currentRole === "field-tech") {
    return null
  }

  return (
    <AppShell title="Dashboard" subtitle="Welcome back. Here's what's happening today.">
      {/* Stats Cards */}
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard
            title="Active Projects"
            value={12}
            change={{ value: "+2 this week", trend: "up" }}
            icon={FolderKanban}
            iconColor="bg-status-info/10 text-status-info"
          />
          <StatsCard
            title="Apparatus Under Test"
            value={48}
            change={{ value: "+8 this week", trend: "up" }}
            icon={Zap}
            iconColor="bg-status-warning/10 text-status-warning"
          />
          <StatsCard
            title="Tests Completed"
            value={156}
            change={{ value: "+23 this month", trend: "up" }}
            icon={CheckCircle}
            iconColor="bg-status-success/10 text-status-success"
          />
          <StatsCard
            title="Pending Reviews"
            value={7}
            change={{ value: "-3 from yesterday", trend: "down" }}
            icon={Clock}
            iconColor="bg-primary/10 text-primary"
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <RecentProjectsTable />
          </div>
          <div>
            <ActivityFeed />
          </div>
        </div>
      </div>
    </AppShell>
  )
}
