"use client"

import { useState } from "react"
import { AppShell } from "@/components/layout/app-shell"
import { StatsCard } from "@/components/dashboard/stats-card"
import { DecisionCallout } from "@/components/ui/decision-callout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Checkbox } from "@/components/ui/checkbox"
import { Calendar, Users, FileText, ClipboardList, ChevronLeft, ChevronRight, MapPin } from "lucide-react"

const weekDays = ["Mon", "Tue", "Wed", "Thu", "Fri"]
const currentWeek = ["Dec 9", "Dec 10", "Dec 11", "Dec 12", "Dec 13"]

const technicians = [
  {
    name: "James Wilson",
    initials: "JW",
    role: "Lead Tech",
    assignments: [
      { day: 0, project: "Metro Hospital", location: "Phoenix", type: "full" },
      { day: 1, project: "Metro Hospital", location: "Phoenix", type: "full" },
      { day: 2, project: "Industrial Park", location: "Denver", type: "full" },
      { day: 3, project: "Industrial Park", location: "Denver", type: "full" },
      { day: 4, project: null, location: null, type: "available" },
    ],
  },
  {
    name: "Sarah Martinez",
    initials: "SM",
    role: "Field Tech",
    assignments: [
      { day: 0, project: "Office Tower", location: "Phoenix", type: "full" },
      { day: 1, project: "Office Tower", location: "Phoenix", type: "half" },
      { day: 2, project: null, location: null, type: "available" },
      { day: 3, project: "Data Center", location: "Las Vegas", type: "full" },
      { day: 4, project: "Data Center", location: "Las Vegas", type: "full" },
    ],
  },
  {
    name: "Tom Chen",
    initials: "TC",
    role: "Field Tech",
    assignments: [
      { day: 0, project: "Manufacturing Plant", location: "San Diego", type: "full" },
      { day: 1, project: "Manufacturing Plant", location: "San Diego", type: "full" },
      { day: 2, project: "Manufacturing Plant", location: "San Diego", type: "half" },
      { day: 3, project: null, location: null, type: "available" },
      { day: 4, project: "Metro Hospital", location: "Phoenix", type: "full" },
    ],
  },
  {
    name: "Lisa Park",
    initials: "LP",
    role: "Junior Tech",
    assignments: [
      { day: 0, project: null, location: null, type: "training" },
      { day: 1, project: "Office Tower", location: "Phoenix", type: "support" },
      { day: 2, project: "Industrial Park", location: "Denver", type: "support" },
      { day: 3, project: "Industrial Park", location: "Denver", type: "support" },
      { day: 4, project: null, location: null, type: "off" },
    ],
  },
]

const documentChecklist = [
  { id: "1", task: "Metro Hospital - Certificate of Insurance", due: "Today", status: "pending", priority: "high" },
  {
    id: "2",
    task: "Industrial Park - Site Access Forms",
    due: "Tomorrow",
    status: "pending",
    priority: "medium",
  },
  {
    id: "3",
    task: "Data Center - NDA Renewal",
    due: "Dec 15",
    status: "in-progress",
    priority: "medium",
  },
  { id: "4", task: "Office Tower - Test Reports", due: "Dec 18", status: "pending", priority: "low" },
]

const dataEntryQueue = [
  { id: "1", type: "Test Results", project: "Manufacturing Plant", tech: "Tom Chen", items: 12, submitted: "2h ago" },
  {
    id: "2",
    type: "Equipment Log",
    project: "Metro Hospital",
    tech: "James Wilson",
    items: 8,
    submitted: "4h ago",
  },
  {
    id: "3",
    type: "Time Sheets",
    project: "Office Tower",
    tech: "Sarah Martinez",
    items: 5,
    submitted: "Yesterday",
  },
]

export default function SchedulingPage() {
  const [selectedWeek, setSelectedWeek] = useState(0)

  return (
    <AppShell title="Scheduling" subtitle="Technician assignments and calendar">
      <div className="space-y-6">
        {/* Decision Callout */}
        <DecisionCallout title="Scheduling Conflict" type="decision" stakeholder="Office Admin">
          2 technicians needed for emergency call at CloudNet Data Center tomorrow, but all Phoenix techs are assigned.
          Pull from Las Vegas (4hr drive) or reschedule existing work?
        </DecisionCallout>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <StatsCard
            title="Techs Available Today"
            value={technicians.filter((t) => t.assignments.some((a) => a.type === "available")).length}
            change={{ value: `of ${technicians.length} total`, trend: "neutral" }}
            icon={Users}
            iconColor="bg-status-success/10 text-status-success"
          />
          <StatsCard
            title="Jobs This Week"
            value={technicians.reduce(
              (acc, t) => acc + t.assignments.filter((a) => a.type === "full" || a.type === "half").length,
              0,
            )}
            change={{ value: "Scheduled", trend: "neutral" }}
            icon={Calendar}
            iconColor="bg-primary/10 text-primary"
          />
          <StatsCard
            title="Pending Documents"
            value={documentChecklist.filter((d) => !d.received).length}
            change={{ value: "Awaiting submission", trend: "neutral" }}
            icon={FileText}
            iconColor="bg-status-warning/10 text-status-warning"
          />
          <StatsCard
            title="Data Entry Queue"
            value={dataEntryQueue.length}
            change={{ value: "Items to process", trend: "neutral" }}
            icon={ClipboardList}
            iconColor="bg-status-info/10 text-status-info"
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Scheduling Calendar */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">Technician Schedule</CardTitle>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" onClick={() => setSelectedWeek((w) => w - 1)}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm font-medium">Week of Dec 9, 2024</span>
                <Button variant="outline" size="icon" onClick={() => setSelectedWeek((w) => w + 1)}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr>
                      <th className="text-left p-2 border-b">Technician</th>
                      {weekDays.map((day, idx) => (
                        <th key={day} className="text-center p-2 border-b min-w-[100px]">
                          <div className="text-sm font-medium">{day}</div>
                          <div className="text-xs text-muted-foreground">{currentWeek[idx]}</div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {technicians.map((tech) => (
                      <tr key={tech.name}>
                        <td className="p-2 border-b">
                          <div className="flex items-center gap-2">
                            <Avatar className="h-8 w-8">
                              <AvatarFallback>{tech.initials}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="text-sm font-medium">{tech.name}</p>
                              <p className="text-xs text-muted-foreground">{tech.role}</p>
                            </div>
                          </div>
                        </td>
                        {tech.assignments.map((assignment, idx) => (
                          <td key={idx} className="p-1 border-b">
                            {assignment.type === "available" ? (
                              <div className="h-16 rounded border-2 border-dashed border-muted flex items-center justify-center text-xs text-muted-foreground">
                                Available
                              </div>
                            ) : (
                              <div
                                className={`h-16 rounded p-2 text-xs ${
                                  assignment.type === "full"
                                    ? "bg-primary/10 border border-primary/20"
                                    : "bg-status-warning/10 border border-status-warning/20"
                                }`}
                              >
                                <p className="font-medium truncate">{assignment.project}</p>
                                <div className="flex items-center gap-1 mt-1 text-muted-foreground">
                                  <MapPin className="h-3 w-3" />
                                  <span>{assignment.location}</span>
                                </div>
                              </div>
                            )}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Document Checklist */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Document Checklist</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {documentChecklist.map((doc) => (
                    <div key={doc.id} className="flex items-center gap-3">
                      <Checkbox checked={doc.received} />
                      <div className="flex-1">
                        <p className="text-sm font-medium">{doc.task}</p>
                        <p className="text-xs text-muted-foreground">{doc.due}</p>
                      </div>
                      {!doc.received && (
                        <Badge variant="outline" className="text-status-warning border-status-warning">
                          {doc.priority}
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Data Entry Queue */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Data Entry Queue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {dataEntryQueue.map((item) => (
                    <div key={item.id} className="flex items-start gap-3 p-2 rounded-lg hover:bg-muted/50">
                      <div
                        className={`mt-1 w-2 h-2 rounded-full ${
                          item.priority === "high"
                            ? "bg-status-error"
                            : item.priority === "medium"
                              ? "bg-status-warning"
                              : "bg-status-info"
                        }`}
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium">{item.type}</p>
                        <p className="text-xs text-muted-foreground">{item.project}</p>
                        <p className="text-xs text-muted-foreground">From: {item.tech}</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Process
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppShell>
  )
}
