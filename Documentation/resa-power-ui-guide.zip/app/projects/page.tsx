"use client"

import { useState, useMemo } from "react"
import { Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { AppShell } from "@/components/layout/app-shell"
import { ProjectsFilters, type FilterState } from "@/components/projects/projects-filters"
import { ProjectsTable, type Project } from "@/components/projects/projects-table"
import { ProjectsPagination } from "@/components/projects/projects-pagination"
import { EmptyState } from "@/components/projects/empty-state"
import Link from "next/link"

// Mock data
const mockProjects: Project[] = [
  {
    id: "1",
    projectNumber: "PRJ-2024-001",
    name: "Main Substation Upgrade",
    client: "Austin Energy",
    status: "in-progress",
    location: "Phoenix, AZ",
    startDate: "Jan 15, 2024",
    revenue: 245000,
    progress: 68,
  },
  {
    id: "2",
    projectNumber: "PRJ-2024-002",
    name: "Gigafactory Expansion Phase 3",
    client: "Tesla Gigafactory",
    status: "in-progress",
    location: "Las Vegas, NV",
    startDate: "Feb 1, 2024",
    revenue: 892000,
    progress: 42,
  },
  {
    id: "3",
    projectNumber: "PRJ-2024-003",
    name: "Fab 2 Electrical Assessment",
    client: "Samsung Austin",
    status: "opportunity",
    location: "Phoenix, AZ",
    startDate: "Mar 1, 2024",
    revenue: 156000,
    progress: 0,
  },
  {
    id: "4",
    projectNumber: "PRJ-2024-004",
    name: "Cleanroom Power Upgrade",
    client: "Applied Materials",
    status: "sold",
    location: "San Diego, CA",
    startDate: "Feb 20, 2024",
    revenue: 378000,
    progress: 15,
  },
  {
    id: "5",
    projectNumber: "PRJ-2024-005",
    name: "Distribution Panel Replacement",
    client: "NXP Semiconductors",
    status: "complete",
    location: "Denver, CO",
    startDate: "Nov 1, 2023",
    revenue: 89000,
    progress: 100,
  },
  {
    id: "6",
    projectNumber: "PRJ-2024-006",
    name: "Data Center Power Study",
    client: "Dell Technologies",
    status: "on-hold",
    location: "Phoenix, AZ",
    startDate: "Jan 5, 2024",
    revenue: 124000,
    progress: 25,
  },
  {
    id: "7",
    projectNumber: "PRJ-2024-007",
    name: "Emergency Generator Installation",
    client: "Austin Energy",
    status: "in-progress",
    location: "Las Vegas, NV",
    startDate: "Feb 10, 2024",
    revenue: 567000,
    progress: 55,
  },
  {
    id: "8",
    projectNumber: "PRJ-2024-008",
    name: "Medium Voltage Switchgear Testing",
    client: "Tesla Gigafactory",
    status: "opportunity",
    location: "Las Vegas, NV",
    startDate: "Apr 1, 2024",
    revenue: 234000,
    progress: 0,
  },
  {
    id: "9",
    projectNumber: "PRJ-2024-009",
    name: "Annual Maintenance Contract",
    client: "Samsung Austin",
    status: "sold",
    location: "San Diego, CA",
    startDate: "Mar 15, 2024",
    revenue: 445000,
    progress: 8,
  },
  {
    id: "10",
    projectNumber: "PRJ-2024-010",
    name: "Transformer Replacement Project",
    client: "Applied Materials",
    status: "in-progress",
    location: "Phoenix, AZ",
    startDate: "Dec 1, 2023",
    revenue: 678000,
    progress: 78,
  },
  {
    id: "11",
    projectNumber: "PRJ-2024-011",
    name: "Power Quality Analysis",
    client: "NXP Semiconductors",
    status: "complete",
    location: "Denver, CO",
    startDate: "Oct 15, 2023",
    revenue: 67000,
    progress: 100,
  },
  {
    id: "12",
    projectNumber: "PRJ-2024-012",
    name: "UPS System Upgrade",
    client: "Dell Technologies",
    status: "opportunity",
    location: "San Diego, CA",
    startDate: "May 1, 2024",
    revenue: 189000,
    progress: 0,
  },
]

export default function ProjectsPage() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [filters, setFilters] = useState<FilterState>({
    search: "",
    status: "all",
    client: "all",
    location: "all",
    dateRange: undefined,
  })
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const [currentPage, setCurrentPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: "asc" | "desc" }>({
    key: "",
    direction: "asc",
  })

  const filteredProjects = useMemo(() => {
    return mockProjects.filter((project) => {
      if (filters.search) {
        const search = filters.search.toLowerCase()
        const matchesSearch =
          project.name.toLowerCase().includes(search) ||
          project.projectNumber.toLowerCase().includes(search) ||
          project.client.toLowerCase().includes(search)
        if (!matchesSearch) return false
      }
      if (filters.status !== "all" && project.status !== filters.status) return false
      if (filters.client !== "all" && project.client !== filters.client) return false
      if (filters.location !== "all" && project.location !== filters.location) return false
      return true
    })
  }, [filters])

  const paginatedProjects = useMemo(() => {
    const start = (currentPage - 1) * pageSize
    return filteredProjects.slice(start, start + pageSize)
  }, [filteredProjects, currentPage, pageSize])

  const totalPages = Math.ceil(filteredProjects.length / pageSize)

  const hasActiveFilters =
    filters.search ||
    filters.status !== "all" ||
    filters.client !== "all" ||
    filters.location !== "all" ||
    filters.dateRange

  const clearFilters = () => {
    setFilters({
      search: "",
      status: "all",
      client: "all",
      location: "all",
      dateRange: undefined,
    })
    setCurrentPage(1)
  }

  return (
    <AppShell title="Projects" subtitle="Manage and track all projects">
      <div className="space-y-6">
        {/* Header Actions */}
        <div className="flex items-center justify-between">
          <ProjectsFilters filters={filters} onFilterChange={setFilters} />
          <Button asChild>
            <Link href="/projects/new">
              <Plus className="mr-2 h-4 w-4" />
              New Project
            </Link>
          </Button>
        </div>

        {/* Table or Empty State */}
        {filteredProjects.length === 0 ? (
          <EmptyState
            hasFilters={filters.search !== "" || filters.status !== "all" || filters.client !== "all"}
            onClearFilters={() =>
              setFilters({
                search: "",
                status: "all",
                client: "all",
                location: "all",
                dateRange: { from: undefined, to: undefined },
              })
            }
          />
        ) : (
          <>
            <ProjectsTable
              projects={paginatedProjects}
              selectedProjects={selectedIds}
              onSelectProject={(id) => {
                setSelectedIds((prev) => (prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]))
              }}
              onSelectAll={(selected) => {
                setSelectedIds(selected ? paginatedProjects.map((p) => p.id) : [])
              }}
              sortConfig={sortConfig}
              onSort={(key) => {
                setSortConfig((prev) => ({
                  key,
                  direction: prev.key === key && prev.direction === "asc" ? "desc" : "asc",
                }))
              }}
            />
            <ProjectsPagination
              currentPage={currentPage}
              totalPages={totalPages}
              pageSize={pageSize}
              totalItems={filteredProjects.length}
              onPageChange={setCurrentPage}
              onPageSizeChange={(size) => {
                setPageSize(size)
                setCurrentPage(1)
              }}
            />
          </>
        )}
      </div>
    </AppShell>
  )
}
