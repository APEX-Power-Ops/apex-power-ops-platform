"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { AppShell } from "@/components/layout/app-shell"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { StepIndicator } from "@/components/projects/create/step-indicator"
import { StepClientBasics } from "@/components/projects/create/step-client-basics"
import { StepLocationTeam } from "@/components/projects/create/step-location-team"
import { StepInitialScope } from "@/components/projects/create/step-initial-scope"
import { ArrowLeft } from "lucide-react"

const steps = [
  { id: 1, name: "Client & Basics" },
  { id: 2, name: "Location & Team" },
  { id: 3, name: "Initial Scope" },
]

interface FormData {
  // Step 1
  clientId: string
  projectName: string
  description: string
  isOpportunity: boolean
  // Step 2
  siteId: string
  resaLocation: string
  estimatorId: string
  projectManagerId: string
  startDate: Date | undefined
  endDate: Date | undefined
  // Step 3
  scopes: Array<{
    id: string
    name: string
    type: string
    revenueType: "time-materials" | "fixed-fee"
    quotedAmount?: number
  }>
}

export default function NewProjectPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(1)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  const [formData, setFormData] = useState<FormData>({
    clientId: "",
    projectName: "",
    description: "",
    isOpportunity: false,
    siteId: "",
    resaLocation: "",
    estimatorId: "",
    projectManagerId: "",
    startDate: undefined,
    endDate: undefined,
    scopes: [],
  })

  const updateFormData = (data: Partial<FormData>) => {
    setFormData((prev) => ({ ...prev, ...data }))
    // Clear errors for updated fields
    const clearedErrors = { ...errors }
    Object.keys(data).forEach((key) => {
      delete clearedErrors[key]
    })
    setErrors(clearedErrors)
  }

  const validateStep = (step: number): boolean => {
    const newErrors: Record<string, string> = {}

    if (step === 1) {
      if (!formData.clientId) newErrors.clientId = "Client is required"
      if (!formData.projectName.trim()) newErrors.projectName = "Project name is required"
    }

    if (step === 2) {
      if (!formData.siteId) newErrors.siteId = "Site is required"
      if (!formData.resaLocation) newErrors.resaLocation = "RESA Location is required"
    }

    if (step === 3) {
      if (formData.scopes.length === 0) newErrors.scopes = "At least one scope is required"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep((prev) => Math.min(prev + 1, 3))
    }
  }

  const handleBack = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1))
  }

  const handleSubmit = async () => {
    if (!validateStep(3)) return

    setIsSubmitting(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsSubmitting(false)
    router.push("/projects")
  }

  return (
    <AppShell title="Create New Project" subtitle="Set up a new project in 3 easy steps">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Back Link */}
        <Link
          href="/projects"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Projects
        </Link>

        {/* Step Indicator */}
        <StepIndicator steps={steps} currentStep={currentStep} />

        {/* Form Card */}
        <Card>
          <CardHeader>
            <CardTitle>{steps[currentStep - 1].name}</CardTitle>
          </CardHeader>
          <CardContent>
            {currentStep === 1 && <StepClientBasics formData={formData} setFormData={setFormData} errors={errors} />}
            {currentStep === 2 && <StepLocationTeam formData={formData} setFormData={setFormData} errors={errors} />}
            {currentStep === 3 && <StepInitialScope formData={formData} setFormData={setFormData} />}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8 pt-6 border-t">
              <Button variant="outline" onClick={() => setCurrentStep((s) => s - 1)} disabled={currentStep === 1}>
                Previous
              </Button>

              {currentStep < 3 ? (
                <Button onClick={handleNext}>Next</Button>
              ) : (
                <Button onClick={handleSubmit} disabled={isSubmitting}>
                  {isSubmitting ? "Creating..." : "Create Project"}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  )
}
