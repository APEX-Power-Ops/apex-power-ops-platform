import Link from "next/link"
import { ArrowLeft, MoreHorizontal, Edit, Download, Copy, Archive } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { StatusBadge } from "@/components/dashboard/status-badge"
import { ProjectTabs } from "@/components/projects/project-tabs"
import { AppShell } from "@/components/layout/app-shell"

// ... existing code (project data) ...

export default function ProjectDetailPage({ project }) {
  return (
    <AppShell title={project.name} subtitle={project.client}>
      <div className="space-y-6">
        {/* Back Link and Actions */}
        <div className="flex items-center justify-between">
          <Link
            href="/projects"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Projects
          </Link>

          <div className="flex items-center gap-2">
            <StatusBadge status={project.status} />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>
                  <Edit className="w-4 h-4 mr-2" />
                  Edit Project
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Download className="w-4 h-4 mr-2" />
                  Export Data
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Copy className="w-4 h-4 mr-2" />
                  Duplicate
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-destructive">
                  <Archive className="w-4 h-4 mr-2" />
                  Archive Project
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Project Info Summary */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-muted/50 rounded-lg">
          <div>
            <p className="text-sm text-muted-foreground">Project ID</p>
            <p className="font-mono font-medium">{project.id}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Location</p>
            <p className="font-medium">{project.location}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Project Manager</p>
            <p className="font-medium">{project.projectManager}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Timeline</p>
            <p className="font-medium">
              {project.startDate} - {project.endDate}
            </p>
          </div>
        </div>

        {/* Project Tabs */}
        <ProjectTabs project={project} />
      </div>
    </AppShell>
  )
}
