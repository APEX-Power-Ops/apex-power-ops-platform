"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { StatsCard } from "@/components/dashboard/stats-card"
import { StatusBadge } from "@/components/dashboard/status-badge"
import { DecisionCallout } from "@/components/ui/decision-callout"
import { AppShell } from "@/components/layout/app-shell"
import {
  Plus,
  Search,
  Receipt,
  Clock,
  TrendingUp,
  DollarSign,
  MoreHorizontal,
  Eye,
  Copy,
  Send,
  CheckCircle2,
  XCircle,
  Pencil,
  FolderKanban,
} from "lucide-react"

type EstimateStatus = "draft" | "sent" | "negotiating" | "won" | "lost"

interface LineItem {
  service: string
  quantity: number
  rate: number
  total: number
}

interface Estimate {
  id: string
  estimateNumber: string
  projectName: string
  client: string
  services: string[]
  totalValue: number
  status: EstimateStatus
  createdDate: string
  estimator: string
  lineItems: LineItem[]
  notes?: string
}

const estimates: Estimate[] = [
  {
    id: "1",
    estimateNumber: "E-2024-0147",
    projectName: "Main Campus Upgrade",
    client: "State University",
    services: ["Testing", "PSS"],
    totalValue: 125000,
    status: "sent",
    createdDate: "12/05/2024",
    estimator: "J. Smith",
    lineItems: [
      { service: "Substation Testing", quantity: 1, rate: 45000, total: 45000 },
      { service: "Switchgear Testing", quantity: 12, rate: 2500, total: 30000 },
      { service: "Transformer Testing", quantity: 8, rate: 3500, total: 28000 },
      { service: "Power System Study", quantity: 1, rate: 15000, total: 15000 },
      { service: "Mobilization", quantity: 1, rate: 7000, total: 7000 },
    ],
    notes: "Client requested expedited timeline. May need additional crew.",
  },
  {
    id: "2",
    estimateNumber: "E-2024-0146",
    projectName: "Distribution Center",
    client: "Amazon",
    services: ["Testing"],
    totalValue: 67500,
    status: "draft",
    createdDate: "12/04/2024",
    estimator: "M. Johnson",
    lineItems: [
      { service: "Switchgear Testing", quantity: 15, rate: 2500, total: 37500 },
      { service: "Transformer Testing", quantity: 6, rate: 3500, total: 21000 },
      { service: "Mobilization", quantity: 1, rate: 9000, total: 9000 },
    ],
  },
  {
    id: "3",
    estimateNumber: "E-2024-0145",
    projectName: "Warehouse A",
    client: "Target",
    services: ["Arc Flash"],
    totalValue: 12000,
    status: "won",
    createdDate: "12/01/2024",
    estimator: "J. Smith",
    lineItems: [{ service: "Arc Flash Study", quantity: 1, rate: 12000, total: 12000 }],
  },
  {
    id: "4",
    estimateNumber: "E-2024-0144",
    projectName: "Hospital Wing C",
    client: "Mercy Health",
    services: ["Full Service"],
    totalValue: 89000,
    status: "lost",
    createdDate: "11/28/2024",
    estimator: "K. Davis",
    lineItems: [
      { service: "Substation Testing", quantity: 1, rate: 45000, total: 45000 },
      { service: "Arc Flash Study", quantity: 1, rate: 18000, total: 18000 },
      { service: "Coordination Study", quantity: 1, rate: 15000, total: 15000 },
      { service: "Mobilization", quantity: 1, rate: 11000, total: 11000 },
    ],
    notes: "Lost to competitor on price. Client went with lowest bidder.",
  },
  {
    id: "5",
    estimateNumber: "E-2024-0143",
    projectName: "Data Center",
    client: "Microsoft",
    services: ["Testing"],
    totalValue: 245000,
    status: "negotiating",
    createdDate: "11/25/2024",
    estimator: "M. Johnson",
    lineItems: [
      { service: "Substation Testing", quantity: 3, rate: 45000, total: 135000 },
      { service: "Switchgear Testing", quantity: 24, rate: 2500, total: 60000 },
      { service: "Transformer Testing", quantity: 10, rate: 3500, total: 35000 },
      { service: "Mobilization", quantity: 1, rate: 15000, total: 15000 },
    ],
    notes: "Discussing scope adjustments. May add PSS to package.",
  },
  {
    id: "6",
    estimateNumber: "E-2024-0142",
    projectName: "Office Complex",
    client: "WeWork",
    services: ["Testing", "Arc Flash"],
    totalValue: 34500,
    status: "sent",
    createdDate: "11/22/2024",
    estimator: "J. Smith",
    lineItems: [
      { service: "Switchgear Testing", quantity: 8, rate: 2500, total: 20000 },
      { service: "Arc Flash Study", quantity: 1, rate: 8500, total: 8500 },
      { service: "Mobilization", quantity: 1, rate: 6000, total: 6000 },
    ],
  },
]

export default function EstimatesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusTab, setStatusTab] = useState("active")
  const [selectedEstimate, setSelectedEstimate] = useState<Estimate | null>(null)

  const getFilteredEstimates = () => {
    let filtered = estimates

    // Tab filter
    if (statusTab === "active") {
      filtered = filtered.filter((e) => !["won", "lost"].includes(e.status))
    } else if (statusTab !== "all") {
      filtered = filtered.filter((e) => e.status === statusTab)
    }

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(
        (e) =>
          e.projectName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          e.client.toLowerCase().includes(searchQuery.toLowerCase()) ||
          e.estimateNumber.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    return filtered
  }

  const filteredEstimates = getFilteredEstimates()

  const openEstimates = estimates.filter((e) => !["won", "lost"].includes(e.status))
  const openValue = openEstimates.reduce((sum, e) => sum + e.totalValue, 0)
  const pendingApproval = estimates.filter((e) => e.status === "sent").length
  const wonCount = estimates.filter((e) => e.status === "won").length
  const totalCount = estimates.filter((e) => ["won", "lost"].includes(e.status)).length
  const winRate = totalCount > 0 ? Math.round((wonCount / totalCount) * 100) : 0
  const avgValue = Math.round(estimates.reduce((sum, e) => sum + e.totalValue, 0) / estimates.length)

  return (
    <AppShell title="Estimates" subtitle="Manage quotes and proposals">
      <div className="space-y-6">
        {/* Decision Callout */}
        <DecisionCallout title="Quote Expiring Soon" type="decision" stakeholder="Sales Team">
          EST-2024-089 for CloudNet Data Center ($485K) expires in 3 days. Client requested final review meeting -
          schedule or extend deadline?
        </DecisionCallout>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard
            title="Open Estimates"
            value={estimates.filter((e) => ["draft", "sent", "negotiating"].includes(e.status)).length}
            change={{
              value: `$${(estimates.filter((e) => ["draft", "sent", "negotiating"].includes(e.status)).reduce((acc, e) => acc + e.amount, 0) / 1000).toFixed(0)}K value`,
              trend: "neutral",
            }}
            icon={Receipt}
            iconColor="bg-primary/10 text-primary"
          />
          <StatsCard
            title="Pending Approval"
            value={estimates.filter((e) => e.status === "sent").length}
            change={{ value: "Awaiting client", trend: "neutral" }}
            icon={Clock}
            iconColor="bg-status-warning/10 text-status-warning"
          />
          <StatsCard
            title="Win Rate"
            value="64%"
            change={{ value: "+5% this quarter", trend: "up" }}
            icon={TrendingUp}
            iconColor="bg-status-success/10 text-status-success"
          />
          <StatsCard
            title="Avg Estimate Value"
            value="$127K"
            change={{ value: "+8% vs last year", trend: "up" }}
            icon={DollarSign}
            iconColor="bg-status-info/10 text-status-info"
          />
        </div>

        {/* Filters and Table */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search estimates..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Tabs value={statusTab} onValueChange={setStatusTab}>
                <TabsList>
                  <TabsTrigger value="active">Active</TabsTrigger>
                  <TabsTrigger value="won">Won</TabsTrigger>
                  <TabsTrigger value="lost">Lost</TabsTrigger>
                  <TabsTrigger value="all">All</TabsTrigger>
                </TabsList>
              </Tabs>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                New Estimate
              </Button>
            </div>

            {/* Table */}
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Estimate #</TableHead>
                  <TableHead>Project / Opportunity</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Services</TableHead>
                  <TableHead className="text-right">Total Value</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Estimator</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEstimates.map((estimate) => (
                  <TableRow
                    key={estimate.id}
                    className="cursor-pointer hover:bg-muted/50"
                    onClick={() => setSelectedEstimate(estimate)}
                  >
                    <TableCell className="font-medium text-primary">{estimate.estimateNumber}</TableCell>
                    <TableCell className="font-medium">{estimate.projectName}</TableCell>
                    <TableCell>{estimate.client}</TableCell>
                    <TableCell>
                      <div className="flex gap-1 flex-wrap">
                        {estimate.services.map((service) => (
                          <Badge key={service} variant="outline" className="text-xs">
                            {service}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-medium">${estimate.totalValue.toLocaleString()}</TableCell>
                    <TableCell>
                      <StatusBadge status={estimate.status} />
                    </TableCell>
                    <TableCell className="text-muted-foreground">{estimate.createdDate}</TableCell>
                    <TableCell>{estimate.estimator}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.stopPropagation()
                              setSelectedEstimate(estimate)
                            }}
                          >
                            <Eye className="h-4 w-4 mr-2" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={(e) => e.stopPropagation()}>
                            <Pencil className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={(e) => e.stopPropagation()}>
                            <Copy className="h-4 w-4 mr-2" />
                            Duplicate
                          </DropdownMenuItem>
                          {estimate.status === "draft" && (
                            <DropdownMenuItem onClick={(e) => e.stopPropagation()}>
                              <Send className="h-4 w-4 mr-2" />
                              Send to Client
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuSeparator />
                          {!["won", "lost"].includes(estimate.status) && (
                            <>
                              <DropdownMenuItem onClick={(e) => e.stopPropagation()} className="text-green-600">
                                <CheckCircle2 className="h-4 w-4 mr-2" />
                                Mark Won
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={(e) => e.stopPropagation()} className="text-red-600">
                                <XCircle className="h-4 w-4 mr-2" />
                                Mark Lost
                              </DropdownMenuItem>
                            </>
                          )}
                          {estimate.status === "won" && (
                            <DropdownMenuItem onClick={(e) => e.stopPropagation()} className="text-primary">
                              <FolderKanban className="h-4 w-4 mr-2" />
                              Convert to Project
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  )
}
