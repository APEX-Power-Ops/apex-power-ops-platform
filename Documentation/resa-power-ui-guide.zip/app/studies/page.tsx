"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import { StatsCard } from "@/components/dashboard/stats-card"
import { StatusBadge } from "@/components/dashboard/status-badge"
import { DecisionCallout } from "@/components/ui/decision-callout"
import { AppShell } from "@/components/layout/app-shell"
import {
  Plus,
  Search,
  FlaskConical,
  FileText,
  Clock,
  CheckCircle2,
  AlertCircle,
  Send,
  ChevronDown,
  ChevronRight,
  Calendar,
} from "lucide-react"
import { cn } from "@/lib/utils"

type StudyType = "PSS" | "Arc Flash" | "PSS + AF" | "Coordination"
type StudyStatus =
  | "intake"
  | "awaiting-docs"
  | "partial-docs"
  | "with-engineer"
  | "rfi-pending"
  | "draft-submitted"
  | "revisions"
  | "stickers-pending"
  | "closed"

interface Study {
  id: string
  jobNumber: string
  projectName: string
  client: string
  type: StudyType
  engineer: string | null
  status: StudyStatus
  daysInStatus: number
  docsReceived: number
  docsTotal: number
  poAmount: number
  documents: {
    name: string
    status: "received" | "requested" | "overdue"
    date?: string
    daysOverdue?: number
  }[]
}

const studies: Study[] = [
  {
    id: "1",
    jobNumber: "629266",
    projectName: "SWA Tech Ops",
    client: "Rosendin",
    type: "PSS",
    engineer: "Shaw Engineering",
    status: "partial-docs",
    daysInStatus: 5,
    docsReceived: 3,
    docsTotal: 5,
    poAmount: 15000,
    documents: [
      { name: "Single-Line Diagram", status: "received", date: "11/5" },
      { name: "Panel Schedules", status: "received", date: "11/5" },
      { name: "Transformer Data", status: "received", date: "11/5" },
      { name: "Utility Fault Current", status: "overdue", daysOverdue: 5 },
      { name: "Main Breaker Info", status: "overdue", daysOverdue: 5 },
    ],
  },
  {
    id: "2",
    jobNumber: "627687",
    projectName: "Hydro",
    client: "DP Electric",
    type: "Arc Flash",
    engineer: "Shaw Engineering",
    status: "stickers-pending",
    daysInStatus: 12,
    docsReceived: 5,
    docsTotal: 5,
    poAmount: 8500,
    documents: [
      { name: "Single-Line Diagram", status: "received", date: "10/20" },
      { name: "Panel Schedules", status: "received", date: "10/22" },
      { name: "Transformer Data", status: "received", date: "10/22" },
      { name: "Utility Fault Current", status: "received", date: "10/25" },
      { name: "Main Breaker Info", status: "received", date: "10/25" },
    ],
  },
  {
    id: "3",
    jobNumber: "659189",
    projectName: "Airport Center",
    client: "ICON",
    type: "PSS + AF",
    engineer: "Shaw Engineering",
    status: "draft-submitted",
    daysInStatus: 3,
    docsReceived: 5,
    docsTotal: 5,
    poAmount: 22000,
    documents: [
      { name: "Single-Line Diagram", status: "received", date: "11/1" },
      { name: "Panel Schedules", status: "received", date: "11/1" },
      { name: "Transformer Data", status: "received", date: "11/2" },
      { name: "Utility Fault Current", status: "received", date: "11/3" },
      { name: "Main Breaker Info", status: "received", date: "11/3" },
    ],
  },
  {
    id: "4",
    jobNumber: "673518",
    projectName: "P7 Lift Station",
    client: "City of Buckeye",
    type: "PSS",
    engineer: "Shaw Engineering",
    status: "with-engineer",
    daysInStatus: 8,
    docsReceived: 4,
    docsTotal: 5,
    poAmount: 12000,
    documents: [
      { name: "Single-Line Diagram", status: "received", date: "11/10" },
      { name: "Panel Schedules", status: "received", date: "11/10" },
      { name: "Transformer Data", status: "received", date: "11/12" },
      { name: "Utility Fault Current", status: "received", date: "11/15" },
      { name: "Main Breaker Info", status: "requested" },
    ],
  },
  {
    id: "5",
    jobNumber: "626206",
    projectName: "Scottsdale Ranch Park",
    client: "K2 Electric",
    type: "Arc Flash",
    engineer: null,
    status: "awaiting-docs",
    daysInStatus: 21,
    docsReceived: 1,
    docsTotal: 5,
    poAmount: 6500,
    documents: [
      { name: "Single-Line Diagram", status: "received", date: "10/28" },
      { name: "Panel Schedules", status: "overdue", daysOverdue: 14 },
      { name: "Transformer Data", status: "overdue", daysOverdue: 14 },
      { name: "Utility Fault Current", status: "requested" },
      { name: "Main Breaker Info", status: "requested" },
    ],
  },
  {
    id: "6",
    jobNumber: "680123",
    projectName: "Data Center Phase 2",
    client: "Microsoft",
    type: "PSS + AF",
    engineer: "Shaw Engineering",
    status: "intake",
    daysInStatus: 2,
    docsReceived: 0,
    docsTotal: 5,
    poAmount: 45000,
    documents: [
      { name: "Single-Line Diagram", status: "requested" },
      { name: "Panel Schedules", status: "requested" },
      { name: "Transformer Data", status: "requested" },
      { name: "Utility Fault Current", status: "requested" },
      { name: "Main Breaker Info", status: "requested" },
    ],
  },
]

const kanbanColumns = [
  { id: "intake", label: "Intake", statuses: ["intake"] as StudyStatus[] },
  { id: "awaiting-docs", label: "Awaiting Docs", statuses: ["awaiting-docs", "partial-docs"] as StudyStatus[] },
  { id: "with-engineer", label: "With Engineer", statuses: ["with-engineer", "rfi-pending"] as StudyStatus[] },
  { id: "draft-review", label: "Draft Review", statuses: ["draft-submitted", "revisions"] as StudyStatus[] },
  { id: "complete", label: "Final/Complete", statuses: ["stickers-pending", "closed"] as StudyStatus[] },
]

const typeColors: Record<StudyType, string> = {
  PSS: "bg-blue-100 text-blue-800",
  "Arc Flash": "bg-orange-100 text-orange-800",
  "PSS + AF": "bg-purple-100 text-purple-800",
  Coordination: "bg-green-100 text-green-800",
}

export default function StudiesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [viewMode, setViewMode] = useState<"kanban" | "table">("kanban")
  const [selectedStudy, setSelectedStudy] = useState<Study | null>(null)
  const [expandedRows, setExpandedRows] = useState<string[]>([])

  const filteredStudies = studies.filter((study) => {
    const matchesSearch =
      study.projectName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      study.client.toLowerCase().includes(searchQuery.toLowerCase()) ||
      study.jobNumber.includes(searchQuery)
    const matchesType = typeFilter === "all" || study.type === typeFilter
    const matchesStatus = statusFilter === "all" || study.status === statusFilter
    return matchesSearch && matchesType && matchesStatus
  })

  const getColumnStudies = (columnStatuses: StudyStatus[]) =>
    filteredStudies.filter((study) => columnStatuses.includes(study.status))

  const toggleRowExpanded = (id: string) => {
    setExpandedRows((prev) => {
      const next = [...prev]
      const index = next.indexOf(id)
      if (index !== -1) {
        next.splice(index, 1)
      } else {
        next.push(id)
      }
      return next
    })
  }

  const activeStudies = studies.filter((s) => !["closed"].includes(s.status)).length
  const awaitingDocs = studies.filter((s) => ["awaiting-docs", "partial-docs"].includes(s.status)).length
  const draftReviews = studies.filter((s) => ["draft-submitted", "revisions"].includes(s.status)).length
  const avgDays = Math.round(studies.reduce((sum, s) => sum + s.daysInStatus, 0) / studies.length)

  return (
    <AppShell title="Power System Studies" subtitle="Track PSS and Arc Flash studies">
      <div className="space-y-6">
        {/* Decision Callout */}
        <DecisionCallout title="Engineer Capacity Alert" type="decision" stakeholder="Engineering Manager">
          3 studies are waiting for engineer assignment. Current team utilization is at 94%. Should we bring in contract
          support for the PSS backlog?
        </DecisionCallout>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard
            title="Active Studies"
            value={studies.filter((s) => !["closed"].includes(s.status)).length}
            change={{ value: "In progress", trend: "neutral" }}
            icon={FlaskConical}
            iconColor="bg-primary/10 text-primary"
          />
          <StatsCard
            title="Awaiting Documents"
            value={studies.filter((s) => s.status === "awaiting-docs" || s.status === "partial-docs").length}
            change={{ value: "Need client input", trend: "neutral" }}
            icon={FileText}
            iconColor="bg-status-warning/10 text-status-warning"
          />
          <StatsCard
            title="In Review"
            value={studies.filter((s) => s.status === "draft-submitted" || s.status === "revisions").length}
            change={{ value: "With client", trend: "neutral" }}
            icon={CheckCircle2}
            iconColor="bg-status-info/10 text-status-info"
          />
          <StatsCard
            title="Avg Completion"
            value="18 days"
            change={{ value: "-3 days vs last month", trend: "up" }}
            icon={Clock}
            iconColor="bg-status-success/10 text-status-success"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search studies..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="intake">Intake</SelectItem>
              <SelectItem value="awaiting-docs">Awaiting Docs</SelectItem>
              <SelectItem value="with-engineer">With Engineer</SelectItem>
              <SelectItem value="draft-submitted">Draft Submitted</SelectItem>
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="PSS">PSS</SelectItem>
              <SelectItem value="Arc Flash">Arc Flash</SelectItem>
              <SelectItem value="PSS + AF">PSS + AF</SelectItem>
              <SelectItem value="Coordination">Coordination</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex gap-1 border rounded-lg p-1">
            <Button
              variant={viewMode === "kanban" ? "secondary" : "ghost"}
              size="sm"
              onClick={() => setViewMode("kanban")}
            >
              Kanban
            </Button>
            <Button
              variant={viewMode === "table" ? "secondary" : "ghost"}
              size="sm"
              onClick={() => setViewMode("table")}
            >
              Table
            </Button>
          </div>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Study
          </Button>
        </div>

        {/* Kanban Board */}
        {viewMode === "kanban" && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Study Pipeline</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-5 gap-4">
                {kanbanColumns.map((column) => {
                  const columnStudies = getColumnStudies(column.statuses)
                  return (
                    <div key={column.id} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium text-sm text-muted-foreground">{column.label}</h3>
                        <Badge variant="secondary" className="text-xs">
                          {columnStudies.length}
                        </Badge>
                      </div>
                      <div className="space-y-2 min-h-[200px] bg-muted/30 rounded-lg p-2">
                        {columnStudies.map((study) => (
                          <div
                            key={study.id}
                            className="bg-background border rounded-lg p-3 cursor-pointer hover:shadow-md transition-shadow"
                            onClick={() => setSelectedStudy(study)}
                          >
                            <div className="flex items-start justify-between mb-2">
                              <span className="font-medium text-sm truncate">{study.projectName}</span>
                              <Badge className={cn("text-xs", typeColors[study.type])}>{study.type}</Badge>
                            </div>
                            <p className="text-xs text-muted-foreground mb-2">{study.client}</p>
                            <div className="flex items-center justify-between text-xs">
                              <span
                                className={cn(
                                  "text-muted-foreground",
                                  study.daysInStatus > 14 && "text-red-600 font-medium",
                                )}
                              >
                                {study.daysInStatus}d in status
                              </span>
                              <span className="text-muted-foreground">
                                {study.docsReceived}/{study.docsTotal} docs
                              </span>
                            </div>
                            {study.engineer && (
                              <p className="text-xs text-muted-foreground mt-2 truncate">{study.engineer}</p>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Studies Table */}
        {viewMode === "table" && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">All Studies</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-8"></TableHead>
                    <TableHead>Job #</TableHead>
                    <TableHead>Project Name</TableHead>
                    <TableHead>Client</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Engineer</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Days</TableHead>
                    <TableHead>Docs</TableHead>
                    <TableHead className="text-right">PO Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudies.map((study) => {
                    const isExpanded = expandedRows.includes(study.id)
                    return (
                      <>
                        <TableRow
                          key={study.id}
                          className="cursor-pointer hover:bg-muted/50"
                          onClick={() => toggleRowExpanded(study.id)}
                        >
                          <TableCell>
                            {isExpanded ? (
                              <ChevronDown className="h-4 w-4 text-muted-foreground" />
                            ) : (
                              <ChevronRight className="h-4 w-4 text-muted-foreground" />
                            )}
                          </TableCell>
                          <TableCell className="font-medium">{study.jobNumber}</TableCell>
                          <TableCell>{study.projectName}</TableCell>
                          <TableCell>{study.client}</TableCell>
                          <TableCell>
                            <Badge className={cn("text-xs", typeColors[study.type])}>{study.type}</Badge>
                          </TableCell>
                          <TableCell>{study.engineer || "—"}</TableCell>
                          <TableCell>
                            <StatusBadge status={study.status} />
                          </TableCell>
                          <TableCell className={cn(study.daysInStatus > 14 && "text-red-600 font-medium")}>
                            {study.daysInStatus}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Progress value={(study.docsReceived / study.docsTotal) * 100} className="w-16 h-2" />
                              <span className="text-xs text-muted-foreground">
                                {study.docsReceived}/{study.docsTotal}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">${study.poAmount.toLocaleString()}</TableCell>
                        </TableRow>
                        {isExpanded && (
                          <TableRow>
                            <TableCell colSpan={10} className="bg-muted/30 p-4">
                              <div className="grid grid-cols-2 gap-6">
                                <div>
                                  <h4 className="font-medium mb-3">Document Checklist</h4>
                                  <div className="space-y-2">
                                    {study.documents.map((doc, idx) => (
                                      <div key={idx} className="flex items-center justify-between text-sm">
                                        <div className="flex items-center gap-2">
                                          <Checkbox checked={doc.status === "received"} disabled />
                                          <span className={cn(doc.status !== "received" && "text-muted-foreground")}>
                                            {doc.name}
                                          </span>
                                        </div>
                                        {doc.status === "received" && (
                                          <span className="text-xs text-muted-foreground">Received {doc.date}</span>
                                        )}
                                        {doc.status === "overdue" && (
                                          <span className="text-xs text-red-600 font-medium">
                                            {doc.daysOverdue}d overdue
                                          </span>
                                        )}
                                        {doc.status === "requested" && (
                                          <span className="text-xs text-amber-600">Requested</span>
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                  {study.documents.some((d) => d.status !== "received") && (
                                    <Button size="sm" variant="outline" className="mt-4 gap-2 bg-transparent">
                                      <Send className="h-3 w-3" />
                                      Send Reminder
                                    </Button>
                                  )}
                                </div>
                                <div>
                                  <h4 className="font-medium mb-3">Timeline</h4>
                                  <div className="space-y-2 text-sm">
                                    <div className="flex items-center gap-2">
                                      <Calendar className="h-4 w-4 text-muted-foreground" />
                                      <span className="text-muted-foreground">Created:</span>
                                      <span>Nov 1, 2024</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <Clock className="h-4 w-4 text-muted-foreground" />
                                      <span className="text-muted-foreground">Est. Completion:</span>
                                      <span>Dec 15, 2024</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </TableCell>
                          </TableRow>
                        )}
                      </>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {/* Document Panel Sheet */}
        <Sheet open={!!selectedStudy} onOpenChange={() => setSelectedStudy(null)}>
          <SheetContent className="w-[400px] sm:w-[540px]">
            {selectedStudy && (
              <>
                <SheetHeader>
                  <SheetTitle>{selectedStudy.projectName}</SheetTitle>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge className={cn("text-xs", typeColors[selectedStudy.type])}>{selectedStudy.type}</Badge>
                    <StatusBadge status={selectedStudy.status} />
                  </div>
                </SheetHeader>
                <div className="mt-6 space-y-6">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Job #</span>
                      <p className="font-medium">{selectedStudy.jobNumber}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Client</span>
                      <p className="font-medium">{selectedStudy.client}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Engineer</span>
                      <p className="font-medium">{selectedStudy.engineer || "Unassigned"}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">PO Amount</span>
                      <p className="font-medium">${selectedStudy.poAmount.toLocaleString()}</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-3">Document Checklist</h4>
                    <div className="space-y-3">
                      {selectedStudy.documents.map((doc, idx) => (
                        <div
                          key={idx}
                          className={cn(
                            "flex items-center justify-between p-3 rounded-lg border",
                            doc.status === "received" && "bg-green-50 border-green-200",
                            doc.status === "requested" && "bg-amber-50 border-amber-200",
                            doc.status === "overdue" && "bg-red-50 border-red-200",
                          )}
                        >
                          <div className="flex items-center gap-3">
                            {doc.status === "received" ? (
                              <CheckCircle2 className="h-5 w-5 text-green-600" />
                            ) : doc.status === "overdue" ? (
                              <AlertCircle className="h-5 w-5 text-red-600" />
                            ) : (
                              <Clock className="h-5 w-5 text-amber-600" />
                            )}
                            <span className="font-medium text-sm">{doc.name}</span>
                          </div>
                          <div className="text-xs">
                            {doc.status === "received" && <span className="text-green-700">Received {doc.date}</span>}
                            {doc.status === "overdue" && (
                              <span className="text-red-700 font-medium">{doc.daysOverdue}d overdue</span>
                            )}
                            {doc.status === "requested" && <span className="text-amber-700">Requested</span>}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button className="flex-1 gap-2">
                      <Send className="h-4 w-4" />
                      Send Reminder
                    </Button>
                    <Button variant="outline" className="flex-1 bg-transparent">
                      View Full Details
                    </Button>
                  </div>
                </div>
              </>
            )}
          </SheetContent>
        </Sheet>
      </div>
    </AppShell>
  )
}
