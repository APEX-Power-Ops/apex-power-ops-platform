"use client"

import { useState } from "react"
import Link from "next/link"
import { Search, MoreHorizontal, ChevronDown, ChevronRight, Grid, List, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { StatusBadge } from "@/components/dashboard/status-badge"
import { AppShell } from "@/components/layout/app-shell"

const apparatus = [
  {
    id: "1",
    type: "Circuit Breaker",
    manufacturer: "Eaton",
    model: "VCP-W",
    serial: "CB-2024-001",
    status: "passed" as const,
    project: "Main Substation Upgrade",
    projectId: "1",
    client: "Acme Corp",
    lastTest: "2024-01-15",
    testHistory: [
      { date: "2024-01-15", result: "Pass", technician: "Mike Chen" },
      { date: "2023-06-20", result: "Pass", technician: "Sarah Wilson" },
    ],
  },
  {
    id: "2",
    type: "Transformer",
    manufacturer: "ABB",
    model: "RESIBLOC",
    serial: "TR-2024-042",
    status: "scheduled" as const,
    project: "Building B Electrical",
    projectId: "2",
    client: "TechStart Inc",
    lastTest: "2023-11-08",
    testHistory: [{ date: "2023-11-08", result: "Pass", technician: "John Smith" }],
  },
  {
    id: "3",
    type: "Switchgear",
    manufacturer: "Siemens",
    model: "8DA10",
    serial: "SG-2023-187",
    status: "failed" as const,
    project: "Data Center Power",
    projectId: "3",
    client: "CloudNet Systems",
    lastTest: "2024-01-20",
    testHistory: [
      { date: "2024-01-20", result: "Fail", technician: "Mike Chen" },
      { date: "2023-08-15", result: "Pass", technician: "Sarah Wilson" },
    ],
  },
  {
    id: "4",
    type: "Relay",
    manufacturer: "SEL",
    model: "SEL-751",
    serial: "RL-2024-089",
    status: "not-tested" as const,
    project: "Hospital Emergency Power",
    projectId: "4",
    client: "Metro Health",
    lastTest: null,
    testHistory: [],
  },
  {
    id: "5",
    type: "Circuit Breaker",
    manufacturer: "Square D",
    model: "PowerPact",
    serial: "CB-2024-055",
    status: "passed" as const,
    project: "Main Substation Upgrade",
    projectId: "1",
    client: "Acme Corp",
    lastTest: "2024-01-18",
    testHistory: [{ date: "2024-01-18", result: "Pass", technician: "John Smith" }],
  },
  {
    id: "6",
    type: "Motor",
    manufacturer: "WEG",
    model: "W22",
    serial: "MT-2023-234",
    status: "passed" as const,
    project: "Manufacturing Line A",
    projectId: "5",
    client: "Industrial Pro",
    lastTest: "2024-01-10",
    testHistory: [{ date: "2024-01-10", result: "Pass", technician: "Sarah Wilson" }],
  },
]

export default function ApparatusPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [typeFilter, setTypeFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [viewMode, setViewMode] = useState<"table" | "grid">("table")
  const [expandedRows, setExpandedRows] = useState<string[]>([])

  const toggleRow = (id: string) => {
    setExpandedRows((prev) => (prev.includes(id) ? prev.filter((r) => r !== id) : [...prev, id]))
  }

  const filteredApparatus = apparatus.filter((item) => {
    const matchesSearch =
      item.serial.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.manufacturer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.model.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = typeFilter === "all" || item.type === typeFilter
    const matchesStatus = statusFilter === "all" || item.status === statusFilter
    return matchesSearch && matchesType && matchesStatus
  })

  return (
    <AppShell title="Apparatus" subtitle="Equipment and test management">
      <div className="space-y-6">
        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by serial, manufacturer, model..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="Circuit Breaker">Circuit Breaker</SelectItem>
              <SelectItem value="Transformer">Transformer</SelectItem>
              <SelectItem value="Switchgear">Switchgear</SelectItem>
              <SelectItem value="Relay">Relay</SelectItem>
              <SelectItem value="Cable">Cable</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="passed">Passed</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
              <SelectItem value="scheduled">Scheduled</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex gap-1 border rounded-lg p-1">
            <Button
              variant={viewMode === "table" ? "secondary" : "ghost"}
              size="icon"
              onClick={() => setViewMode("table")}
            >
              <List className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "grid" ? "secondary" : "ghost"}
              size="icon"
              onClick={() => setViewMode("grid")}
            >
              <Grid className="h-4 w-4" />
            </Button>
          </div>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Add Apparatus
          </Button>
        </div>

        {/* Table View */}
        {viewMode === "table" && (
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-8"></TableHead>
                  <TableHead>Serial Number</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Manufacturer / Model</TableHead>
                  <TableHead>Project</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Test</TableHead>
                  <TableHead className="w-8"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredApparatus.map((item) => {
                  const isExpanded = expandedRows.includes(item.id)
                  return (
                    <>
                      <TableRow key={item.id} className="cursor-pointer" onClick={() => toggleRow(item.id)}>
                        <TableCell>
                          <Button variant="ghost" size="icon" className="h-6 w-6">
                            {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                          </Button>
                        </TableCell>
                        <TableCell className="font-mono text-sm">{item.serial}</TableCell>
                        <TableCell>{item.type}</TableCell>
                        <TableCell>
                          {item.manufacturer} {item.model}
                        </TableCell>
                        <TableCell>
                          <Link
                            href={`/projects/${item.projectId}`}
                            className="text-primary hover:underline"
                            onClick={(e) => e.stopPropagation()}
                          >
                            {item.project}
                          </Link>
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={item.status} />
                        </TableCell>
                        <TableCell>{item.lastTest}</TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>View Details</DropdownMenuItem>
                              <DropdownMenuItem>Edit</DropdownMenuItem>
                              <DropdownMenuItem>View Test History</DropdownMenuItem>
                              <DropdownMenuItem>Download Report</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                      {isExpanded && (
                        <TableRow key={`${item.id}-expanded`}>
                          <TableCell colSpan={8} className="bg-muted/50 p-4">
                            <div className="text-sm">
                              <h4 className="font-medium mb-2">Test History</h4>
                              <div className="space-y-2">
                                {item.testHistory.map((test, idx) => (
                                  <div key={idx} className="flex items-center gap-4 text-muted-foreground">
                                    <span>{test.date}</span>
                                    <StatusBadge status={test.result.toLowerCase() as "pass" | "fail"} />
                                    <span>by {test.technician}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </TableCell>
                        </TableRow>
                      )}
                    </>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        )}

        {/* Grid View */}
        {viewMode === "grid" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredApparatus.map((item) => (
              <div key={item.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="font-mono text-sm text-muted-foreground">{item.serial}</p>
                    <h3 className="font-medium">{item.type}</h3>
                  </div>
                  <StatusBadge status={item.status} />
                </div>
                <p className="text-sm text-muted-foreground mb-2">
                  {item.manufacturer} {item.model}
                </p>
                <Link href={`/projects/${item.projectId}`} className="text-sm text-primary hover:underline">
                  {item.project}
                </Link>
                <p className="text-xs text-muted-foreground mt-2">Last tested: {item.lastTest}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  )
}
