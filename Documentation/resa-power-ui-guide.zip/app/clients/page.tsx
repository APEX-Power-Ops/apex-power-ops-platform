"use client"

import { useState } from "react"
import Link from "next/link"
import { Search, Plus, MoreHorizontal, Building2, MapPin, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AppShell } from "@/components/layout/app-shell"

const clients = [
  {
    id: "1",
    code: "APS",
    name: "Arizona Public Service",
    projects: 24,
    activeProjects: 8,
    sites: 12,
    totalRevenue: 1250000,
    contacts: [{ name: "John Martinez", role: "Facilities Director", email: "jmartinez@aps.com" }],
  },
  {
    id: "2",
    code: "SRP",
    name: "Salt River Project",
    projects: 18,
    activeProjects: 5,
    sites: 8,
    totalRevenue: 890000,
    contacts: [{ name: "Sarah Thompson", role: "Engineering Manager", email: "sthompson@srpnet.com" }],
  },
  {
    id: "3",
    code: "TEP",
    name: "Tucson Electric Power",
    projects: 12,
    activeProjects: 3,
    sites: 6,
    totalRevenue: 560000,
    contacts: [{ name: "Michael Chen", role: "Operations Manager", email: "mchen@tep.com" }],
  },
  {
    id: "4",
    code: "NVE",
    name: "NV Energy",
    projects: 15,
    activeProjects: 4,
    sites: 7,
    totalRevenue: 720000,
    contacts: [{ name: "Lisa Anderson", role: "Project Coordinator", email: "landerson@nvenergy.com" }],
  },
  {
    id: "5",
    code: "SDG",
    name: "San Diego Gas & Electric",
    projects: 20,
    activeProjects: 6,
    sites: 10,
    totalRevenue: 980000,
    contacts: [{ name: "David Kim", role: "Maintenance Director", email: "dkim@sdge.com" }],
  },
  {
    id: "6",
    code: "PSC",
    name: "Public Service Colorado",
    projects: 10,
    activeProjects: 2,
    sites: 5,
    totalRevenue: 420000,
    contacts: [{ name: "Jennifer Walsh", role: "Facilities Manager", email: "jwalsh@xcelenergy.com" }],
  },
]

export default function ClientsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedClient, setSelectedClient] = useState<string | null>(null)

  const filteredClients = clients.filter(
    (client) =>
      client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.code.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const activeClient = selectedClient ? clients.find((c) => c.id === selectedClient) : null

  return (
    <AppShell title="Clients" subtitle="Manage client relationships">
      <div className="space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <Building2 className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-semibold">{clients.length}</p>
                  <p className="text-sm text-muted-foreground">Total Clients</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-status-success/10">
                  <MapPin className="h-5 w-5 text-status-success" />
                </div>
                <div>
                  <p className="text-2xl font-semibold">{clients.reduce((acc, c) => acc + c.sites, 0)}</p>
                  <p className="text-sm text-muted-foreground">Total Sites</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-status-info/10">
                  <Building2 className="h-5 w-5 text-status-info" />
                </div>
                <div>
                  <p className="text-2xl font-semibold">{clients.reduce((acc, c) => acc + c.activeProjects, 0)}</p>
                  <p className="text-sm text-muted-foreground">Active Projects</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-status-warning/10">
                  <Building2 className="h-5 w-5 text-status-warning" />
                </div>
                <div>
                  <p className="text-2xl font-semibold">
                    ${(clients.reduce((acc, c) => acc + c.totalRevenue, 0) / 1000000).toFixed(1)}M
                  </p>
                  <p className="text-sm text-muted-foreground">Total Revenue</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Clients Table */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search clients..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Client
              </Button>
            </div>

            <div className="border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Client</TableHead>
                    <TableHead>Projects</TableHead>
                    <TableHead>Sites</TableHead>
                    <TableHead>Total Revenue</TableHead>
                    <TableHead className="w-8"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredClients.map((client) => (
                    <TableRow
                      key={client.id}
                      className={`cursor-pointer ${selectedClient === client.id ? "bg-muted" : ""}`}
                      onClick={() => setSelectedClient(client.id)}
                    >
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 text-primary font-semibold text-sm">
                            {client.code}
                          </div>
                          <span className="font-medium">{client.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>{client.projects}</TableCell>
                      <TableCell>{client.sites}</TableCell>
                      <TableCell>${(client.totalRevenue / 1000).toFixed(0)}K</TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>View Details</DropdownMenuItem>
                            <DropdownMenuItem>Edit</DropdownMenuItem>
                            <DropdownMenuItem>View Projects</DropdownMenuItem>
                            <DropdownMenuItem>Add Site</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>

          {/* Client Quick View */}
          <div>
            {activeClient ? (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{activeClient.name}</CardTitle>
                    <Button variant="outline" size="sm" asChild>
                      <Link href={`/clients/${activeClient.id}`}>
                        View Full <ChevronRight className="ml-1 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Active Projects</p>
                      <p className="text-lg font-semibold">{activeClient.activeProjects}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Total Sites</p>
                      <p className="text-lg font-semibold">{activeClient.sites}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Total Projects</p>
                      <p className="text-lg font-semibold">{activeClient.projects}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Revenue</p>
                      <p className="text-lg font-semibold">${(activeClient.totalRevenue / 1000).toFixed(0)}K</p>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <p className="text-sm font-medium mb-2">Primary Contact</p>
                    {activeClient.contacts.map((contact, idx) => (
                      <div key={idx} className="text-sm">
                        <p className="font-medium">{contact.name}</p>
                        <p className="text-muted-foreground">{contact.role}</p>
                        <p className="text-primary">{contact.email}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  Select a client to view details
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </AppShell>
  )
}
