"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useRole } from "@/contexts/role-context"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { AppShell } from "@/components/layout/app-shell"
import {
  MapPin,
  Clock,
  ChevronRight,
  Wifi,
  WifiOff,
  RefreshCw,
  Zap,
  Phone,
  Navigation,
  ClipboardCheck,
  AlertTriangle,
  CheckCircle2,
} from "lucide-react"
import Link from "next/link"

const todaySchedule = [
  {
    id: "1",
    time: "8:00 AM",
    project: "Metro Hospital Main Switchgear",
    client: "Metro Health System",
    location: "1234 Medical Center Dr, Houston, TX",
    equipment: "Circuit Breaker CB-101",
    status: "in-progress",
    testsComplete: 8,
    testsTotal: 17,
  },
  {
    id: "2",
    time: "1:30 PM",
    project: "Industrial Park Substation",
    client: "Texas Industrial LLC",
    location: "5678 Industrial Blvd, Houston, TX",
    equipment: "Transformer TR-201",
    status: "upcoming",
    testsComplete: 0,
    testsTotal: 12,
  },
  {
    id: "3",
    time: "4:00 PM",
    project: "Office Tower Assessment",
    client: "Premier Properties",
    location: "910 Downtown Ave, Houston, TX",
    equipment: "Relay Panel RP-301",
    status: "upcoming",
    testsComplete: 0,
    testsTotal: 8,
  },
]

const recentEquipment = [
  { name: "CB-099", type: "Circuit Breaker", lastTest: "Yesterday", result: "Pass" },
  { name: "TR-198", type: "Transformer", lastTest: "Dec 4", result: "Pass" },
  { name: "SW-045", type: "Switchgear", lastTest: "Dec 3", result: "Fail" },
]

export default function FieldTechPage() {
  const [isOnline, setIsOnline] = useState(true)
  const [lastSync, setLastSync] = useState("2 min ago")
  const { currentRole } = useRole()
  const router = useRouter()

  useEffect(() => {
    if (currentRole !== "field-tech") {
      router.push("/")
    }
  }, [currentRole, router])

  if (currentRole !== "field-tech") {
    return null
  }

  const currentJob = todaySchedule.find((job) => job.status === "in-progress")
  const upcomingJobs = todaySchedule.filter((job) => job.status === "upcoming")

  return (
    <AppShell title="Today's Schedule" subtitle="December 11, 2024">
      <div className="space-y-4 max-w-lg mx-auto">
        {/* Sync Status */}
        <div className="flex items-center justify-between p-3 bg-card rounded-lg border">
          <div className="flex items-center gap-2">
            {isOnline ? (
              <Wifi className="h-4 w-4 text-status-success" />
            ) : (
              <WifiOff className="h-4 w-4 text-status-error" />
            )}
            <span className="text-sm">{isOnline ? "Online" : "Offline"}</span>
            <span className="text-xs text-muted-foreground">• Synced {lastSync}</span>
          </div>
          <Button variant="ghost" size="sm">
            <RefreshCw className="h-4 w-4 mr-1" />
            Sync
          </Button>
        </div>

        {/* Safety Alert */}
        <div className="flex items-center gap-3 p-3 bg-status-warning/10 border border-status-warning/20 rounded-lg">
          <AlertTriangle className="h-5 w-5 text-status-warning shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-medium">Safety Reminder</p>
            <p className="text-xs text-muted-foreground">Verify LOTO procedures before testing</p>
          </div>
        </div>

        {/* Current Job */}
        {currentJob && (
          <Card className="border-primary">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <Badge className="bg-status-info">In Progress</Badge>
                <span className="text-sm text-muted-foreground">{currentJob.time}</span>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <h3 className="font-semibold">{currentJob.project}</h3>
                <p className="text-sm text-muted-foreground">{currentJob.client}</p>
              </div>

              <div className="flex items-start gap-2 text-sm">
                <MapPin className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                <span>{currentJob.location}</span>
              </div>

              <div className="flex items-center gap-2 text-sm">
                <Zap className="h-4 w-4 text-muted-foreground" />
                <span>{currentJob.equipment}</span>
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span>Test Progress</span>
                  <span className="font-medium">
                    {currentJob.testsComplete}/{currentJob.testsTotal}
                  </span>
                </div>
                <Progress value={(currentJob.testsComplete / currentJob.testsTotal) * 100} className="h-2" />
              </div>

              <div className="flex gap-2 pt-2">
                <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                  <Phone className="h-4 w-4 mr-1" />
                  Call Site
                </Button>
                <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                  <Navigation className="h-4 w-4 mr-1" />
                  Navigate
                </Button>
              </div>

              <Button className="w-full" asChild>
                <Link href="/field-tech/test">
                  <ClipboardCheck className="h-4 w-4 mr-2" />
                  Continue Testing
                </Link>
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Upcoming Jobs */}
        <div className="space-y-3">
          <h2 className="font-semibold">Upcoming</h2>
          {upcomingJobs.map((job) => (
            <Card key={job.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">{job.time}</span>
                    </div>
                    <h3 className="font-medium">{job.project}</h3>
                    <p className="text-sm text-muted-foreground">{job.client}</p>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Zap className="h-3 w-3" />
                      <span>{job.equipment}</span>
                      <span>• {job.testsTotal} tests</span>
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Recent Equipment */}
        <div className="space-y-3">
          <h2 className="font-semibold">Recent Equipment</h2>
          {recentEquipment.map((item) => (
            <div key={item.id} className="flex items-center justify-between p-3 bg-card rounded-lg border">
              <div>
                <p className="font-medium text-sm">{item.name}</p>
                <p className="text-xs text-muted-foreground">{item.type}</p>
              </div>
              <div className="flex items-center gap-2">
                {item.result === "Pass" ? (
                  <CheckCircle2 className="h-4 w-4 text-status-success" />
                ) : (
                  <Clock className="h-4 w-4 text-status-warning" />
                )}
                <span className="text-xs text-muted-foreground">{item.lastTest}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  )
}
