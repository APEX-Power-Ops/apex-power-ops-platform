"use client"

import { useState } from "react"
import {
  ArrowLeft,
  Camera,
  Check,
  ChevronDown,
  ChevronRight,
  Copy,
  MessageSquare,
  Wifi,
  WifiOff,
  X,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { cn } from "@/lib/utils"
import Link from "next/link"
import { MobileBottomNav } from "@/components/layout/mobile-bottom-nav"

type TestResult = "pass" | "fail" | "na" | null

interface TestItem {
  id: string
  description: string
  result: TestResult
  notes: string
  required: boolean
}

interface TestSection {
  id: string
  name: string
  items: TestItem[]
}

const initialSections: TestSection[] = [
  {
    id: "visual",
    name: "Visual & Mechanical",
    items: [
      {
        id: "v1",
        description: "Enclosure condition - no damage or corrosion",
        result: "pass",
        notes: "",
        required: true,
      },
      { id: "v2", description: "Proper labeling and nameplates", result: "pass", notes: "", required: true },
      { id: "v3", description: "Arc flash labels present", result: null, notes: "", required: true },
      { id: "v4", description: "Operating mechanism functions properly", result: null, notes: "", required: true },
      { id: "v5", description: "Mounting hardware secure", result: null, notes: "", required: false },
    ],
  },
  {
    id: "electrical",
    name: "Electrical Tests",
    items: [
      {
        id: "e1",
        description: "Insulation resistance test - phase to ground",
        result: "pass",
        notes: "Readings within spec",
        required: true,
      },
      {
        id: "e2",
        description: "Insulation resistance test - phase to phase",
        result: "pass",
        notes: "",
        required: true,
      },
      { id: "e3", description: "Contact resistance measurement", result: null, notes: "", required: true },
      { id: "e4", description: "Primary injection test", result: null, notes: "", required: true },
      { id: "e5", description: "Secondary injection test", result: null, notes: "", required: false },
    ],
  },
  {
    id: "functional",
    name: "Functional Tests",
    items: [
      { id: "f1", description: "Manual trip test", result: "pass", notes: "", required: true },
      { id: "f2", description: "Electrical trip test", result: "pass", notes: "", required: true },
      { id: "f3", description: "Close/open cycle timing", result: null, notes: "", required: true },
      { id: "f4", description: "Anti-pump relay operation", result: null, notes: "", required: false },
    ],
  },
  {
    id: "protection",
    name: "Protection Coordination",
    items: [
      { id: "p1", description: "Trip unit settings verified", result: "pass", notes: "", required: true },
      { id: "p2", description: "Time-current characteristics test", result: null, notes: "", required: true },
      { id: "p3", description: "Ground fault protection test", result: null, notes: "", required: true },
    ],
  },
]

export default function FieldTechTestPage() {
  const [sections, setSections] = useState<TestSection[]>(initialSections)
  const [expandedSections, setExpandedSections] = useState<string[]>(["visual"])
  const [expandedNotes, setExpandedNotes] = useState<string[]>([])
  const [isOnline, setIsOnline] = useState(true)
  const [photoCount, setPhotoCount] = useState(3)

  const toggleSection = (id: string) => {
    setExpandedSections((prev) => (prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]))
  }

  const toggleNotes = (itemId: string) => {
    setExpandedNotes((prev) => (prev.includes(itemId) ? prev.filter((n) => n !== itemId) : [...prev, itemId]))
  }

  const setTestResult = (sectionId: string, itemId: string, result: TestResult) => {
    setSections((prev) =>
      prev.map((section) =>
        section.id === sectionId
          ? {
              ...section,
              items: section.items.map((item) => (item.id === itemId ? { ...item, result } : item)),
            }
          : section,
      ),
    )
  }

  const updateNotes = (sectionId: string, itemId: string, notes: string) => {
    setSections((prev) =>
      prev.map((section) =>
        section.id === sectionId
          ? {
              ...section,
              items: section.items.map((item) => (item.id === itemId ? { ...item, notes } : item)),
            }
          : section,
      ),
    )
  }

  const allItems = sections.flatMap((s) => s.items)
  const completedItems = allItems.filter((i) => i.result !== null)
  const requiredItems = allItems.filter((i) => i.required)
  const completedRequired = requiredItems.filter((i) => i.result !== null)
  const canSubmit = completedRequired.length === requiredItems.length

  const getSectionCompletion = (section: TestSection) => {
    const completed = section.items.filter((i) => i.result !== null).length
    return `${completed}/${section.items.length}`
  }

  const copySerial = () => {
    navigator.clipboard.writeText("12345-ABC")
  }

  return (
    <div className="min-h-screen bg-muted/30 pb-24">
      {/* Offline Banner */}
      {!isOnline && (
        <div className="bg-status-warning text-status-warning-foreground px-4 py-2 text-center text-sm flex items-center justify-center gap-2">
          <WifiOff className="w-4 h-4" />
          You are offline. Changes will sync when connected.
        </div>
      )}

      {/* Sticky Header */}
      <header className="sticky top-0 bg-background border-b z-10">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="h-10 w-10" asChild>
              <Link href="/field-tech">
                <ArrowLeft className="w-5 h-5" />
              </Link>
            </Button>
            <div>
              <h1 className="font-semibold">Test Checklist</h1>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">Circuit Breaker</span>
                <span className="text-xs text-muted-foreground">CB-101</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isOnline ? (
              <div className="flex items-center gap-1.5 text-status-success text-sm">
                <div className="w-2 h-2 bg-status-success rounded-full" />
                Synced
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-status-warning text-sm">
                <div className="w-2 h-2 bg-status-warning rounded-full" />
                Pending
              </div>
            )}
            <Button variant="ghost" size="sm" onClick={() => setIsOnline(!isOnline)}>
              {isOnline ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </header>

      <div className="p-4 space-y-4">
        {/* Equipment Info Card */}
        <Card>
          <CardContent className="p-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <p className="text-muted-foreground text-xs">Manufacturer</p>
                <p className="font-medium">Eaton</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Model</p>
                <p className="font-medium">VCP-W</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Serial Number</p>
                <button
                  onClick={copySerial}
                  className="flex items-center gap-1.5 font-mono font-medium hover:text-primary"
                >
                  12345-ABC
                  <Copy className="w-3 h-3" />
                </button>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Location</p>
                <p className="font-medium">Building A, Room 101</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Progress Bar */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">
                {completedItems.length} of {allItems.length} items complete
              </span>
              <span className="text-sm text-muted-foreground">
                {Math.round((completedItems.length / allItems.length) * 100)}%
              </span>
            </div>
            <Progress value={(completedItems.length / allItems.length) * 100} className="h-3" />
          </CardContent>
        </Card>

        {/* Test Sections */}
        <div className="space-y-3">
          {sections.map((section) => (
            <Collapsible
              key={section.id}
              open={expandedSections.includes(section.id)}
              onOpenChange={() => toggleSection(section.id)}
            >
              <Card>
                <CollapsibleTrigger asChild>
                  <button className="w-full p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {expandedSections.includes(section.id) ? (
                        <ChevronDown className="w-5 h-5 text-muted-foreground" />
                      ) : (
                        <ChevronRight className="w-5 h-5 text-muted-foreground" />
                      )}
                      <span className="font-medium">{section.name}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">{getSectionCompletion(section)}</span>
                  </button>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="border-t">
                    {section.items.map((item) => (
                      <div key={item.id} className="p-4 border-b last:border-b-0">
                        <div className="flex items-start gap-3">
                          <div className="flex-1">
                            <p className="text-sm">
                              {item.description}
                              {item.required && <span className="text-status-error ml-1">*</span>}
                            </p>
                          </div>
                          <button
                            onClick={() => toggleNotes(item.id)}
                            className={cn(
                              "p-2 rounded-lg",
                              item.notes ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted",
                            )}
                          >
                            <MessageSquare className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Result Toggles */}
                        <div className="flex gap-2 mt-3">
                          <button
                            onClick={() => setTestResult(section.id, item.id, item.result === "pass" ? null : "pass")}
                            className={cn(
                              "flex-1 py-3 rounded-lg text-sm font-medium transition-colors",
                              item.result === "pass"
                                ? "bg-status-success text-white"
                                : "bg-muted text-muted-foreground hover:bg-muted/80",
                            )}
                          >
                            <Check className="w-4 h-4 mx-auto" />
                          </button>
                          <button
                            onClick={() => setTestResult(section.id, item.id, item.result === "fail" ? null : "fail")}
                            className={cn(
                              "flex-1 py-3 rounded-lg text-sm font-medium transition-colors",
                              item.result === "fail"
                                ? "bg-status-error text-white"
                                : "bg-muted text-muted-foreground hover:bg-muted/80",
                            )}
                          >
                            <X className="w-4 h-4 mx-auto" />
                          </button>
                          <button
                            onClick={() => setTestResult(section.id, item.id, item.result === "na" ? null : "na")}
                            className={cn(
                              "flex-1 py-3 rounded-lg text-sm font-medium transition-colors",
                              item.result === "na"
                                ? "bg-muted-foreground text-white"
                                : "bg-muted text-muted-foreground hover:bg-muted/80",
                            )}
                          >
                            N/A
                          </button>
                        </div>

                        {/* Notes Expansion */}
                        {expandedNotes.includes(item.id) && (
                          <div className="mt-3">
                            <Textarea
                              placeholder="Add notes..."
                              value={item.notes}
                              onChange={(e) => updateNotes(section.id, item.id, e.target.value)}
                              className="min-h-[80px]"
                            />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CollapsibleContent>
              </Card>
            </Collapsible>
          ))}
        </div>
      </div>

      {/* Sticky Bottom Bar */}
      <div className="fixed bottom-16 md:bottom-0 left-0 right-0 bg-background border-t p-4 z-10">
        <div className="flex gap-3 max-w-lg mx-auto">
          <Button
            variant="outline"
            className="flex-1 h-12 bg-transparent"
            onClick={() => setPhotoCount(photoCount + 1)}
          >
            <Camera className="w-4 h-4 mr-2" />
            Add Photo
            {photoCount > 0 && (
              <span className="ml-2 bg-primary/10 text-primary px-2 py-0.5 rounded-full text-xs">{photoCount}</span>
            )}
          </Button>
          <Button className="flex-1 h-12" disabled={!canSubmit}>
            {canSubmit ? "Submit Complete" : "Save & Continue"}
          </Button>
        </div>
      </div>

      <MobileBottomNav />
    </div>
  )
}
