"use client"

import { AppShell } from "@/components/layout/app-shell"
import { StatsCard } from "@/components/dashboard/stats-card"
import { StatusBadge } from "@/components/dashboard/status-badge"
import { DecisionCallout } from "@/components/ui/decision-callout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FolderKanban, DollarSign, AlertTriangle, Clock, ArrowRight, Calendar } from "lucide-react"
import Link from "next/link"

const myProjects = [
  {
    id: "PRJ-2024-089",
    name: "Metro Hospital Main Switchgear",
    client: "Metro Health System",
    status: "in-progress",
    progress: 60,
    budget: { spent: 127500, total: 150000 },
    dueDate: "2024-12-20",
    tasksComplete: 18,
    tasksTotal: 28,
    health: "at-risk",
  },
  {
    id: "PRJ-2024-092",
    name: "Industrial Park Substation",
    client: "Texas Industrial LLC",
    status: "in-progress",
    progress: 35,
    budget: { spent: 45000, total: 185000 },
    dueDate: "2025-01-15",
    tasksComplete: 12,
    tasksTotal: 42,
    health: "warning",
  },
  {
    id: "PRJ-2024-095",
    name: "Office Tower Electrical Assessment",
    client: "Premier Properties",
    status: "planning",
    progress: 10,
    budget: { spent: 8500, total: 95000 },
    dueDate: "2025-02-01",
    tasksComplete: 3,
    tasksTotal: 24,
    health: "healthy",
  },
  {
    id: "PRJ-2024-086",
    name: "Manufacturing Plant Annual Testing",
    client: "AutoTech Industries",
    status: "in-progress",
    progress: 85,
    budget: { spent: 198000, total: 220000 },
    dueDate: "2024-12-10",
    tasksComplete: 34,
    tasksTotal: 38,
    health: "healthy",
  },
]

const teamWorkload = [
  { name: "James Wilson", role: "Lead Tech", projects: 3, utilization: 95, initials: "JW" },
  { name: "Sarah Martinez", role: "Field Tech", projects: 2, utilization: 80, initials: "SM" },
  { name: "Tom Chen", role: "Field Tech", projects: 2, utilization: 75, initials: "TC" },
  { name: "Lisa Park", role: "Junior Tech", projects: 1, utilization: 45, initials: "LP" },
]

const upcomingTasks = [
  { task: "Transformer oil sampling", project: "Metro Hospital", due: "Today", priority: "high" },
  { task: "Switchgear inspection", project: "Industrial Park", due: "Tomorrow", priority: "medium" },
  { task: "Relay calibration", project: "Manufacturing Plant", due: "Dec 8", priority: "high" },
  { task: "Cable testing prep", project: "Office Tower", due: "Dec 10", priority: "low" },
  { task: "Final report review", project: "Metro Hospital", due: "Dec 12", priority: "high" },
]

export default function MyProjectsPage() {
  return (
    <AppShell title="My Projects" subtitle="Projects assigned to you">
      <div className="space-y-6">
        {/* Decision Callout */}
        <DecisionCallout title="Resource Conflict" type="decision" stakeholder="You">
          James Wilson is double-booked on Dec 12th for Metro Hospital and Industrial Park projects. Please reassign or
          reschedule one task.
        </DecisionCallout>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard
            title="Active Projects"
            value={myProjects.filter((p) => p.status === "in-progress").length}
            change={{ value: "Currently managing", trend: "neutral" }}
            icon={FolderKanban}
            iconColor="bg-primary/10 text-primary"
          />
          <StatsCard
            title="Total Budget"
            value={`$${(myProjects.reduce((acc, p) => acc + p.budget.total, 0) / 1000).toFixed(0)}K`}
            change={{ value: "Across all projects", trend: "neutral" }}
            icon={DollarSign}
            iconColor="bg-status-success/10 text-status-success"
          />
          <StatsCard
            title="At Risk"
            value={myProjects.filter((p) => p.health === "at-risk").length}
            change={{ value: "Needs attention", trend: "neutral" }}
            icon={AlertTriangle}
            iconColor="bg-status-error/10 text-status-error"
          />
          <StatsCard
            title="Tasks Due This Week"
            value={upcomingTasks.length}
            change={{ value: "Pending completion", trend: "neutral" }}
            icon={Clock}
            iconColor="bg-status-warning/10 text-status-warning"
          />
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Projects List */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Your Projects</h2>
              <Tabs defaultValue="all" className="w-auto">
                <TabsList>
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="active">Active</TabsTrigger>
                  <TabsTrigger value="at-risk">At Risk</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            <div className="space-y-4">
              {myProjects.map((project) => (
                <Card key={project.id} className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="flex">
                      <div
                        className={`w-1.5 ${
                          project.health === "at-risk"
                            ? "bg-status-error"
                            : project.health === "warning"
                              ? "bg-status-warning"
                              : "bg-status-success"
                        }`}
                      />
                      <div className="flex-1 p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-xs font-mono text-muted-foreground">{project.id}</span>
                              <StatusBadge status={project.status} />
                            </div>
                            <h3 className="font-medium">{project.name}</h3>
                            <p className="text-sm text-muted-foreground">{project.client}</p>
                          </div>
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/projects/${project.id}`}>
                              View <ArrowRight className="ml-1 h-4 w-4" />
                            </Link>
                          </Button>
                        </div>

                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground mb-1">Progress</p>
                            <div className="flex items-center gap-2">
                              <Progress value={project.progress} className="h-2 flex-1" />
                              <span className="font-medium">{project.progress}%</span>
                            </div>
                          </div>
                          <div>
                            <p className="text-muted-foreground mb-1">Budget</p>
                            <div className="flex items-center gap-2">
                              <Progress
                                value={(project.budget.spent / project.budget.total) * 100}
                                className={`h-2 flex-1 ${(project.budget.spent / project.budget.total) > 0.8 ? "[&>div]:bg-status-error" : ""}`}
                              />
                              <span className="font-medium">
                                ${(project.budget.spent / 1000).toFixed(0)}K / $
                                {(project.budget.total / 1000).toFixed(0)}K
                              </span>
                            </div>
                          </div>
                          <div>
                            <p className="text-muted-foreground mb-1">Tasks</p>
                            <p className="font-medium">
                              {project.tasksComplete} / {project.tasksTotal}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* Team Workload */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-base">Team Workload</CardTitle>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/team-workload">
                    View All <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {teamWorkload.map((member) => (
                    <div key={member.name} className="flex items-center gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback>{member.initials}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-sm font-medium truncate">{member.name}</p>
                          <span
                            className={`text-xs font-medium ${
                              member.utilization > 90
                                ? "text-status-error"
                                : member.utilization > 75
                                  ? "text-status-warning"
                                  : "text-status-success"
                            }`}
                          >
                            {member.utilization}%
                          </span>
                        </div>
                        <Progress
                          value={member.utilization}
                          className={`h-1.5 ${member.utilization > 90 ? "[&>div]:bg-status-error" : member.utilization > 75 ? "[&>div]:bg-status-warning" : ""}`}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Upcoming Tasks */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-base">Upcoming Tasks</CardTitle>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/task-calendar">
                    <Calendar className="mr-1 h-4 w-4" />
                    Calendar
                  </Link>
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {upcomingTasks.map((task) => (
                    <div key={task.id} className="flex items-start gap-3 p-2 rounded-lg hover:bg-muted/50">
                      <div
                        className={`mt-1.5 w-2 h-2 rounded-full ${
                          task.priority === "high"
                            ? "bg-status-error"
                            : task.priority === "medium"
                              ? "bg-status-warning"
                              : "bg-status-info"
                        }`}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{task.task}</p>
                        <p className="text-xs text-muted-foreground">{task.project}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge
                            variant="outline"
                            className={
                              task.priority === "high"
                                ? "border-status-error text-status-error"
                                : task.priority === "medium"
                                  ? "border-status-warning text-status-warning"
                                  : "border-status-info text-status-info"
                            }
                          >
                            {task.priority}
                          </Badge>
                          <span className="text-xs text-muted-foreground">Due {task.due}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Budget Alert */}
            <DecisionCallout title="Budget Alert" type="decision" stakeholder="Finance Review">
              Metro Hospital project is at 85% budget with only 60% completion. Review scope or request budget increase?
            </DecisionCallout>
          </div>
        </div>
      </div>
    </AppShell>
  )
}
