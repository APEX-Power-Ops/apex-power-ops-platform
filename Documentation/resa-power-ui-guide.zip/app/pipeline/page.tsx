"use client"

import { AppShell } from "@/components/layout/app-shell"
import { StatsCard } from "@/components/dashboard/stats-card"
import { DecisionCallout } from "@/components/ui/decision-callout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Target, DollarSign, TrendingUp, Clock, ArrowRight, FileText, Phone, Mail, Building2 } from "lucide-react"
import { Funnel, FunnelChart, LabelList, ResponsiveContainer, Cell, Tooltip } from "recharts"

const pipelineData = [
  { stage: "Lead", value: 18, amount: 2850000, fill: "#94a3b8" },
  { stage: "Qualified", value: 12, amount: 1920000, fill: "#60a5fa" },
  { stage: "Proposal", value: 8, amount: 1450000, fill: "#3b82f6" },
  { stage: "Negotiation", value: 5, amount: 875000, fill: "#2563eb" },
  { stage: "Won", value: 3, amount: 420000, fill: "#16a34a" },
]

const opportunities = [
  {
    id: "OPP-2024-142",
    name: "Data Center Power Infrastructure",
    client: "TechCore Systems",
    value: 485000,
    stage: "Proposal",
    probability: 65,
    dueDate: "2024-12-18",
    daysInStage: 5,
    contact: "Jennifer Adams",
  },
  {
    id: "OPP-2024-138",
    name: "Hospital Emergency Power System",
    client: "Regional Medical Center",
    value: 320000,
    stage: "Negotiation",
    probability: 80,
    dueDate: "2024-12-12",
    daysInStage: 8,
    contact: "Dr. Robert Chen",
  },
  {
    id: "OPP-2024-145",
    name: "Manufacturing Plant Upgrade",
    client: "Steel Dynamics Inc",
    value: 275000,
    stage: "Qualified",
    probability: 40,
    dueDate: "2024-12-28",
    daysInStage: 3,
    contact: "Mark Thompson",
  },
  {
    id: "OPP-2024-139",
    name: "Office Complex Annual Testing",
    client: "Premier Properties",
    value: 145000,
    stage: "Proposal",
    probability: 70,
    dueDate: "2024-12-20",
    daysInStage: 6,
    contact: "Sarah Mitchell",
  },
  {
    id: "OPP-2024-147",
    name: "Retail Distribution Center",
    client: "MegaMart Corp",
    value: 195000,
    stage: "Lead",
    probability: 20,
    dueDate: "2025-01-15",
    daysInStage: 2,
    contact: "Tom Richards",
  },
]

const pendingQuotes = [
  { id: "QT-2024-089", client: "TechCore Systems", amount: 485000, sent: "Dec 3", followUp: "Dec 10" },
  { id: "QT-2024-087", client: "Premier Properties", amount: 145000, sent: "Dec 1", followUp: "Dec 8" },
  { id: "QT-2024-085", client: "City Utilities", amount: 220000, sent: "Nov 28", followUp: "Overdue" },
]

export default function PipelinePage() {
  const totalPipeline = pipelineData.reduce((sum, item) => sum + item.amount, 0)
  const weightedPipeline = opportunities.reduce((sum, opp) => sum + opp.value * (opp.probability / 100), 0)

  return (
    <AppShell title="Sales Pipeline" subtitle="Track opportunities and manage quotes">
      <div className="space-y-6">
        {/* Decision Callout */}
        <DecisionCallout title="Pricing Decision Needed" type="decision" stakeholder="Sales Team">
          TechCore Systems is comparing our quote against a competitor 15% lower. Should we match price or emphasize our
          quality differentiators?
        </DecisionCallout>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard
            title="Total Pipeline"
            value="$7.5M"
            change={{ value: "+$1.2M this month", trend: "up" }}
            icon={Target}
            iconColor="bg-primary/10 text-primary"
          />
          <StatsCard
            title="Weighted Value"
            value="$3.8M"
            change={{ value: "Based on probability", trend: "neutral" }}
            icon={DollarSign}
            iconColor="bg-status-success/10 text-status-success"
          />
          <StatsCard
            title="Win Rate"
            value="64%"
            change={{ value: "+5% vs last quarter", trend: "up" }}
            icon={TrendingUp}
            iconColor="bg-status-info/10 text-status-info"
          />
          <StatsCard
            title="Avg Deal Size"
            value="$185K"
            change={{ value: "+12% this year", trend: "up" }}
            icon={Clock}
            iconColor="bg-status-warning/10 text-status-warning"
          />
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Pipeline Funnel */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Pipeline Funnel</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <FunnelChart>
                  <Tooltip
                    formatter={(value: number, name: string, props: { payload: { amount: number } }) => [
                      `${value} deals ($${(props.payload.amount / 1000000).toFixed(1)}M)`,
                      name,
                    ]}
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}
                  />
                  <Funnel dataKey="value" data={pipelineData} isAnimationActive>
                    <LabelList position="center" fill="#fff" stroke="none" dataKey="stage" />
                    {pipelineData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Funnel>
                </FunnelChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Opportunities Table */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">Active Opportunities</CardTitle>
              <Button variant="outline" size="sm">
                <FileText className="mr-2 h-4 w-4" />
                Export
              </Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Opportunity</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead>Stage</TableHead>
                    <TableHead>Probability</TableHead>
                    <TableHead>Close Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {opportunities.map((opp) => (
                    <TableRow key={opp.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{opp.name}</p>
                          <p className="text-sm text-muted-foreground">{opp.client}</p>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">${(opp.value / 1000).toFixed(0)}K</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            opp.stage === "Negotiation"
                              ? "border-status-success text-status-success"
                              : opp.stage === "Proposal"
                                ? "border-primary text-primary"
                                : "border-muted-foreground text-muted-foreground"
                          }
                        >
                          {opp.stage}
                        </Badge>
                      </TableCell>
                      <TableCell>{opp.probability}%</TableCell>
                      <TableCell>{opp.dueDate}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Phone className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Mail className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            View <ArrowRight className="ml-1 h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        {/* Pending Quotes */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base">Pending Quotes</CardTitle>
            <Button>Create Quote</Button>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {pendingQuotes.map((quote) => (
                <div key={quote.id} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-mono text-muted-foreground">{quote.id}</span>
                    <Badge variant={quote.age > 5 ? "destructive" : "secondary"}>{quote.age} days old</Badge>
                  </div>
                  <h4 className="font-medium mb-1">{quote.name}</h4>
                  <p className="text-sm text-muted-foreground mb-2">{quote.client}</p>
                  <p className="text-lg font-semibold mb-3">${(quote.value / 1000).toFixed(0)}K</p>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                      Edit
                    </Button>
                    <Button size="sm" className="flex-1">
                      Send
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Competitive Intel */}
        <DecisionCallout title="Competitive Intelligence" type="question" stakeholder="Sales Leadership">
          <div className="flex items-center gap-2 mt-2">
            <Building2 className="h-4 w-4" />
            <span>
              We've lost 3 deals to CompetitorX in the Phoenix market this quarter. Should we adjust our pricing
              strategy or enhance service offerings for that region?
            </span>
          </div>
        </DecisionCallout>
      </div>
    </AppShell>
  )
}
